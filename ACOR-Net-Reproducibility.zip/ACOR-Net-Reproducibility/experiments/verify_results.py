from pathlib import Path
import collections,statistics as st,json,hashlib
ROOT=Path(__file__).resolve().parent/'server_results'
assert (ROOT/'execution_complete.json').exists()
checks=0;clean_checks=0;unique_reference=set()
for name,expected in json.loads((ROOT/'result_hashes.json').read_text()).items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
for p in (ROOT/'evaluation').glob('*/*/complete.json'):
    meta=json.loads(p.read_text());data=json.loads((p.parent/'predictions.json').read_text())
    metrics=json.loads((p.parent/'metrics.json').read_text())
    assert len(data)==meta['records']
    assert len({x['record_id'] for x in data})==len(data)
    for mode,m in metrics.items():
        ex=[];oc=[];ae=[];pe=[];zero=[];oe=[];comb=collections.defaultdict(list);tp=fp=fn=0
        for row in data:
            y=row['truth'];q=row[mode]
            assert len(y)==len(q)==9 and all(isinstance(v,int) and v>=0 for v in q)
            e=y==q;ex.append(e);oc.append(sum(y)==sum(q));oe.append(abs(sum(y)-sum(q)));comb[tuple(y)].append(e)
            for a,b in zip(y,q):
                ae.append(abs(a-b));tp+=min(a,b);fp+=max(b-a,0);fn+=max(a-b,0)
                if a>0:pe.append(abs(a-b))
                else:zero.append(b>0)
        expected=dict(macro_exact_match_by_complete_composition=st.mean(st.mean(v) for v in comb.values()),
            sample_exact_match=st.mean(ex),occupancy_accuracy=st.mean(oc),occupancy_mae=st.mean(oe),
            positive_count_mae=st.mean(pe),all_count_mae=st.mean(ae),
            zero_count_false_positive_rate=st.mean(zero),multiset_micro_f1=2*tp/(2*tp+fp+fn))
        for k,v in expected.items():assert abs(v-m[k])<1e-10,(str(p),mode,k);checks+=1
        if mode!='round':assert all(sum(x[mode])<=3 for x in data)
    if meta['rate']==0 and meta['job'].startswith(('main/','ablation/')):
        assert meta['native_reproduction_checked'];clean_checks+=1;unique_reference.add(meta['checkpoint_sha256'])
fits=[json.loads(p.read_text()) for p in (ROOT/'training').glob('*/training_summary.json')]
assert len(fits)==9 and all(f['completed_epochs']==60 for f in fits)
assert checks==1872,checks
assert clean_checks==27,clean_checks
report=dict(metrics_independently_reproduced=checks,reference_evaluations_reproduced=clean_checks,
            unique_reference_checkpoints=len(unique_reference),reference_parent_reuse=3,
            training_fits=len(fits),training_epochs_per_fit=60,evaluation_conditions=144,
            decoder_truth_occupancy='not an input; predicted logits only',
            missing_observation_masks='fixed three seeds, paired by record ID',
            original_run_files='no original training artifacts overwritten')
dest=ROOT.parents[1]/'_reproduced/additional_verification.json'
dest.parent.mkdir(parents=True,exist_ok=True)
dest.write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
