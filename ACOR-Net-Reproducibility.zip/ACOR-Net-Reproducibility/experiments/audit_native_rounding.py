"""Check that supplementary nearest rounding equals native floor(mu+0.5)."""
from pathlib import Path
import argparse,sys,json,os,subprocess,concurrent.futures,hashlib
PROJECT=Path('${PROJECT}')
R=PROJECT/'runs/measurement_20261112'
sys.path.insert(0,str(PROJECT/'measurement_addon_20261112'))
import measurement_experiments as m

def one(jobid):
    torch,engine=m.activate(PROJECT)
    from wificount.data import CSIDataset,collate_records
    from torch.utils.data import DataLoader
    plan=m.read(R/'plan.json')
    path=Path(next(x for x in plan['original'] if x['id']==jobid)['checkpoint'])
    ck=torch.load(path,map_location='cpu',weights_only=True);cfg=ck['config']
    engine.seed_all(cfg['model_seed'],True,cfg['threads'])
    engine.verify_run_provenance(ck['provenance'],engine.provenance(cfg),'Native rounding audit')
    model=engine.build_model(cfg,initialize_pretrained=False).cuda();model.load_state_dict(ck['model']);model.eval()
    records,train,_,_,store,stats=engine.prepare_data(cfg,stats=ck['stats'])
    ds=CSIDataset([x for x in records if x['partition']=='test_unseen'],store,stats,expected_train_records=train)
    checked=0;different=0
    for rate in [.1,.3]:
        for seed in [20261,20262,20263]:
            ref={x['record_id']:x['round'] for x in m.read(R/'evaluation'/jobid.replace('/','__')/f'drop{rate:g}_mask{seed}/predictions.json')}
            for batch in DataLoader(ds,batch_size=16,shuffle=False,num_workers=0,collate_fn=collate_records):
                changed=[m.thin(x,v,meta['record_id'],rate,seed) for x,v,meta in zip(batch['X'],batch['valid'],batch['meta'])]
                with torch.inference_mode():
                    out=model.predict_potentials(torch.stack([x[0] for x in changed]).cuda(),torch.stack([x[1] for x in changed]).cuda())
                    native=engine.decode_outputs(out,cfg,None).cpu().tolist()
                for meta,pred in zip(batch['meta'],native):
                    checked+=1;different+=int(pred!=ref[meta['record_id']])
    result=dict(job=jobid,record_conditions_checked=checked,different_native_predictions=different,
                audit_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    m.write(R/'rounding_audit'/f'{jobid.replace("/","__")}.json',result)
    assert different==0,result
    print(json.dumps(result),flush=True)

def worker(gpu,jobs):
    env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']=str(gpu)
    for job in jobs:subprocess.run([sys.executable,__file__,'--job',job],env=env,check=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--job');a=p.parse_args()
    if a.job:one(a.job)
    else:
        jobs=[x['id'] for x in m.read(R/'plan.json')['original'] if 'activity_counting_' in x['id']]
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            futures=[pool.submit(worker,gpu,jobs[i::4]) for i,gpu in enumerate([1,2,3,7])]
            for f in concurrent.futures.as_completed(futures):f.result()
        m.write(R/'rounding_audit/complete.json',dict(checkpoints=9,all_perturbed_native_predictions_identical=True))
