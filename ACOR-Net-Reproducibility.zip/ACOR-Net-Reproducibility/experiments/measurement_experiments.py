"""Isolated Measurement additions. Import the original release without modifying it."""
from pathlib import Path
import argparse,copy,csv,hashlib,json,sys,collections,statistics,os

SCRIPT=Path(__file__).resolve()
SHA=hashlib.sha256(SCRIPT.read_bytes()).hexdigest()

def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,indent=2,allow_nan=False),encoding='utf-8')

def activate(project):
    sys.path.insert(0,str(Path(project)/'src'))
    import torch
    from torch import nn
    from torch.nn import functional as F
    from wificount import engine
    from wificount.domain_adapters import ActivityCountingAdapter
    class DirectOccupancy(nn.Module):
        def __init__(self,initialize_pretrained=True):
            super().__init__()
            original=ActivityCountingAdapter(initialize_pretrained=initialize_pretrained)
            self.projection=original.projection;self.backbone=original.backbone;self.head=original.head
            self.occupancy_head=nn.Linear(self.head.in_features,4)
        def forward(self,x,valid):
            h=self.backbone(self.projection(x,valid))
            # Dummy normalized views preserve the original engine's zero-weight
            # contrast bookkeeping. They add no learned feature module.
            z=h[:,None].expand(-1,9,-1)
            return dict(regression=F.relu(self.head(h)),b=self.occupancy_head(h),
                        h=h,z=z,p=F.normalize(z[...,:32].float(),dim=-1))
        def predict_potentials(self,x,valid):
            h=self.backbone(self.projection(x,valid))
            return dict(regression=F.relu(self.head(h)),b=self.occupancy_head(h))
    original_builder=engine.build_model
    original_provenance=engine.provenance
    def build(cfg,initialize_pretrained=True):
        if cfg.get('measurement_extension'):
            if cfg['measurement_extension']['script_sha256']!=SHA:
                raise ValueError('Extension source changed since protocol freeze')
            return DirectOccupancy(initialize_pretrained)
        return original_builder(cfg,initialize_pretrained=initialize_pretrained)
    def provenance(cfg):
        p=original_provenance(cfg)
        if cfg.get('measurement_extension'):p['measurement_extension']=cfg['measurement_extension']
        return p
    engine.build_model=build;engine.provenance=provenance
    return torch,engine

def decode(out,candidates,mode):
    import torch
    mu=out['regression'].float()
    if mode=='round':return torch.round(mu).clamp_min(0).long()
    c=candidates.float();scores=2*mu@c.T-c.square().sum(-1)
    if mode=='soft':scores+=.25*torch.log_softmax(out['b'].float(),-1)[:,candidates.sum(-1)]
    elif mode=='hard':
        n=out['b'].argmax(-1)
        scores=scores.masked_fill(candidates.sum(-1)[None]!=n[:,None],float('-inf'))
    elif mode!='legal':raise ValueError(mode)
    return candidates[scores.argmax(-1)]

def thin(x,valid,record_id,rate,mask_seed):
    """Remove observed time points, preserving order and contiguous loader mask.

    This simulates missing observations, not a calibrated physical packet-loss
    rate or shorter acquisition duration. Existing dataset losses remain.
    """
    import torch
    if rate==0:return x,valid
    positions=valid.nonzero(as_tuple=False).flatten()
    seed=int.from_bytes(hashlib.sha256(f'{mask_seed}:{record_id}'.encode()).digest()[:8],'little')%(2**63-1)
    gen=torch.Generator().manual_seed(seed)
    nkeep=max(1,len(positions)-round(rate*len(positions)))
    take=torch.randperm(len(positions),generator=gen)[:nkeep].sort().values
    kept=x[:,positions[take]]
    result=torch.zeros_like(x);mask=torch.zeros_like(valid)
    result[:,-nkeep:]=kept;mask[-nkeep:]=True
    return result,mask

def make_plan(args):
    project=Path(args.project).resolve();run=project/'runs/acor_reduced'
    parent=read(run/'plan.json');jobs=parent['jobs']
    nc=[j for j in jobs if j['id'].startswith('ablation/no_contrast_')]
    assert len(nc)==9
    training=[]
    for j in nc:
        cfg=copy.deepcopy(j['config']);s=cfg['split_seed'];m=cfg['model_seed']
        assert cfg['training']['gamma']==0
        name=f'direct_occ_s{s}_m{m}'
        cfg['output']=str(Path(args.output).resolve()/'training'/name)
        cfg['name']=name;cfg['workers']=2
        cfg['measurement_extension']=dict(script_sha256=SHA,kind='ActivityCounting ReLU direct head plus occupancy',
            comparator=j['id'],loss='same MSE+0.25 occupancy CE; contrast=joint=0',
            selection='original val_unseen Macro Exact, lower positive MAE, earlier epoch')
        training.append(dict(id=name,config=cfg,paired_checkpoint=str(Path(j['config']['output'])/'best.pt')))
    original=[dict(id=j['id'],checkpoint=str(Path(j['config']['output'])/'best.pt')) for j in jobs
              if j.get('role')=='main' and j['method'] in ['ours_v4','activity_counting']]
    value=dict(script_sha256=SHA,project=str(project),parent_plan_sha256=hashlib.sha256((run/'plan.json').read_bytes()).hexdigest(),
        training=training,original=original,no_contrast=nc,
        protocol=dict(new_training_fits=9,training_budget='same selected no-contrast settings, no new search',
        decoder_modes=['round','legal','hard','soft'],soft_lambda=.25,
        missing_observation_rates=[0,.1,.3],mask_seeds=[20261,20262,20263],
        partition='test_unseen',test_selection=False,original_results_overwritten=False))
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    path=out/'plan.json'
    if path.exists():assert read(path)==value,'Refusing to change frozen plan'
    else:write(path,value)
    print('PLAN',path,'new training fits',len(training),flush=True)

def train_one(args):
    plan=read(Path(args.output)/'plan.json');assert plan['script_sha256']==SHA
    _,engine=activate(plan['project'])
    job=next(x for x in plan['training'] if x['id']==args.job)
    cfg=job['config'];dest=Path(cfg['output'])
    if (dest/'training_summary.json').exists():
        assert read(dest/'config.json')==cfg
        print('TRAIN_ALREADY_COMPLETE',args.job);return
    resume=dest/'last.pt' if (dest/'last.pt').exists() else None
    engine.train(cfg,resume=resume)

def evaluate_one(args):
    plan=read(Path(args.output)/'plan.json');assert plan['script_sha256']==SHA
    torch,engine=activate(plan['project'])
    from wificount.data import CSIDataset,collate_records
    from wificount.objectives import enumerate_counts
    from wificount.metrics import evaluate_counts
    from torch.utils.data import DataLoader
    if args.job.startswith('direct_occ_'):
        job=next(x for x in plan['training'] if x['id']==args.job)
        checkpoint=Path(job['config']['output'])/'best.pt'
    elif args.job.startswith('ablation/'):
        job=next(x for x in plan['no_contrast'] if x['id']==args.job)
        checkpoint=Path(job['config']['output'])/'best.pt'
    else:checkpoint=Path(next(x for x in plan['original'] if x['id']==args.job)['checkpoint'])
    ckpt=torch.load(checkpoint,map_location='cpu',weights_only=True)
    cfg=ckpt['config'];engine.seed_all(cfg['model_seed'],True,cfg['threads'])
    if cfg.get('measurement_extension'):
        assert ckpt['provenance']['measurement_extension']['script_sha256']==SHA
    current=engine.provenance(cfg)
    engine.verify_run_provenance(ckpt['provenance'],current,'Measurement evaluation')
    dev=engine.device_for('cuda');model=engine.build_model(cfg,initialize_pretrained=False).to(dev)
    model.load_state_dict(ckpt['model'],strict=True);model.eval()
    records,train,_,_,store,stats=engine.prepare_data(cfg,stats=ckpt['stats'])
    dataset=CSIDataset([r for r in records if r['partition']=='test_unseen'],store,stats,expected_train_records=train)
    candidates=enumerate_counts(9,3).to(dev)
    stem=args.job.replace('/','__')
    # Decoder comparison is performed for all checkpoints; robustness only for
    # the two original main methods, avoiding additional retrained variants.
    conditions=[(0,0)]
    if args.job.startswith('main/'):
        conditions += [(r,s) for r in [.1,.3] for s in [20261,20262,20263]]
    root=Path(args.output)/'evaluation'/stem
    checkpoint_hash=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    for rate,seed in conditions:
        cond=f'drop{rate:g}_mask{seed}'
        dest=root/cond
        if (dest/'complete.json').exists():
            old=read(dest/'complete.json');assert old['checkpoint_sha256']==checkpoint_hash and old['script_sha256']==SHA
            continue
        loader=DataLoader(dataset,batch_size=16,shuffle=False,num_workers=0,collate_fn=collate_records)
        yy=[];mm=[];outputs=[];preds=collections.defaultdict(list)
        with torch.inference_mode():
            for batch in loader:
                x=batch['X'];v=batch['valid']
                if rate:
                    changed=[thin(xx,vv,meta['record_id'],rate,seed) for xx,vv,meta in zip(x,v,batch['meta'])]
                    x=torch.stack([z[0] for z in changed]);v=torch.stack([z[1] for z in changed])
                out=model.predict_potentials(x.to(dev),v.to(dev))
                modes=['round','legal','hard','soft'] if 'b' in out else ['round','legal']
                if rate:modes=['soft'] if 'b' in out else ['round']
                for mode in modes:preds[mode].extend(decode(out,candidates,mode).cpu().tolist())
                yy.extend(batch['counts'].tolist());mm.extend(batch['meta'])
                if rate==0:
                    mu=out['regression'].cpu().tolist();b=out['b'].cpu().tolist() if 'b' in out else [None]*len(mu)
                    outputs.extend(dict(record_id=m['record_id'],regression=a,occupancy_logits=z) for m,a,z in zip(batch['meta'],mu,b))
        metrics={mode:evaluate_counts(yy,pp,mm,max_occupancy=3,train_context_records=train) for mode,pp in preds.items()}
        # The primary clean output must reproduce the original archived counts.
        native='soft' if 'b' in out else 'round'
        archived=checkpoint.parent/'evaluation_test_unseen/predictions.csv'
        if rate==0 and archived.exists():
            old={r['record_id']:r['pred'] for r in engine.load_predictions(archived)}
            assert set(old)=={r['record_id'] for r in mm}
            assert all(old[m['record_id']]==pp for m,pp in zip(mm,preds[native])), 'Clean reproduction failed'
        write(dest/'metrics.json',metrics)
        rows=[]
        for i,(truth,meta) in enumerate(zip(yy,mm)):
            row={k:meta[k] for k in ['record_id','combo_id','environment','wifi_band']}
            row.update(truth=truth,**{mode:pp[i] for mode,pp in preds.items()})
            rows.append(row)
        write(dest/'predictions.json',rows)
        if outputs:write(dest/'continuous_outputs.json',outputs)
        write(dest/'complete.json',dict(script_sha256=SHA,checkpoint_sha256=checkpoint_hash,
              split=cfg['split_seed'],model_seed=cfg['model_seed'],job=args.job,rate=rate,mask_seed=seed,
              training=False,selection=False,records=len(rows),native_reproduction_checked=rate==0 and archived.exists()))
        print('EVALUATED',args.job,cond,flush=True)

def report(args):
    root=Path(args.output);values=[]
    for p in sorted((root/'evaluation').glob('*/*/complete.json')):
        meta=read(p);assert meta['script_sha256']==SHA
        for mode,m in read(p.parent/'metrics.json').items():
            row={k:meta[k] for k in ['job','split','model_seed','rate','mask_seed']}
            row['decoder']=mode;row.update({k:v for k,v in m.items() if isinstance(v,(float,int)) or v is None})
            values.append(row)
    groups=collections.defaultdict(list)
    for x in values:
        family=x['job'].split('_s')[0]
        groups[(family,x['decoder'],x['rate'])].append(x)
    summary=[]
    for (family,mode,rate),rr in sorted(groups.items()):
        row=dict(family=family,decoder=mode,missing_rate=rate,model_mask_evaluations=len(rr))
        for k in rr[0]:
            if k in ['job','split','model_seed','rate','mask_seed','decoder']:continue
            vv=[x[k] for x in rr if x[k] is not None]
            if vv:row[k]=statistics.mean(vv)
        summary.append(row)
    write(root/'reports/per_run.json',values);write(root/'reports/summary.json',summary)
    print('REPORT rows',len(values),'groups',len(summary))

def main():
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['plan','train','evaluate','report'])
    p.add_argument('--project');p.add_argument('--output',required=True);p.add_argument('--job')
    a=p.parse_args();dict(plan=make_plan,train=train_one,evaluate=evaluate_one,report=report)[a.stage](a)
if __name__=='__main__':main()
