"""Conditional combination-bootstrap intervals for the matched head comparison."""
from pathlib import Path
import json,statistics as st,collections,random
R=Path(__file__).resolve().parent/'server_results'
assert (R/'execution_complete.json').exists()
means=collections.defaultdict(list)
for split in [2026,2027,2028]:
    for seed in [2026,2027,2028]:
        a=R/f'evaluation/direct_occ_s{split}_m{seed}/drop0_mask0/predictions.json'
        b=R/f'evaluation/ablation__no_contrast_s{split}_m{seed}/drop0_mask0/predictions.json'
        baseline={x['record_id']:x for x in json.loads(b.read_text())}
        groups=collections.defaultdict(list)
        for x in json.loads(a.read_text()):
            old=baseline[x['record_id']];assert old['truth']==x['truth']
            groups[tuple(x['truth'])].append(int(x['soft']==x['truth'])-int(old['soft']==old['truth']))
        for combo,values in groups.items():means[(split,combo)].append(st.mean(values))
out=[]
def quantile(x,q):
    z=(len(x)-1)*q;i=int(z);f=z-i
    return x[i]*(1-f)+x[min(i+1,len(x)-1)]*f
for split in [2026,2027,2028]:
    groups=collections.defaultdict(list)
    for (s,c),values in means.items():
        if s==split:assert len(values)==3;groups[sum(c)].append(st.mean(values))
    assert len(groups[2])==7 and len(groups[3])==11
    rng=random.Random(55000+split);draws=[]
    for _ in range(2000):
        draws.append(sum(len(values)/18*st.mean(rng.choices(values,k=len(values))) for values in groups.values()))
    draws.sort();delta=sum(sum(values) for values in groups.values())/18
    out.append(dict(split=split,direct_minus_no_contrast_pp=100*delta,
                    interval_95_pp=[100*quantile(draws,.025),100*quantile(draws,.975)],
                    bootstrap_replicates=2000,unit='complete combinations stratified by reference occupancy',
                    conditional_on='fixed selected checkpoints and recordings; not independent acquisition-domain uncertainty'))
dest=R.parents[1]/'_reproduced/matched_paired_intervals.json'
dest.parent.mkdir(parents=True,exist_ok=True)
dest.write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
