"""Configuration loading, strict contracts and portable relative paths."""
from __future__ import annotations

import copy
import hashlib
import json
import re
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]
CORE_METHODS = ("b1", "b2", "b3", "b4", "b5", "ours")
PAPER_METHODS = ("amar", "mushot_source", "activity_counting")
METHODS = CORE_METHODS + ("ours_v2", "ours_v3", "ours_v4", "groupdro", "mldg", "set_transformer", "activity_cnn") + PAPER_METHODS
PATH_FIELDS = ("manifest", "data_root", "data_index", "output", "cache_dir", "development_protocol")


def deep_update(base, update):
    out = copy.deepcopy(base)
    for key, value in update.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_update(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def load_config(path, overrides=None, _stack=()):
    path = Path(path).resolve()
    if path in _stack:
        raise ValueError(f"Cyclic configuration inheritance: {path}")
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("Configuration must be a mapping")
    parent = raw.pop("extends", None)
    base = load_config(path.parent / parent, _stack=(*_stack, path)) if parent else {}
    for key in PATH_FIELDS:
        if raw.get(key) is not None:
            raw[key] = str((path.parent / raw[key]).resolve())
    cfg = deep_update(base, raw)
    if overrides:
        cfg = deep_update(cfg, overrides)
    validate_config(cfg)
    return cfg


def validate_config(cfg):
    manifest_seed = re.fullmatch(r"sample_manifest_seed(\d+)\.csv", Path(cfg["manifest"]).name)
    if manifest_seed and int(manifest_seed.group(1)) != cfg["split_seed"]:
        raise ValueError("split_seed must match the selected frozen manifest filename")
    if cfg.get("method") not in METHODS:
        raise ValueError(f"Unknown method; choose from {METHODS}")
    t = cfg["training"]
    if t["batch_size"] < 2 or t["epochs"] < 1:
        raise ValueError("Need batch_size>=2 and epochs>=1")
    if not 0 < t["learning_rate"] or not 0 <= t["gamma"]:
        raise ValueError("Invalid learning rate or contrast weight")
    if t["temperature"] <= 0:
        raise ValueError("temperature must be positive")
    if cfg["model"]["max_occupancy"] != 3:
        raise ValueError("Runnable experiment protocol is M=3 only; M=5 primitives do not define a validated dataset/split protocol")
    if t.get("diagnostic") not in (None, "erm", "within", "cross", "any"):
        raise ValueError("Unknown controlled diagnostic variant")
    if t.get("diagnostic") is not None:
        if cfg["method"] not in ("ours", "ours_v4") or t["sampler"] != "controlled":
            raise ValueError("Controlled diagnostics require method=ours/ours_v4 and sampler=controlled")
    if cfg["method"] == "ours_v2" and t["gamma"] != 0:
        raise ValueError("The V2 representation study requires gamma=0; contrast is a separate experiment")
    if cfg["method"] == "ours_v3":
        if t["gamma"] != 0:
            raise ValueError("V3 support-count study requires gamma=0")
        from .v3_model import validate_v3_settings
        validate_v3_settings(cfg.get("v3", {}))
    if cfg["method"] == "ours_v4":
        from .v4_model import validate_v4_settings
        validate_v4_settings(cfg.get("v4", {}))
        if t.get("contrast_variant", "ours") not in ("ours", "supcon", "no_n"):
            raise ValueError("V4 main contrast variant must be ours, supcon, or no_n")
        if t["gamma"] and (t["contrast_warmup"] < 0 or t["contrast_ramp"] < 1):
            raise ValueError("V4 requires a nonnegative contrast warmup and positive ramp")
    return cfg


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)

