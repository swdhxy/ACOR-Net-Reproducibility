"""Mechanism diagnostics and separately versioned background stress protocols.

Diagnostics may condition on labels/background, but never replace label-free
model inference. No function invents sessions, relabels data or synthesizes CSI.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import csv
import json
from pathlib import Path

import numpy as np

from .config import file_hash, write_json
from .data import ACTIONS, read_manifest


def support_coverage(records, no_aux=False):
    rows = [r for r in records if not r["partition"].startswith("excluded")
            and (not no_aux or r["n"] >= 2)]
    train = [r for r in rows if r["partition"] == "train"]
    if not train:
        raise ValueError("Support audit needs training records")
    cells = defaultdict(list)
    for row in rows:
        for k, r in enumerate(row["counts"]):
            if r > 0:
                cells[(row["n"], k, r, row["environment"], row["wifi_band"])].append(row)
    background = defaultdict(list)
    for row in train:
        background[(row["n"], row["environment"], row["wifi_band"])].append(row)
    table, totals = [], defaultdict(Counter)
    for (n, k, r, env, band), members in sorted(cells.items()):
        pos = [x for x in members if x["partition"] == "train"]
        combos = Counter(x["combo_id"] for x in pos)
        neg = [x for x in background[(n, env, band)] if x["counts"][k] != r]
        pairable = len(combos) >= 2 and bool(neg)
        item = {"n": n, "action": ACTIONS[k], "count": r,
                "environment": env, "wifi_band": band,
                "train_records": len(pos), "train_compositions": len(combos),
                "train_combo_ids": sorted(combos), "negative_records": len(neg),
                "negative_count_values": sorted({x["counts"][k] for x in neg}),
                "valid_train_anchors": len(pos) if pairable else 0,
                "direct_positive_available": len(combos) >= 2,
                "valid_contrast_available": pairable,
                "controlled_available": sum(v >= 2 for v in combos.values()) >= 2 and bool(neg),
                "partition_entries": dict(Counter(x["partition"] for x in members))}
        table.append(item)
        for partition, amount in item["partition_entries"].items():
            bucket = totals[(partition, r)]
            bucket["positive_entries"] += amount
            bucket["same_background_supervised_entries"] += amount * bool(pos)
            bucket["direct_positive_entries"] += amount * (len(combos) >= 2)
            bucket["valid_contrast_entries"] += amount * pairable
    return {"schema": 1, "no_aux": no_aux, "cells": table,
            "by_partition_and_count": {f"{p}/r{r}": dict(v) for (p, r), v in sorted(totals.items())},
            "scope": "Metadata support only; availability is not actual sampled exposure or evidence of improved performance.",
            "session_independence": "UNVERIFIED: known user_group_id is not capture_session_id"}


def exposure_ledger(run_directory):
    """Summarize actual logged anchors, and distinguish warmup from active loss."""
    root = Path(run_directory)
    cfg = json.loads((root / "config.json").read_text(encoding="utf-8"))
    from .engine import gamma_at
    files = sorted((root / "pair_logs").glob("epoch_*.json"))
    result = []
    for path in files:
        epoch = int(path.stem.split("_")[-1])
        logs = json.loads(path.read_text(encoding="utf-8"))
        groups = Counter()
        for batch in logs:
            groups.update(batch.get("group_anchor_counts", {}))
        weight = gamma_at(epoch - 1, cfg["training"])
        active = cfg["method"] in ("ours", "b5") and cfg["training"].get("diagnostic") != "erm" and weight > 0
        result.append({"epoch": epoch, "batches": len(logs), "contrast_weight": weight,
                       "contrast_active": active, "anchors_by_n_action_index_count": dict(groups),
                       "active_anchor_exposures": sum(groups.values()) if active else 0,
                       "selected_cross_positive_pairs": sum(x.get("selected_cross_positive_pairs", 0) for x in logs),
                       "selected_within_positive_pairs": sum(x.get("selected_within_positive_pairs", 0) for x in logs),
                       "negative_pairs": sum(x.get("negative_pairs", 0) for x in logs)})
    return {"epochs": result, "complete_training_marker": (root / "training_summary.json").exists(),
            "note": "Anchor exposures include repeat sampling; these are not independent sample counts. Background-specific availability is in support-audit."}


def support_audit(manifest, output, no_aux=False, run_directory=None):
    result = support_coverage(read_manifest(manifest), no_aux)
    result.update(manifest_sha256=file_hash(manifest))
    if run_directory:
        cfg = json.loads((Path(run_directory) / "config.json").read_text(encoding="utf-8"))
        if file_hash(cfg["manifest"]) != result["manifest_sha256"] or bool(cfg["no_aux"]) != bool(no_aux):
            raise ValueError("Exposure run must use this exact manifest and no_aux setting")
        result["actual_training_exposure"] = exposure_ledger(run_directory)
    write_json(output, result)
    return {"output": str(output), "cells": len(result["cells"]),
            "by_partition_and_count": result["by_partition_and_count"]}


def make_environment_stress(manifest, heldout_environment, output):
    """Subset original assignments: source train/val, held-out environment test.

    Source validation selects hyperparameters. Target labels are only used for
    protocol coverage. No training row is promoted to testing, and vice versa.
    """
    from .audit import audit_metadata
    original = read_manifest(manifest, max_occupancy=None)
    environments = {r["environment"] for r in original}
    if heldout_environment not in environments or len(environments) < 2:
        raise ValueError(f"Choose one held-out environment from {sorted(environments)}")
    target = Path(output).resolve()
    sidecar = target.with_suffix(".protocol.json")
    if target == Path(manifest).resolve() or target.exists() or sidecar.exists():
        raise FileExistsError("Stress manifests are new immutable artifacts; choose a new output")
    with Path(manifest).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        columns = reader.fieldnames
        raw = list(reader)
    retained = []
    for row in raw:
        partition = row["partition"]
        if partition.startswith("excluded"):
            continue
        is_target = row["environment"] == heldout_environment
        if (partition in ("train", "val_unseen", "val_aux") and not is_target) or (partition.startswith("test") and is_target):
            retained.append(row)
    ids = {r["record_id"] for r in retained}
    selected = [r for r in original if r["record_id"] in ids]
    audit = audit_metadata(selected)
    if not audit["ok"]:
        raise ValueError("Stress subset fails support/composition audit: " + "; ".join(audit["errors"]))
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(".csv.tmp")
    with temporary.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(retained)
    temporary.replace(target)
    report = {"schema": 1, "protocol": "supplemental_joint_unseen_environment_and_composition",
              "parent_manifest": str(Path(manifest).resolve()), "parent_sha256": file_hash(manifest),
              "manifest_sha256": file_hash(target), "heldout_environment": heldout_environment,
              "training_validation_environments": sorted(environments - {heldout_environment}),
              "partition_counts": dict(Counter(r["partition"] for r in selected)),
              "target_used_for_training_or_selection": False, "metadata_audit": audit,
              "scope": "Separate harder protocol. Not comparable as the same cohort to primary scores; does not establish new-user/session independence."}
    write_json(sidecar, report)
    return {"manifest": str(target), "protocol": str(sidecar), "partition_counts": report["partition_counts"]}


def retrieval_metrics(train_features, train_records, query_features, query_records):
    """Exact train-bank cosine retrieval per action, matched n/env/band.

    Equal-weight count cells/compositions for the similarity margin prevent the
    largest training composition from dominating the geometry diagnostic.
    """
    if not train_records or not query_records:
        raise ValueError("Retrieval requires nonempty training and query cohorts")
    if any(r["partition"] != "train" for r in train_records):
        raise ValueError("Retrieval bank must contain training records only")
    if any(r["partition"] != "val_unseen" for r in query_records):
        raise ValueError("Mechanism development uses val_unseen only; do not tune against test embeddings")
    if {r["record_id"] for r in train_records} & {r["record_id"] for r in query_records}:
        raise ValueError("Retrieval cohorts overlap")
    if {r["combo_id"] for r in train_records} & {r["combo_id"] for r in query_records}:
        raise ValueError("Retrieval requires held-out complete query compositions")
    train_features, query_features = np.asarray(train_features), np.asarray(query_features)
    for features, records in ((train_features, train_records), (query_features, query_records)):
        if features.ndim != 3 or features.shape[:2] != (len(records), 9) or not np.isfinite(features).all():
            raise ValueError("Features must be finite [records,9,embedding_dim]")
    if train_features.shape[2] != query_features.shape[2]:
        raise ValueError("Embedding dimensions differ")
    norms = np.linalg.norm(train_features, axis=-1, keepdims=True)
    qnorms = np.linalg.norm(query_features, axis=-1, keepdims=True)
    train_features = train_features / np.maximum(norms, 1e-8)
    query_features = query_features / np.maximum(qnorms, 1e-8)
    bank = defaultdict(list)
    for i, record in enumerate(train_records):
        bank[(record["n"], record["environment"], record["wifi_band"])].append(i)
    cells, rows = defaultdict(list), []
    for i, record in enumerate(query_records):
        indices = sorted(bank[(record["n"], record["environment"], record["wifi_band"])],
                         key=lambda j: train_records[j]["record_id"])
        for k, r in enumerate(record["counts"]):
            if r <= 0:
                continue
            if not indices:
                rows.append({"record_id": record["record_id"], "action": ACTIONS[k], "status": "no_background_bank"})
                continue
            valid_indices = [j for j in indices if norms[j, k, 0] > 1e-8]
            if qnorms[i, k, 0] <= 1e-8 or not valid_indices:
                rows.append({"record_id": record["record_id"], "action": ACTIONS[k], "status": "zero_embedding"})
                continue
            scores = train_features[valid_indices, k] @ query_features[i, k]
            j = valid_indices[int(np.argmax(scores))]
            count_frequencies = Counter(train_records[j]["counts"][k] for j in valid_indices)
            majority = min(count_frequencies, key=lambda c: (-count_frequencies[c], c))
            by_count_combo = defaultdict(lambda: defaultdict(list))
            for bank_index, score in zip(valid_indices, scores):
                item = train_records[bank_index]
                by_count_combo[item["counts"][k]][item["combo_id"]].append(float(score))
            count_means = {count: float(np.mean([np.mean(v) for v in combos.values()]))
                           for count, combos in by_count_combo.items()}
            negatives = [score for count, score in count_means.items() if count != r]
            margin = count_means[r] - float(np.mean(negatives)) if r in count_means and negatives else None
            row = {"record_id": record["record_id"], "action": ACTIONS[k], "n": record["n"], "count": r,
                   "environment": record["environment"], "wifi_band": record["wifi_band"], "status": "evaluated",
                   "nearest_train_record": train_records[j]["record_id"], "nearest_count": train_records[j]["counts"][k],
                   "correct_count": train_records[j]["counts"][k] == r, "balanced_cosine_margin": margin,
                   "bank_records": len(valid_indices), "majority_count": majority,
                   "majority_correct_count": majority == r,
                   "same_count_train_compositions": len(by_count_combo.get(r, {}))}
            rows.append(row)
            cells[(record["n"], k, r, record["environment"], record["wifi_band"])].append(row)
    summary = {}
    for key, values in sorted(cells.items()):
        margins = [v["balanced_cosine_margin"] for v in values if v["balanced_cosine_margin"] is not None]
        summary[",".join(map(str, key))] = {"entries": len(values),
            "count_retrieval_accuracy": float(np.mean([v["correct_count"] for v in values])),
            "majority_count_accuracy": float(np.mean([v["majority_correct_count"] for v in values])),
            "balanced_cosine_margin": float(np.mean(margins)) if margins else None, "margin_entries": len(margins)}
    return {"rows": rows, "groups": summary,
            "macro_group_count_retrieval_accuracy": float(np.mean([v["count_retrieval_accuracy"] for v in summary.values()])) if summary else None,
            "macro_group_majority_count_accuracy": float(np.mean([v["majority_count_accuracy"] for v in summary.values()])) if summary else None,
            "skipped_status_counts": dict(Counter(r["status"] for r in rows if r["status"] != "evaluated")),
            "scope": "Label/background-conditioned geometry diagnostic on val_unseen; not model inference accuracy, causal proof, or an independent significance test."}


def diagnose_representation(checkpoint, output, device="auto", representation="z"):
    import torch
    from torch.utils.data import DataLoader
    from .data import collate_records
    from .engine import build_model, device_for, prepare_data, provenance, seed_all, verify_run_provenance
    if representation not in ("z", "p"):
        raise ValueError("Choose count representation z or contrast projection p")
    if Path(output).exists():
        raise FileExistsError("Diagnostic result already exists; use a new output")
    ckpt = torch.load(checkpoint, map_location="cpu", weights_only=True)
    cfg = ckpt["config"]
    if cfg["method"] not in ("b1", "b2", "b3", "b4", "b5", "ours", "groupdro", "mldg"):
        raise ValueError("This diagnostic requires the shared action-conditioned backbone")
    prov = provenance(cfg)
    verify_run_provenance(ckpt["provenance"], prov, "Diagnostic")
    seed_all(cfg["model_seed"], cfg["deterministic"], cfg["threads"])
    dev = device_for(device)
    _, train, train_ds, val_ds, _, _ = prepare_data(cfg, stats=ckpt["stats"])
    model = build_model(cfg).to(dev)
    model.load_state_dict(ckpt["model"], strict=True)
    model.eval()
    def extract(dataset):
        blocks = []
        with torch.inference_mode():
            for batch in DataLoader(dataset, batch_size=cfg["evaluation"]["batch_size"], shuffle=False,
                                    num_workers=cfg["workers"], collate_fn=collate_records):
                blocks.append(model(batch["X"].to(dev), batch["valid"].to(dev))[representation].float().cpu().numpy())
        return np.concatenate(blocks)
    result = retrieval_metrics(extract(train_ds), train, extract(val_ds), val_ds.records)
    result.update(checkpoint_sha256=file_hash(checkpoint), manifest_sha256=prov["manifest_sha256"],
                  training_provenance=ckpt["provenance"], diagnostic_provenance=prov,
                  representation=representation, partition="val_unseen", test_read=False,
                  projection_warning="B4 projection p is not contrast-trained; z is the primary comparison.")
    write_json(output, result)
    return {"output": str(output), "macro_group_count_retrieval_accuracy": result["macro_group_count_retrieval_accuracy"],
            "test_read": False}
