"""Exactly specified supervised baselines and legal-space decoding."""

from __future__ import annotations

import torch
from torch import Tensor
from torch.nn import functional as F


def enumerate_counts(K: int = 9, M: int = 3) -> Tensor:
    """All nonnegative length-K integer vectors of sum <= M, lexicographically.

    This space includes unobserved compositions. Ordering also defines the
    deterministic lexicographic tie-break for joint and regression projection.
    """
    if not isinstance(K, int) or not isinstance(M, int) or K < 1 or M < 0:
        raise ValueError("K must be a positive integer and M a nonnegative integer")
    rows: list[list[int]] = []

    def visit(prefix: list[int], remaining: int) -> None:
        if len(prefix) == K:
            rows.append(prefix)
            return
        for value in range(remaining + 1):
            visit(prefix + [value], remaining - value)

    visit([], M)
    return torch.tensor(rows, dtype=torch.long)


def joint_scores(a: Tensor, b: Tensor, candidates: Tensor, lambda_occ: float = 1.0) -> Tensor:
    """s(c) = sum_k a[k,c_k] + lambda_occ * b[sum_k c_k], computed in float32."""
    if a.ndim != 3 or b.ndim != 2 or a.shape[0] != b.shape[0]:
        raise ValueError("a must be [B,K,M+1] and b [B,M+1]")
    if candidates.ndim != 2 or candidates.shape[1] != a.shape[1] or len(candidates) == 0:
        raise ValueError("candidates must be a nonempty [C,K] tensor")
    c = candidates.to(device=a.device, dtype=torch.long)
    occupancy = c.sum(dim=1)
    if bool((c < 0).any()) or int(c.max()) >= a.shape[-1] or int(occupancy.max()) >= b.shape[-1]:
        raise ValueError("Candidate space is incompatible with model head dimensions")
    action_index = torch.arange(a.shape[1], device=a.device)
    action_score = a.float()[:, action_index[None, :], c].sum(dim=-1)
    return action_score + float(lambda_occ) * b.float()[:, occupancy]


def _method(method: str) -> str:
    method = method.lower()
    aliases = {"regression": "b1", "independent": "b2", "constrained": "b3", "structured": "b4", "supcon": "b5"}
    method = aliases.get(method, method)
    if method not in {"b1", "b2", "b3", "b4", "b5", "ours"}:
        raise ValueError(f"Unknown supervised method: {method}")
    return method


def supervised_loss(
    outputs: dict[str, Tensor],
    counts: Tensor,
    method: str = "ours",
    candidates: Tensor | None = None,
    eta: float = 0.25,
    lambda_occ: float = 1.0,
) -> tuple[Tensor, dict[str, float]]:
    """Return ``(differentiable_loss, detached_scalar_log)``.

    B1: mean over records and actions of squared error. B2: sum action CE,
    then mean records. B3: B2 + eta occupancy CE. B4/B5/Ours: joint NLL
    + eta occupancy CE. Contrast loss is added by the training engine.
    """
    method = _method(method)
    if counts.ndim != 2 or counts.numel() == 0 or bool((counts < 0).any()):
        raise ValueError("counts must be a nonempty [B,K] nonnegative tensor")
    if counts.is_floating_point() and not bool((counts == counts.round()).all()):
        raise ValueError("counts must contain integers")
    device = next(iter(outputs.values())).device
    c = counts.to(device=device, dtype=torch.long)
    occupancy = c.sum(dim=1)
    if method == "b1":
        prediction = outputs["regression"].float()
        if prediction.shape != c.shape:
            raise ValueError("Regression output shape must match counts")
        total = F.mse_loss(prediction, c.float(), reduction="mean")
        return total, {"supervised": float(total.detach()), "regression_mse": float(total.detach())}
    a, b = outputs["a"], outputs["b"]
    if a.shape[:2] != c.shape or b.shape[0] != c.shape[0]:
        raise ValueError("Model output batch/action dimensions must match counts")
    if int(c.max()) >= a.shape[-1] or int(occupancy.max()) >= b.shape[-1]:
        raise ValueError("Target count/occupancy exceeds model maximum")
    if method in {"b2", "b3"}:
        per_action = F.cross_entropy(a.float().transpose(1, 2), c, reduction="none")
        core = per_action.sum(dim=1).mean()
        name = "independent_ce"
    else:
        if candidates is None:
            candidates = enumerate_counts(c.shape[1], b.shape[-1] - 1)
        cand = candidates.to(device)
        matching = (cand[None] == c[:, None]).all(dim=-1)
        if not bool((matching.sum(dim=1) == 1).all()):
            raise ValueError("Each target must occur exactly once in the legal candidate space")
        target = matching.long().argmax(dim=1)
        core = F.cross_entropy(joint_scores(a, b, cand, lambda_occ), target)
        name = "joint_nll"
    occ_loss = F.cross_entropy(b.float(), occupancy) if method != "b2" else core.new_zeros(())
    total = core + float(eta) * occ_loss
    return total, {"supervised": float(total.detach()), name: float(core.detach()), "occupancy_ce": float(occ_loss.detach())}


def decode(
    outputs: dict[str, Tensor],
    method: str = "ours",
    candidates: Tensor | None = None,
    lambda_occ: float = 1.0,
    project_regression: bool = False,
) -> Tensor:
    """Predict integer counts without ground-truth occupancy or compositions."""
    method = _method(method)
    if method == "b1":
        continuous = outputs["regression"].float().clamp_min(0)
        if not project_regression:
            return torch.floor(continuous + 0.5).long()
        if candidates is None:
            if "b" not in outputs:
                raise ValueError("Supply candidates when regression outputs omit the occupancy head")
            candidates = enumerate_counts(continuous.shape[1], outputs["b"].shape[-1] - 1)
        candidates = candidates.to(device=continuous.device, dtype=torch.long)
        distances = ((continuous[:, None] - candidates[None].float()) ** 2).sum(dim=-1)
        return candidates[distances.argmin(dim=1)]
    if method == "b2":
        return outputs["a"].argmax(dim=-1)
    a, b = outputs["a"], outputs["b"]
    if candidates is None:
        candidates = enumerate_counts(a.shape[1], b.shape[-1] - 1)
    candidates = candidates.to(device=a.device, dtype=torch.long)
    return candidates[joint_scores(a, b, candidates, lambda_occ).argmax(dim=1)]
