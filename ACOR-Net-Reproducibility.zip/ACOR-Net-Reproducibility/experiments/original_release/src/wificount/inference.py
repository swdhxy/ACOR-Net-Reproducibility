"""No-label inference and strict external prediction scoring."""
from __future__ import annotations

import csv
import json
from pathlib import Path
import numpy as np
import torch

from .data import ACTIONS, WaveformStore, read_manifest
from .engine import build_model, device_for, decode_outputs, seed_all
from .objectives import enumerate_counts
from .metrics import evaluate_counts


def predict_file(checkpoint, amplitude_path, layout="auto", device="auto"):
    checkpoint=torch.load(checkpoint,map_location="cpu",weights_only=True)
    cfg=checkpoint["config"];dev=device_for(device)
    seed_all(cfg["model_seed"],cfg["deterministic"],cfg["threads"])
    p=Path(amplitude_path).resolve()
    if p.suffix.lower() not in (".npy",".npz"): raise ValueError("Provide a .npy/.npz amplitude array")
    store=WaveformStore(p.parent,layout=layout,max_length=cfg["max_length"])
    amplitude,valid=store.load_file(p)
    stats=checkpoint["stats"]
    x=np.log1p(amplitude.astype(np.float64))
    x=(x-np.asarray(stats["mean"])[:,None])/np.asarray(stats["std"])[:,None]
    x[:,~valid]=0
    model=build_model(cfg,initialize_pretrained=False).to(dev);model.load_state_dict(checkpoint["model"]);model.eval()
    with torch.inference_mode():
        potentials=model.predict_potentials(torch.from_numpy(x.astype(np.float32))[None].to(dev),torch.from_numpy(valid)[None].to(dev))
        candidates=enumerate_counts(K=9,M=cfg["model"]["max_occupancy"]).to(dev)
        count=decode_outputs(potentials,cfg,candidates)[0].cpu().tolist()
    return {"input":str(p),"action_order":list(ACTIONS),"counts":count,"occupancy":sum(count),
            "labels_or_identity_used":False,"checkpoint_epoch":checkpoint["epoch"]+1}


def score_external(manifest_path, predictions_path, partition="test_unseen"):
    records=[r for r in read_manifest(manifest_path,max_occupancy=None) if r["partition"]==partition]
    if not records: raise ValueError("No records for requested partition")
    with Path(predictions_path).open(encoding="utf-8-sig",newline="") as f: supplied=list(csv.DictReader(f))
    ids=[r["record_id"] for r in supplied]
    if len(set(ids))!=len(ids) or set(ids)!={r["record_id"] for r in records}:
        raise ValueError("External predictions must cover exactly all partition record IDs, once each")
    table={r["record_id"]:r for r in supplied}
    prediction=[]
    for record in records:
        row=table[record["record_id"]]
        values=json.loads(row["pred"]) if "pred" in row else [int(row[f"pred_{k}"]) for k in ACTIONS]
        prediction.append(values)
    return evaluate_counts([r["counts"] for r in records],prediction,records,max_occupancy=max(3,max(r["n"] for r in records)))
