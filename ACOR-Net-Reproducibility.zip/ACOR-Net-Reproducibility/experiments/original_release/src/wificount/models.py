"""Label-free masked TCN for per-activity people counting.

The validity mask describes real input samples, not observed zero amplitudes.
No participant, activity, environment, or occupancy labels enter this model.
"""

from __future__ import annotations

import torch
from torch import Tensor, nn
from torch.nn import functional as F


class ChannelLayerNorm(nn.Module):
    """Normalize channels separately at every time position."""

    def __init__(self, channels: int):
        super().__init__()
        self.norm = nn.LayerNorm(channels)

    def forward(self, x: Tensor) -> Tensor:
        return self.norm(x.transpose(1, 2)).transpose(1, 2)


def _masked(x: Tensor, valid: Tensor) -> Tensor:
    # masked_fill also removes NaN/Inf confined to padding positions.
    return x.masked_fill(~valid[:, None, :], 0.0)


class MaskedResidualBlock(nn.Module):
    def __init__(self, channels: int, dilation: int, dropout: float):
        super().__init__()
        self.convs = nn.ModuleList([
            nn.Conv1d(channels, channels, 5, padding=2 * dilation, dilation=dilation)
            for _ in range(2)
        ])
        self.norms = nn.ModuleList([ChannelLayerNorm(channels) for _ in range(2)])
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: Tensor, valid: Tensor) -> Tensor:
        residual = _masked(x, valid)
        for conv, norm in zip(self.convs, self.norms):
            x = _masked(conv(_masked(x, valid)), valid)
            x = _masked(norm(x), valid)
            x = _masked(F.gelu(x), valid)
        return _masked(residual + self.dropout(x), valid)


class CountingModel(nn.Module):
    """Default architecture follows the frozen v2 design.

    ``forward`` includes training-only contrast projections ``p``. Inference
    should call ``predict_potentials``; that path never evaluates the projection
    network. ``channels``, ``dilations`` and ``stem_stride`` can be reduced for
    CPU smoke tests; changing them in a research run changes the architecture.
    """

    def __init__(
        self,
        max_occupancy: int = 3,
        channels: int = 128,
        dilations: tuple[int, ...] = (1, 2, 4, 8, 16),
        dropout: float = 0.1,
        stem_stride: int = 5,
        regression: bool = False,
        num_actions: int = 9,
        in_channels: int = 270,
    ):
        super().__init__()
        if max_occupancy < 1 or channels < 1 or stem_stride < 1:
            raise ValueError("max_occupancy, channels, and stem_stride must be positive")
        if not dilations or any(d < 1 for d in dilations):
            raise ValueError("dilations must be a nonempty sequence of positive integers")
        self.max_occupancy = int(max_occupancy)
        self.num_actions = int(num_actions)
        self.in_channels = int(in_channels)
        self.regression = regression
        self.stem_stride = int(stem_stride)
        self.stem = nn.Conv1d(in_channels, channels, 9, stride=stem_stride, padding=4)
        self.stem_norm = ChannelLayerNorm(channels)
        self.stem_dropout = nn.Dropout(dropout)
        self.blocks = nn.ModuleList([
            MaskedResidualBlock(channels, d, dropout) for d in dilations
        ])
        self.global_projection = nn.Linear(channels * 2, 128)
        self.activity_embedding = nn.Embedding(num_actions, 32)
        self.activity_mlp = nn.Sequential(
            nn.Linear(160, 128), nn.GELU(), nn.Linear(128, 64)
        )
        self.count_head = nn.Linear(64, 1 if regression else max_occupancy + 1)
        if regression:
            # A shared ReLU regressor can otherwise start entirely negative and
            # receive no gradient. Fixed positive initialization for every B1 run.
            nn.init.zeros_(self.count_head.weight)
            nn.init.constant_(self.count_head.bias, 0.5)
        self.occupancy_head = nn.Linear(128, max_occupancy + 1)
        self.contrast_projection = nn.Sequential(
            nn.Linear(64, 64), nn.GELU(), nn.Linear(64, 32)
        )

    def _encode(self, x: Tensor, valid: Tensor) -> tuple[Tensor, Tensor]:
        if x.ndim != 3 or x.shape[1] != self.in_channels:
            raise ValueError(f"Expected input [B,{self.in_channels},T]; received {tuple(x.shape)}")
        if valid.ndim == 3 and valid.shape[1] == 1:
            valid = valid[:, 0]
        if valid.ndim != 2 or valid.shape != (x.shape[0], x.shape[-1]):
            raise ValueError("valid must have shape [B,T] (or [B,1,T]) matching input")
        if x.shape[0] == 0 or x.shape[-1] == 0:
            raise ValueError("Empty batches and zero-length sequences are unsupported")
        valid = valid.to(device=x.device, dtype=torch.bool)
        if not bool(valid.any(dim=1).all()):
            raise ValueError("Every record must contain at least one valid input sample")
        x = _masked(x, valid)
        if not bool(torch.isfinite(x).all()):
            raise ValueError("Nonfinite valid input: repair or reject during preprocessing")
        stem_valid = F.max_pool1d(
            valid[:, None].float(), kernel_size=9, stride=self.stem_stride, padding=4
        )[:, 0].bool()
        if not bool(stem_valid.any(dim=1).all()):
            raise ValueError("A record has no valid stem outputs")
        x = _masked(self.stem(x), stem_valid)
        x = _masked(self.stem_norm(x), stem_valid)
        x = _masked(F.gelu(x), stem_valid)
        x = _masked(self.stem_dropout(x), stem_valid)
        for block in self.blocks:
            x = block(x, stem_valid)
        if not bool(stem_valid.any(dim=1).all()):
            raise ValueError("A record has no valid positions before pooling")
        mean = x.sum(dim=-1) / stem_valid.sum(dim=-1, keepdim=True).to(x.dtype)
        maximum = x.masked_fill(~stem_valid[:, None], float("-inf")).amax(dim=-1)
        h = self.global_projection(torch.cat((mean, maximum), dim=-1))
        activities = self.activity_embedding.weight[None].expand(x.shape[0], -1, -1)
        h_by_action = h[:, None].expand(-1, self.num_actions, -1)
        z = self.activity_mlp(torch.cat((h_by_action, activities), dim=-1))
        return h, z

    def _potentials(self, h: Tensor, z: Tensor) -> dict[str, Tensor]:
        result = {"b": self.occupancy_head(h)}
        if self.regression:
            result["regression"] = F.relu(self.count_head(z).squeeze(-1))
        else:
            result["a"] = self.count_head(z)
        return result

    def forward(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        h, z = self._encode(x, valid)
        result = self._potentials(h, z)
        result.update(h=h, z=z, p=F.normalize(self.contrast_projection(z), dim=-1, eps=1e-8))
        return result

    def predict_potentials(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        """Compute label-free inference potentials without the contrast head.

        Callers control ``eval()`` and ``torch.inference_mode()`` so this method
        can also be used for gradient-based checks without hidden state changes.
        """
        h, z = self._encode(x, valid)
        return self._potentials(h, z)
