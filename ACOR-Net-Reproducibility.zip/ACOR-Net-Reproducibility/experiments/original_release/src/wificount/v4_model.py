"""Predictive action embeddings with nonnegative regression for V4.

The official ConvNeXt forward preserves pooling before classifier normalization.
Contrastive projections share the action features used by the count heads; the
projection is training-only and is not needed for label-free inference.
"""

from __future__ import annotations

import math

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from .domain_adapters import CSISpatialProjection, _convnext_tiny


def validate_v4_settings(settings: dict) -> None:
    """Reject malformed settings before model creation or objective evaluation."""
    if not isinstance(settings, dict):
        raise ValueError("v4 settings must be a mapping")
    if settings.get("pretrained", True) is not True:
        raise ValueError("V4 requires official pretrained weights; no random fallback")
    mode = settings.get("action_feature_mode", "action_specific")
    if not isinstance(mode, str) or mode not in ("action_specific", "shared"):
        raise ValueError("V4 action_feature_mode must be action_specific or shared")
    for name, default in (("hidden_dim", 64), ("projection_dim", 32), ("resolution", 270)):
        value = settings.get(name, default)
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f"V4 {name} must be a positive integer")
    for name, default in (("dropout", .1), ("warp_probability", .5),
                          ("temperature", 1.), ("lambda_occ", .25),
                          ("occupancy_weight", .25), ("joint_weight", .1),
                          ("backbone_lr_multiplier", .1)):
        raw = settings.get(name, default)
        if isinstance(raw, bool) or not isinstance(raw, (int, float)):
            raise ValueError(f"V4 {name} must be a finite number")
        value = float(raw)
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"V4 {name} must be finite and nonnegative")
        if name in {"temperature", "backbone_lr_multiplier"} and value <= 0:
            raise ValueError(f"V4 {name} must be positive")
        if name == "dropout" and value >= 1:
            raise ValueError("V4 dropout must be in [0,1)")
        if name == "warp_probability" and value > 1:
            raise ValueError("V4 warp_probability must be in [0,1]")


class V4CountingModel(nn.Module):
    """One architecture for ERM and contrast controls, including unused heads.

    Default action-specific features preserve the original V4 state layout.
    The shared ablation keeps the K*D projection, but each count head and the
    contrast projector sees its full vector. It changes the complete action
    feature structure, not only the contrastive loss or a single pooling step.

    An injected vector backbone is reserved for lightweight software tests.
    ``initialize_pretrained=False`` is for strict checkpoint reconstruction;
    production training uses the official pretrained backbone without fallback.
    """

    def __init__(self, *, initialize_pretrained=True, backbone=None, feature_dim=None,
                 hidden_dim=64, projection_dim=32, dropout=.1,
                 warp_probability=.5, resolution=270, length=3000,
                 max_occupancy=3, num_actions=9,
                 action_feature_mode="action_specific"):
        super().__init__()
        validate_v4_settings(dict(hidden_dim=hidden_dim, projection_dim=projection_dim,
                                  dropout=dropout, warp_probability=warp_probability,
                                  resolution=resolution,
                                  action_feature_mode=action_feature_mode))
        if not isinstance(initialize_pretrained, bool):
            raise ValueError("initialize_pretrained must be a boolean")
        for name, value in (("length", length), ("max_occupancy", max_occupancy),
                            ("num_actions", num_actions)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"V4 {name} must be a positive integer")
        self.num_actions, self.max_occupancy = num_actions, max_occupancy
        self.hidden_dim = hidden_dim
        self.action_feature_mode = action_feature_mode
        self.action_feature_dim = (hidden_dim if action_feature_mode == "action_specific"
                                   else num_actions * hidden_dim)
        self.projection = CSISpatialProjection(warp_probability=warp_probability,
                                              length=length, resolution=resolution)
        if backbone is None:
            backbone, feature_dim = _convnext_tiny(initialize_pretrained)
        if isinstance(feature_dim, bool) or not isinstance(feature_dim, int) or feature_dim < 1:
            raise ValueError("V4 backbone requires a positive feature_dim")
        self.backbone, self.feature_dim = backbone, feature_dim
        self.action_features = nn.Sequential(nn.Linear(feature_dim, num_actions * hidden_dim),
                                             nn.GELU(), nn.Dropout(dropout))
        self.count_heads = nn.ModuleList(nn.Linear(self.action_feature_dim, 1) for _ in range(num_actions))
        for head in self.count_heads:
            nn.init.normal_(head.weight, std=.01)
            nn.init.constant_(head.bias, math.log(math.expm1(.5)))
        self.occupancy_head = nn.Linear(feature_dim, max_occupancy + 1)
        self.contrast_projector = nn.Linear(self.action_feature_dim, projection_dim)

    def _encode(self, x: Tensor, valid: Tensor) -> tuple[Tensor, Tensor]:
        h = self.backbone(self.projection(x, valid))
        if h.ndim != 2 or h.shape != (len(x), self.feature_dim):
            raise ValueError("V4 backbone must return [B,feature_dim] vectors")
        flat = self.action_features(h)
        if self.action_feature_mode == "action_specific":
            z = flat.reshape(len(x), self.num_actions, self.hidden_dim)
        else:
            # The complete K*D projection is shared by all action heads. Expand
            # after dropout so the representation is identical across actions.
            z = flat.unsqueeze(1).expand(-1, self.num_actions, -1)
        return h, z

    def _potentials(self, h: Tensor, z: Tensor) -> dict[str, Tensor]:
        raw = torch.cat([head(z[:, k]) for k, head in enumerate(self.count_heads)], dim=1)
        return {"regression": F.softplus(raw.float()), "b": self.occupancy_head(h)}

    def forward(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        h, z = self._encode(x, valid)
        p = F.normalize(self.contrast_projector(z).float(), dim=-1)
        return {**self._potentials(h, z), "h": h, "z": z, "p": p}

    def predict_potentials(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        h, z = self._encode(x, valid)
        return self._potentials(h, z)


def build_v4_model(cfg: dict, initialize_pretrained=True) -> V4CountingModel:
    settings = cfg.get("v4", {})
    validate_v4_settings(settings)
    model = cfg.get("model", {})
    if model.get("in_channels", 270) != 270:
        raise ValueError("V4 spatial projection requires 270 CSI channels")
    allowed = ("hidden_dim", "projection_dim", "dropout", "warp_probability", "resolution",
               "action_feature_mode")
    return V4CountingModel(initialize_pretrained=initialize_pretrained,
                           max_occupancy=model.get("max_occupancy", 3),
                           num_actions=model.get("num_actions", 9),
                           length=cfg.get("max_length", 3000),
                           **{name: settings[name] for name in allowed if name in settings})
