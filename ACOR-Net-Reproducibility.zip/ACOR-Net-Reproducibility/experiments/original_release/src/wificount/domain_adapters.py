"""Source-grounded, explicitly task-adapted WiFi literature comparators.

This is an independent implementation, not vendored upstream code. Exact
provenance, deviations and optional pretrained requirements are documented in
docs/DOMAIN_ADAPTERS.md. Neither comparator consumes identity or true occupancy
at inference. ActivityCounting is a paper-described adaptation; MU-SHOT-Fi
implements its public source-training CNN and permutation-matched objective.
"""

from __future__ import annotations

from functools import lru_cache
from itertools import permutations
from importlib import metadata
import math
from pathlib import Path

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from .objectives import decode, enumerate_counts, supervised_loss


DOMAIN_METHODS = ("activity_counting", "mushot_source")
MUSHOT_COMMIT = "ea634c71039e4a24a49505cfbc537a4ad419c6d8"
CONVNEXT_WEIGHTS_URL = "https://download.pytorch.org/models/convnext_tiny-983f1562.pth"


def domain_provenance(cfg: dict) -> dict:
    """Record exact upstream identity plus actual cached pretrained file hash."""
    if cfg["method"] == "mushot_source":
        return {"kind": "source-only task adaptation", "repository": "https://github.com/AhmedRadwan02/mu-shot-fi",
                "commit": MUSHOT_COMMIT, "source_variant": "WiMANS/SHOTPlus;use_transformer=False",
                "upstream_license": None, "upstream_code_vendored": False}
    if cfg["method"] == "activity_counting":
        from .config import file_hash
        cached = Path(torch.hub.get_dir()) / "checkpoints" / Path(CONVNEXT_WEIGHTS_URL).name
        try:
            vision_version = metadata.version("torchvision")
        except metadata.PackageNotFoundError:
            vision_version = None
        return {"kind": "paper-described task adaptation", "paper": "https://arxiv.org/abs/2604.16572v1",
                "torchvision": vision_version, "weights_enum": "ConvNeXt_Tiny_Weights.IMAGENET1K_V1",
                "weights_url": CONVNEXT_WEIGHTS_URL, "weights_sha256_prefix": "983f1562",
                "cached_weights_sha256": file_hash(cached) if cached.is_file() else None}
    raise ValueError(f"Unknown domain adapter: {cfg['method']}")


def _validated_input(x: Tensor, valid: Tensor, channels: int = 270) -> tuple[Tensor, Tensor]:
    if valid.ndim == 3 and valid.shape[1] == 1:
        valid = valid[:, 0]
    if x.ndim != 3 or x.shape[1] != channels or valid.shape != (x.shape[0], x.shape[2]):
        raise ValueError(f"Expected x=[B,{channels},T] and matching valid=[B,T].")
    if x.shape[0] == 0 or x.shape[-1] == 0:
        raise ValueError("Empty inputs are unsupported.")
    valid = valid.to(device=x.device, dtype=torch.bool)
    if not bool(valid.any(dim=1).all()):
        raise ValueError("Every record must have valid CSI samples.")
    x = x.masked_fill(~valid[:, None], 0)
    if not bool(torch.isfinite(x).all()):
        raise ValueError("Nonfinite CSI at a valid position.")
    return x, valid


def _reflect_to_length(signal: Tensor, length: int) -> Tensor:
    """Right reflection valid even when padding exceeds the original length."""
    original = signal.shape[-1]
    if original >= length:
        return signal[..., :length]
    if original == 1:
        return signal.expand(*signal.shape[:-1], length)
    position = torch.arange(length, device=signal.device) % (2 * (original - 1))
    indices = torch.minimum(position, 2 * (original - 1) - position)
    return signal.index_select(-1, indices)


class CSISpatialProjection(nn.Module):
    """Valid CSI -> [time,feature] -> bicubic270square -> learned RGB.

    Random temporal scaling is training-only. Padding values supplied by the
    loader are never interpreted as observed CSI, and holes in a validity mask
    are rejected rather than silently concatenating discontinuous recordings.
    """

    def __init__(self, warp_probability=0.5, warp_range=(0.95, 1.05), length=3000, resolution=270):
        super().__init__()
        if not 0 <= warp_probability <= 1 or not 0 < warp_range[0] <= warp_range[1]:
            raise ValueError("Invalid temporal warping parameters.")
        if length < 1 or resolution < 1:
            raise ValueError("Projection dimensions must be positive.")
        self.warp_probability = float(warp_probability)
        self.warp_range = tuple(warp_range)
        self.length, self.resolution = int(length), int(resolution)
        self.rgb = nn.Conv2d(1, 3, 1)

    def forward(self, x: Tensor, valid: Tensor) -> Tensor:
        x, valid = _validated_input(x, valid)
        images = []
        for signal, mask in zip(x, valid):
            positions = mask.nonzero(as_tuple=False).flatten()
            if int(positions[-1] - positions[0] + 1) != len(positions):
                raise ValueError("Spatial projection requires one contiguous valid interval.")
            signal = signal[:, positions[0]:positions[-1] + 1]
            if self.training and bool(torch.rand((), device=x.device) < self.warp_probability):
                scale = float(torch.empty((), device=x.device).uniform_(*self.warp_range))
                target_length = max(1, round(signal.shape[-1] * scale))
                signal = F.interpolate(signal[None], size=target_length, mode="linear", align_corners=False)[0]
            signal = _reflect_to_length(signal, self.length)
            image = F.interpolate(signal.T[None, None], size=(self.resolution, self.resolution),
                                  mode="bicubic", align_corners=False, antialias=True)
            images.append(image[0])
        return self.rgb(torch.stack(images))


def _convnext_tiny(initialize_pretrained: bool) -> tuple[nn.Module, int]:
    # Lazy import keeps the main method and MU-SHOT-Fi independent of torchvision.
    try:
        from torchvision.models import ConvNeXt_Tiny_Weights, convnext_tiny
    except (ImportError, RuntimeError) as error:
        raise RuntimeError("ActivityCounting requires torchvision compatible with torch; "
                           "for torch2.6 install torchvision0.21.0 from the same CPU/CUDA wheel index.") from error
    weights = ConvNeXt_Tiny_Weights.IMAGENET1K_V1 if initialize_pretrained else None
    if weights is not None:
        from .config import file_hash
        if weights.url != CONVNEXT_WEIGHTS_URL:
            raise RuntimeError("Unexpected ConvNeXt pretrained URL; use pinned torchvision0.21.0.")
        cached = Path(torch.hub.get_dir()) / "checkpoints" / Path(weights.url).name
        # torch.hub checks hash during download only; verify existing cached
        # files too, before any state deserialization can occur.
        if cached.is_file() and not file_hash(cached).startswith("983f1562"):
            raise RuntimeError("Cached ConvNeXt weights do not match the official SHA256 prefix; replace cache file.")
    try:
        backbone = convnext_tiny(weights=weights)
    except Exception as error:
        raise RuntimeError("Failed to load required ImageNet ConvNeXt-Tiny weights. "
                           "Pre-download/cache the official weights; no random-weight fallback is allowed.") from error
    dimension = backbone.classifier[-1].in_features
    backbone.classifier[-1] = nn.Identity()
    return backbone, dimension


class ActivityCountingAdapter(nn.Module):
    """Paper-described spatial projection + pretrained ConvNeXt + ReLU MSE.

    ``backbone`` injection exists only for lightweight unit tests. Production
    builders always use ConvNeXt-Tiny. ``initialize_pretrained=False`` is solely
    for reconstructing an architecture before strict checkpoint restoration.
    """

    def __init__(self, *, initialize_pretrained=True, backbone=None, feature_dim=None,
                 warp_probability=0.5):
        super().__init__()
        self.projection = CSISpatialProjection(warp_probability=warp_probability)
        if backbone is None:
            backbone, feature_dim = _convnext_tiny(initialize_pretrained)
        elif feature_dim is None or feature_dim < 1:
            raise ValueError("An injected test backbone requires its feature dimension.")
        self.backbone = backbone
        self.head = nn.Linear(int(feature_dim), 9)
        # Positive bias is an explicit adaptation to avoid a permanently dead
        # ReLU head. Do not zero weights: pretrained features get gradients now.
        nn.init.constant_(self.head.bias, 0.5)

    def forward(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        return {"regression": F.relu(self.head(self.backbone(self.projection(x, valid))))}

    def predict_potentials(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        return self(x, valid)


class MUShotSourceAdapter(nn.Module):
    """Public MU-SHOT-Fi default source CNN, independently implemented.

    Six exchangeable slots are retained even for the M=3 study. The original
    source objective already matches slots to the action multiset; no identities
    are necessary. Source-free target adaptation is deliberately outside this
    inductive unseen-composition evaluation protocol.
    """

    def __init__(self, bottleneck_dim=128):
        super().__init__()
        if not isinstance(bottleneck_dim, int) or bottleneck_dim < 1:
            raise ValueError("bottleneck_dim must be positive.")
        self.normalization = nn.ModuleList([nn.BatchNorm2d(c) for c in (1, 32, 64, 128)])
        self.convolutions = nn.ModuleList([
            nn.Conv2d(1, 32, 27, stride=7), nn.Conv2d(32, 64, 15, stride=3),
            nn.Conv2d(64, 128, 7),
        ])
        self.dropout = nn.Dropout(0.2)
        self.bottleneck = nn.Linear(128, bottleneck_dim)
        self.classifier = nn.Linear(bottleneck_dim, 6 * 10)
        for module in self.modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                nn.init.xavier_uniform_(module.weight)
                nn.init.zeros_(module.bias)
            elif isinstance(module, nn.BatchNorm2d):
                nn.init.normal_(module.weight, mean=1, std=0.02)
                nn.init.zeros_(module.bias)

    def forward(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        x, _ = _validated_input(x, valid)
        if x.shape[-1] < 251:
            raise ValueError("MU-SHOT-Fi source CNN needs at least 251 time positions; use max_length=3000.")
        features = x.transpose(1, 2)[:, None]
        for normalizer, convolution in zip(self.normalization, self.convolutions):
            features = self.dropout(F.leaky_relu(convolution(normalizer(features)), negative_slope=0.01))
        features = self.normalization[-1](features).mean(dim=(-2, -1))
        return {"slots": self.classifier(self.bottleneck(features)).reshape(-1, 6, 10)}

    def predict_potentials(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        return self(x, valid)


@lru_cache(maxsize=1)
def _six_permutations() -> Tensor:
    return torch.tensor(list(permutations(range(6))), dtype=torch.long)


def mushot_source_loss(logits: Tensor, counts: Tensor, smoothing=0.2) -> Tensor:
    """Exact 6! assignment by unsmoothed CE, then smoothed CE on that match.

    This is numerically equivalent to minimum-cost Hungarian assignment for six
    slots. Empty has unit weight, as in source training. Duplicate activities
    retain multiplicity, and an empty scene is six empty9 labels, not nothing2.
    """
    if logits.ndim != 3 or logits.shape[1:] != (6, 10) or not bool(torch.isfinite(logits).all()):
        raise ValueError("Expected finite source slot logits [B,6,10].")
    if counts.shape != (logits.shape[0], 9) or not bool(torch.isfinite(counts).all()):
        raise ValueError("Expected finite counts [B,9].")
    if bool((counts < 0).any()) or bool((counts != counts.long()).any()) or bool((counts.sum(1) > 6).any()):
        raise ValueError("Counts must be nonnegative integers with occupancy<=6.")
    if not math.isfinite(smoothing) or not 0 <= smoothing < 1:
        raise ValueError("label smoothing must be in [0,1).")
    labels = []
    for row in counts.detach().cpu().tolist():
        active = [action for action, number in enumerate(row) for _ in range(int(number))]
        labels.append(active + [9] * (6 - len(active)))
    targets = torch.tensor(labels, dtype=torch.long, device=logits.device)
    assignments = targets[:, _six_permutations().to(logits.device)]
    logp = logits.float().log_softmax(-1)
    nll = -logp[:, None].expand(-1, 720, -1, -1).gather(-1, assignments[..., None]).squeeze(-1).mean(-1)
    chosen = nll.detach().argmin(-1)
    matched_nll = nll[torch.arange(len(logits), device=logits.device), chosen]
    smooth_loss = -logp.mean(dim=(-1, -2))
    return ((1 - smoothing) * matched_nll + smoothing * smooth_loss).mean()


def build_domain_adapter(cfg: dict, initialize_pretrained=True) -> nn.Module:
    settings = cfg.get("baseline", {})
    if cfg.get("model", {}).get("in_channels", 270) != 270:
        raise ValueError("These WiMANS adapters require 270 CSI channels.")
    if cfg["method"] == "activity_counting":
        if settings.get("pretrained", True) is not True:
            raise ValueError("ActivityCounting comparator requires pretrained ConvNeXt; no random fallback.")
        return ActivityCountingAdapter(initialize_pretrained=initialize_pretrained,
                                       warp_probability=settings.get("warp_probability", 0.5))
    if cfg["method"] == "mushot_source":
        return MUShotSourceAdapter(bottleneck_dim=settings.get("bottleneck_dim", 128))
    raise ValueError(f"Unknown domain adapter: {cfg['method']}")


def domain_loss(out: dict, counts: Tensor, cfg: dict) -> tuple[Tensor, dict[str, float]]:
    if cfg["method"] == "activity_counting":
        return supervised_loss(out, counts, method="b1")
    if cfg["method"] == "mushot_source":
        loss = mushot_source_loss(out["slots"], counts, cfg.get("baseline", {}).get("label_smoothing", 0.2))
        return loss, {"source_matching_smoothed_ce": float(loss.detach())}
    raise ValueError(f"Unknown domain adapter: {cfg['method']}")


def domain_decode(out: dict, cfg: dict) -> Tensor:
    if cfg["method"] == "activity_counting":
        return decode(out, method="b1", candidates=enumerate_counts(M=cfg["model"]["max_occupancy"]),
                      project_regression=cfg.get("evaluation", {}).get("project_regression", False))
    if cfg["method"] == "mushot_source":
        label = out["slots"].argmax(-1)
        return F.one_hot(label, num_classes=10)[..., :9].sum(dim=1)
    raise ValueError(f"Unknown domain adapter: {cfg['method']}")
