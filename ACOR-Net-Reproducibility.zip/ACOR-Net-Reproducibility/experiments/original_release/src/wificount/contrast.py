"""Count-conditioned contrast with matched anchors, pair budgets and negatives."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from math import isfinite
import random
from typing import Any, Mapping, Sequence

import torch
from torch import Tensor
from torch.nn import functional as F

from .sampling import stable_seed, validate_training_records


@dataclass(frozen=True)
class PairSpec:
    anchor: int
    action: int
    positives: tuple[int, ...]
    negatives: tuple[int, ...]
    group: tuple[int, int, int]


def _draw(indices: Sequence[int], size: int, seed: int) -> tuple[int, ...]:
    if size > len(indices):
        raise ValueError("Requested contrast pair budget exceeds eligible records.")
    return tuple(random.Random(seed).sample(sorted(indices), size))


def _balanced_positive_draw(
    indices: Sequence[int], size: int, meta: Sequence[Mapping[str, Any]], seed: int
) -> tuple[int, ...]:
    """Cycle shuffled compositions, drawing distinct records without replacement."""
    rng = random.Random(seed)
    by_combo: dict[str, list[int]] = defaultdict(list)
    for index in indices:
        by_combo[str(meta[index]["combo_id"])].append(index)
    for values in by_combo.values():
        values.sort()
        rng.shuffle(values)
    result = []
    while len(result) < size:
        combos = sorted(combo for combo, values in by_combo.items() if values)
        if not combos:
            raise ValueError("Insufficient positive candidates.")
        rng.shuffle(combos)
        for combo in combos:
            result.append(by_combo[combo].pop())
            if len(result) == size:
                break
    return tuple(result)


def build_pairs(
    meta: Sequence[Mapping[str, Any]],
    variant: str = "ours",
    seed: int = 11,
    quadruplets: Sequence[Mapping[str, Any]] | None = None,
    max_positives: int = 4,
    max_negatives_per_count: int = 4,
) -> tuple[list[PairSpec], dict[str, Any]]:
    """Return metadata-only pair assignments, which are auditable without a model.

    ``ours`` and ``supcon`` have exactly the same main valid anchors, positive
    counts, selected negatives, and group reduction. SupCon expands its positive
    pool to include same-composition records. ``no_n`` only relaxes occupancy in
    candidate pools, preserving the main valid anchors and pair counts.

    Controlled ``within``, ``cross`` and ``any`` use only designated quadruplet
    anchors, exactly one positive and common negatives. Duplicate (record,action)
    assignments are owned by the first quadruplet, including if its anchor later
    has no valid negative. Never combine both schedules in one contrastive loss.
    """
    if variant not in {"ours", "supcon", "no_n", "within", "cross", "any"}:
        raise ValueError(f"Unknown contrastive variant: {variant}")
    if max_positives < 1 or max_negatives_per_count < 1:
        raise ValueError("Contrastive pair caps must be positive.")
    validate_training_records(meta)
    by_cell: dict[tuple, list[int]] = defaultdict(list)
    for i, record in enumerate(meta):
        by_cell[(str(record["environment"]), str(record["wifi_band"]))].append(i)
    controlled = variant in {"within", "cross", "any"}
    assignments: dict[tuple[int, int], tuple[int, int, tuple[int, int]]] = {}
    duplicate_assignments = 0
    if controlled:
        for qi, quad in enumerate(quadruplets or []):
            members = list(quad["indices"])
            if len(members) != 4 or len(set(members)) != 4 or any(i < 0 or i >= len(meta) for i in members):
                raise ValueError("Each controlled quadruplet needs four distinct batch indices.")
            k, n, r = int(quad["k"]), int(quad["n"]), int(quad["r"])
            if not 0 <= k < 9 or r <= 0:
                raise ValueError("Controlled quadruplets require a positive target action count.")
            reference = meta[members[0]]
            for i in members:
                item = meta[i]
                if (int(item["n"]) != n or int(item["counts"][k]) != r
                    or str(item["environment"]) != str(reference["environment"])
                    or str(item["wifi_band"]) != str(reference["wifi_band"])):
                    raise ValueError("Quadruplet members must share n, k, r, environment and band.")
            combos = [str(meta[i]["combo_id"]) for i in members]
            if not (combos[0] == combos[1] and combos[2] == combos[3] and combos[0] != combos[2]):
                raise ValueError("Quadruplet must contain two distinct records from each of two compositions.")
            # A seeded parity swaps the two cross-composition assignments while
            # each foreign record remains positive for exactly one A/B anchor.
            offset = stable_seed(seed, "quad_cross", qi, tuple(meta[i]["record_id"] for i in members), k) % 2
            for pos, i in enumerate(members):
                key = (i, k)
                if key in assignments:
                    duplicate_assignments += 1
                    continue
                same = members[pos ^ 1]
                other_base = 2 if pos < 2 else 0
                foreign = (members[other_base], members[other_base + 1])
                cross = foreign[((pos % 2) + offset) % 2]
                assignments[key] = (same, cross, foreign)

    specs: list[PairSpec] = []
    positive_anchors = 0
    main_valid = 0
    no_same_combo_candidate = 0
    selected_within = 0
    selected_cross = 0
    excluded_empty = 0
    for i, anchor in enumerate(meta):
        n = int(anchor["n"])
        cell = (str(anchor["environment"]), str(anchor["wifi_band"]))
        neighbors = [j for j in by_cell[cell] if j != i]
        same_n = [j for j in neighbors if int(meta[j]["n"]) == n]
        for k, raw_count in enumerate(anchor["counts"]):
            r = int(raw_count)
            if r <= 0:
                continue
            positive_anchors += 1
            same_count = [j for j in same_n if int(meta[j]["counts"][k]) == r]
            cross_pool = [j for j in same_count if meta[j]["combo_id"] != anchor["combo_id"]]
            negative_pools: dict[int, list[int]] = defaultdict(list)
            for j in same_n:
                q = int(meta[j]["counts"][k])
                if q != r:
                    negative_pools[q].append(j)
            if not cross_pool or not negative_pools:
                if not controlled or (i, k) in assignments:
                    excluded_empty += 1
                continue
            main_valid += 1
            no_same_combo_candidate += int(not any(meta[j]["combo_id"] == anchor["combo_id"] for j in same_count))
            if controlled and (i, k) not in assignments:
                continue
            positive_size = min(max_positives, len(cross_pool))
            positive_seed = stable_seed(seed, anchor["record_id"], k, "positive")
            if controlled:
                same, cross, foreign = assignments[(i, k)]
                if variant == "within":
                    positives = (same,)
                elif variant == "cross":
                    positives = (cross,)
                else:
                    positives = _draw([same, *foreign], 1, positive_seed)
            elif variant == "supcon":
                positives = _balanced_positive_draw(same_count, positive_size, meta, positive_seed)
            elif variant == "no_n":
                expanded = [j for j in neighbors if int(meta[j]["counts"][k]) == r
                            and meta[j]["combo_id"] != anchor["combo_id"]]
                positives = _balanced_positive_draw(expanded, positive_size, meta, positive_seed)
            else:
                positives = _balanced_positive_draw(cross_pool, positive_size, meta, positive_seed)

            negatives: list[int] = []
            for q in sorted(negative_pools):
                pool = negative_pools[q]
                size = min(max_negatives_per_count, len(pool))
                if variant == "no_n":
                    pool = [j for j in neighbors if int(meta[j]["counts"][k]) == q]
                neg_seed = stable_seed(seed, anchor["record_id"], k, "negative", q)
                negatives.extend(_balanced_positive_draw(pool, size, meta, neg_seed))
            within = sum(meta[j]["combo_id"] == anchor["combo_id"] for j in positives)
            selected_within += within
            selected_cross += len(positives) - within
            specs.append(PairSpec(i, k, tuple(positives), tuple(negatives), (n, k, r)))

    groups = Counter(spec.group for spec in specs)
    selected_total = selected_within + selected_cross
    negative_counts = Counter(int(meta[j]["counts"][spec.action]) for spec in specs for j in spec.negatives)
    negative_total = sum(negative_counts.values())
    log = {
        "variant": variant,
        "positive_count_anchors": positive_anchors,
        "main_valid_anchors": main_valid,
        "retained_anchors": len(specs),
        "valid_groups": len(groups),
        "group_anchor_counts": {",".join(map(str, group)): count for group, count in sorted(groups.items())},
        "skipped_empty_positive_or_negative": excluded_empty,
        "designated_anchors": len(assignments) if controlled else None,
        "duplicate_designated_assignments": duplicate_assignments,
        "main_anchors_without_same_combo_positive": no_same_combo_candidate,
        "main_fraction_without_same_combo_positive": no_same_combo_candidate / main_valid if main_valid else None,
        "selected_within_positive_pairs": selected_within,
        "selected_cross_positive_pairs": selected_cross,
        "selected_within_positive_fraction": selected_within / selected_total if selected_total else None,
        "negative_pairs": negative_total,
        "negative_pairs_per_count": {str(q): count for q, count in sorted(negative_counts.items())},
        "zero_count_negative_fraction": negative_counts[0] / negative_total if negative_total else None,
    }
    return specs, log


def contrastive_loss(
    p: Tensor,
    meta: Sequence[Mapping[str, Any]],
    variant: str = "ours",
    seed: int = 11,
    quadruplets: Sequence[Mapping[str, Any]] | None = None,
    temperature: float = 0.1,
    max_positives: int = 4,
    max_negatives_per_count: int = 4,
) -> tuple[Tensor, dict[str, Any]]:
    """Mean positive log probability, then equal means over valid (n,k,r) groups.

    The denominator contains *only selected* positives and negatives. Unselected
    same-count examples never become negatives. All logsumexp work is float32,
    including under autocast. Empty pair batches retain a differentiable zero.
    """
    if p.ndim != 3 or p.shape[0] != len(meta) or p.shape[1] != 9 or p.shape[2] < 1:
        raise ValueError("p must have shape [len(meta), 9, embedding_dimension].")
    if not isfinite(temperature) or temperature <= 0:
        raise ValueError("temperature must be positive.")
    specs, log = build_pairs(meta, variant, seed, quadruplets, max_positives, max_negatives_per_count)
    if not specs:
        return p.float().sum() * 0.0, log
    with torch.autocast(device_type=p.device.type, enabled=False):
        projected = F.normalize(p.float(), dim=-1, eps=1e-8)
        group_losses: dict[tuple, list[Tensor]] = defaultdict(list)
        for spec in specs:
            selected = spec.positives + spec.negatives
            anchor = projected[spec.anchor, spec.action]
            scores = (projected[list(selected), spec.action] * anchor).sum(dim=-1) / temperature
            anchor_loss = torch.logsumexp(scores, dim=0) - scores[:len(spec.positives)].mean()
            group_losses[spec.group].append(anchor_loss)
        loss = torch.stack([torch.stack(values).mean() for values in group_losses.values()]).mean()
    return loss, log
