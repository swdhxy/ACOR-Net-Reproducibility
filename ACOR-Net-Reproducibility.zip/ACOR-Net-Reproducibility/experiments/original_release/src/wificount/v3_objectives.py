"""Legal count likelihood with explicit presence, multiplicity and support.

Support means the number of distinct active actions, not occupancy. Conditional
support adds a learned soft potential and does not exclude repeated actions.
"""

from __future__ import annotations

import math

import torch
from torch import Tensor
from torch.nn import functional as F

from .objectives import enumerate_counts, joint_scores
from .v3_model import validate_v3_settings


def conditional_support_log_probs(d: Tensor, num_actions: int) -> Tensor:
    """log P(q|n,x), normalized over feasible q for each candidate occupancy n."""
    if d.ndim != 3 or d.shape[1] != d.shape[2] or d.shape[1] < 2 or num_actions < 1:
        raise ValueError("Support logits must have shape [B,M+1,M+1], M>=1")
    n = torch.arange(d.shape[1], device=d.device)[:, None]
    q = torch.arange(d.shape[2], device=d.device)[None, :]
    feasible = ((n == 0) & (q == 0)) | ((n > 0) & (q >= 1) & (q <= n) & (q <= num_actions))
    return F.log_softmax(d.float().masked_fill(~feasible[None], -torch.inf), dim=-1)


def asymmetric_presence_loss(logits: Tensor, present: Tensor, gamma_pos=0., gamma_neg=2.) -> Tensor:
    """ASL without probability clipping; reduce easy absent-label domination.

    Focusing weights are differentiable. Stable log-sigmoid avoids log(0) even
    for highly confident logits. Reduction is mean over records and actions.
    """
    if logits.ndim != 2 or logits.numel() == 0 or logits.shape != present.shape:
        raise ValueError("Presence logits/targets must be nonempty [B,K]")
    if any(not math.isfinite(float(v)) or v < 0 for v in (gamma_pos, gamma_neg)):
        raise ValueError("Presence focusing exponents must be finite and nonnegative")
    if not bool(((present == 0) | (present == 1)).all()):
        raise ValueError("Presence targets must be binary")
    logits, y = logits.float(), present.to(device=logits.device, dtype=torch.float32)
    log_pos, log_neg = F.logsigmoid(logits), F.logsigmoid(-logits)
    # log-space focusing avoids 0**(gamma-1) in backward for allowed fractional
    # exponents and saturated sigmoid values, e.g. gamma=.5, logit=1000.
    return -(y * (gamma_pos * log_neg).exp() * log_pos
             + (1 - y) * (gamma_neg * log_pos).exp() * log_neg).mean()


def _candidates(outputs: dict[str, Tensor], candidates: Tensor | None) -> Tensor:
    a, b = outputs["a"], outputs["b"]
    if (a.ndim != 3 or b.ndim != 2 or a.shape[0] != b.shape[0]
            or a.shape[0] < 1 or a.shape[1] < 1 or a.shape[2] != b.shape[1] or a.shape[2] < 2):
        raise ValueError("V3 requires a [B,K,M+1] and b [B,M+1]")
    if candidates is None:
        candidates = enumerate_counts(a.shape[1], a.shape[-1] - 1)
    if (candidates.ndim != 2 or candidates.shape[1] != a.shape[1] or len(candidates) == 0
            or not bool(torch.isfinite(candidates).all()) or bool((candidates < 0).any())
            or bool((candidates != candidates.long()).any())
            or bool((candidates.sum(-1) >= a.shape[-1]).any())):
        raise ValueError("Candidates must be finite nonnegative integer vectors with legal occupancy")
    return candidates.to(device=a.device, dtype=torch.long)


def _settings(cfg: dict) -> tuple[dict, dict]:
    settings, training = cfg.get("v3", {}), cfg.get("training", {})
    validate_v3_settings(settings)
    for name, default in (("eta", .25), ("lambda_occ", 1.)):
        value = training.get(name, default)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError(f"{name} must be finite and nonnegative")
    return settings, training


def v3_joint_scores(outputs: dict[str, Tensor], cfg: dict,
                    candidates: Tensor | None = None) -> Tensor:
    """Score every legal composition without ground-truth counts or occupancy."""
    settings, training = _settings(cfg)
    cand = _candidates(outputs, candidates)
    scores = joint_scores(outputs["a"], outputs["b"], cand, training.get("lambda_occ", 1.))
    weight = settings.get("lambda_support", 1.) if settings.get("use_support", True) else 0.
    if weight:
        if "d" not in outputs or outputs["d"].shape != (len(scores), outputs["b"].shape[1], outputs["b"].shape[1]):
            raise ValueError("Enabled support potential requires compatible d logits")
        log_support = conditional_support_log_probs(outputs["d"], cand.shape[1])
        scores = scores + weight * log_support[:, cand.sum(1), (cand > 0).sum(1)]
    return scores


def decode_v3(outputs: dict[str, Tensor], cfg: dict,
              candidates: Tensor | None = None) -> Tensor:
    cand = _candidates(outputs, candidates)
    return cand[v3_joint_scores(outputs, cfg, cand).argmax(dim=1)]


def v3_supervised_loss(outputs: dict[str, Tensor], counts: Tensor, cfg: dict,
                       candidates: Tensor | None = None) -> tuple[Tensor, dict[str, float]]:
    settings, training = _settings(cfg)
    cand = _candidates(outputs, candidates)
    if (counts.shape != outputs["a"].shape[:2] or counts.numel() == 0
            or not bool(torch.isfinite(counts).all()) or bool((counts < 0).any())
            or bool((counts != counts.long()).any())
            or bool((counts.sum(1) >= outputs["b"].shape[1]).any())):
        raise ValueError("Targets must be finite nonnegative integer counts with legal occupancy")
    counts = counts.to(device=cand.device, dtype=torch.long)
    match = (counts[:, None] == cand[None]).all(dim=-1)
    if not bool((match.sum(-1) == 1).all()):
        raise ValueError("Each target must occur exactly once in the legal candidate space")
    n, q = counts.sum(1), (counts > 0).sum(1)
    joint = F.cross_entropy(v3_joint_scores(outputs, cfg, cand), match.long().argmax(-1))
    occupancy = F.cross_entropy(outputs["b"].float(), n)
    presence = asymmetric_presence_loss(outputs["presence"], counts > 0,
                                        settings.get("gamma_pos", 0.), settings.get("gamma_neg", 2.))
    logits = outputs["multiplicity"].float()
    if logits.shape != (*counts.shape, outputs["a"].shape[-1] - 1):
        raise ValueError("Positive multiplicity logits must have shape [B,K,M]")
    positive = counts > 0
    multiplicity = (F.cross_entropy(logits[positive], counts[positive] - 1)
                    if bool(positive.any()) else logits.sum() * 0.)
    support = joint.new_zeros(())
    support_weight = settings.get("support_ce_weight", .25) if settings.get("use_support", True) else 0.
    if support_weight:
        if "d" not in outputs or outputs["d"].shape != (len(counts), outputs["b"].shape[1], outputs["b"].shape[1]):
            raise ValueError("Enabled support supervision requires compatible d logits")
        log_probs = conditional_support_log_probs(outputs["d"], counts.shape[1])
        support = -log_probs[torch.arange(len(counts), device=counts.device), n, q].mean()
    total = (joint + training.get("eta", .25) * occupancy
             + settings.get("presence_weight", 1.) * presence
             + settings.get("multiplicity_weight", .5) * multiplicity
             + support_weight * support)
    return total, {"supervised": float(total.detach()), "joint_nll": float(joint.detach()),
                   "occupancy_ce": float(occupancy.detach()), "presence_asl": float(presence.detach()),
                   "positive_multiplicity_ce": float(multiplicity.detach()),
                   "conditional_support_ce": float(support.detach()),
                   "positive_action_entries": int(positive.sum().detach()),
                   "support_ce_weight": float(support_weight)}
