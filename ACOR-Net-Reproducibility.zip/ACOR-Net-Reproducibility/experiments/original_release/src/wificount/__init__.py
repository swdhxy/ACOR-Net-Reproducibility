"""WiFi count-composition research; scientific performance requires real data."""

__version__ = "0.1.0"

