"""Isolated development using only records assigned to the original train split.

Internal holdouts are development data, not fresh confirmation data. In
particular this protocol does not undo previous exposure to the V1 test results.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import copy
import csv
import io
import json
import math
from pathlib import Path
import random
import re
import statistics

from .config import deep_update, file_hash, fingerprint, validate_config, write_json
from .data import ACTIONS, read_manifest


PROTOCOL = "development_train_only_v2"
SELECTION = "harmonic_seen_unseen_macro_exact_then_mean_positive_mae_then_earliest"
EXACT = "macro_exact_match_by_complete_composition"
ALLOWED = {"train", "val_seen", "val_unseen", "val_aux"}


def _json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _write_new(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="") as stream:
        stream.write(text)


def _positive_cells(records):
    return {(r["n"], k, count, r["environment"], r["wifi_band"])
            for r in records for k, count in enumerate(r["counts"]) if count > 0}


def _source_train(source):
    rows = read_manifest(source, max_occupancy=None)
    train = [r for r in rows if r["partition"] == "train"]
    if not train or any(r["n"] > 3 for r in train):
        raise ValueError("Development requires original train records with occupancy <=3")
    return train


def _protocol_path(manifest):
    return Path(manifest).with_suffix(".protocol.json")


def make_development_manifest(source_manifest, output, *, seed=271828,
                              unseen_per_occupancy=3, seen_fraction=.2,
                              aux_fraction=.2):
    """Freeze a metadata-only split; no source heldout waveform is accessed.

    Hold out complete multi-action compositions while retaining positive
    count support in each occupancy/environment/band cell. Pure-action anchors
    stay in training. Then hold out whole seen records within each composition,
    environment and band, always leaving at least one training record per cell.
    Singleton cells remain in training and are reported, never duplicated.
    """
    if isinstance(unseen_per_occupancy, bool) or int(unseen_per_occupancy) != unseen_per_occupancy or unseen_per_occupancy < 1:
        raise ValueError("unseen_per_occupancy must be a positive integer")
    if not 0 < seen_fraction < 1 or not 0 < aux_fraction < 1:
        raise ValueError("Development fractions must be in (0,1)")
    source, target = Path(source_manifest).resolve(), Path(output).resolve()
    sidecar = _protocol_path(target)
    if source == target or target.exists() or sidecar.exists():
        raise FileExistsError("Development artifacts are immutable; choose a new output")
    original = _source_train(source)
    by_combo = defaultdict(list)
    for row in original:
        if row["n"] in (2, 3):
            by_combo[(row["n"], row["combo_id"])].append(row)
    rng = random.Random(int(seed))
    chosen = set()
    all_cells = _positive_cells(original)
    for n in (2, 3):
        candidates = sorted(c for c, rows in by_combo.items()
                            if c[0] == n and sum(v > 0 for v in rows[0]["counts"]) > 1)
        rng.shuffle(candidates)
        accepted = 0
        for candidate in candidates:
            proposed = chosen | {candidate}
            remaining = [r for r in original if (r["n"], r["combo_id"]) not in proposed]
            if not all_cells <= _positive_cells(remaining):
                continue
            chosen.add(candidate)
            accepted += 1
            if accepted == unseen_per_occupancy:
                break
        if accepted != unseen_per_occupancy:
            raise ValueError(f"Cannot hold out {unseen_per_occupancy} n={n} compositions while preserving count/background support; selected {accepted}")
    assignments = {}
    strata = defaultdict(list)
    for row in original:
        if (row["n"], row["combo_id"]) in chosen:
            assignments[row["record_id"]] = "val_unseen"
        else:
            strata[(row["n"], row["combo_id"], row["environment"], row["wifi_band"])].append(row)
    singleton_cells = 0
    for key, members in sorted(strata.items()):
        members = sorted(members, key=lambda r: r["record_id"])
        rng.shuffle(members)
        n = key[0]
        fraction = seen_fraction if n >= 2 else aux_fraction
        holdout = min(len(members) - 1, max(1, int(len(members) * fraction))) if len(members) >= 2 else 0
        singleton_cells += len(members) == 1
        for i, row in enumerate(members):
            assignments[row["record_id"]] = ("val_seen" if n >= 2 else "val_aux") if i < holdout else "train"
    assert len(assignments) == len(original)
    with source.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        columns = list(reader.fieldnames)
        raw = [r for r in reader if r["partition"] == "train"]
    for extra in ("source_partition", "development_partition"):
        if extra not in columns:
            columns.append(extra)
    for row in raw:
        p = assignments[row["record_id"]]
        row["partition"] = p
        row["source_partition"] = "train"
        row["development_partition"] = p
        if "combo_partition" in columns:
            row["combo_partition"] = "auxiliary" if int(row["number_of_users"]) <= 1 else ("val_unseen" if p == "val_unseen" else "train_combo")
    raw.sort(key=lambda r: r["record_id"])
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=columns)
    writer.writeheader()
    writer.writerows(raw)
    _write_new(target, buffer.getvalue())
    report = {
        "schema": 1, "protocol": PROTOCOL,
        "source_manifest": str(source), "source_manifest_sha256": file_hash(source),
        "manifest": str(target), "manifest_sha256": file_hash(target),
        "source_training_record_ids_sha256": fingerprint(sorted(assignments)),
        "original_training_records": len(original),
        "partition_counts": dict(Counter(assignments.values())),
        "seed": int(seed), "unseen_per_occupancy": int(unseen_per_occupancy),
        "seen_fraction": seen_fraction, "aux_fraction": aux_fraction,
        "heldout_compositions": [list(c) for c in sorted(chosen)],
        "singleton_background_cells_kept_in_train": singleton_cells,
        "count_background_support_preserved": True,
        "selection": SELECTION, "original_heldout_records_included": 0,
        "capture_session_independence": "UNVERIFIED; this is a record-level development split",
        "scope": "Exploratory development after V1 test review, not a new independent confirmatory test",
    }
    _write_new(sidecar, json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    verify_development_manifest(target, sidecar)
    return {"manifest": str(target), "protocol": str(sidecar), "partition_counts": report["partition_counts"],
            "source_training_records": len(original), "original_heldout_records_included": 0}


def verify_development_manifest(manifest, protocol_path=None):
    """Verify original-train-only membership and unchanged semantic metadata."""
    manifest = Path(manifest).resolve()
    sidecar = Path(protocol_path or _protocol_path(manifest)).resolve()
    report = _json(sidecar)
    if report.get("protocol") != PROTOCOL or report.get("selection") != SELECTION:
        raise ValueError("Unknown development protocol or selection rule")
    if str(manifest) != report["manifest"] or file_hash(manifest) != report["manifest_sha256"]:
        raise ValueError("Development manifest changed")
    source = Path(report["source_manifest"])
    if file_hash(source) != report["source_manifest_sha256"]:
        raise ValueError("Original source manifest changed")
    original = {r["record_id"]: r for r in _source_train(source)}
    rows = read_manifest(manifest)
    ids = {r["record_id"] for r in rows}
    if ids != set(original) or fingerprint(sorted(ids)) != report["source_training_record_ids_sha256"]:
        raise ValueError("Development IDs must cover exactly the original train partition")
    if len(rows) != report["original_training_records"] or dict(Counter(r["partition"] for r in rows)) != report["partition_counts"]:
        raise ValueError("Development record counts changed")
    if not {"train", "val_seen", "val_unseen"} <= {r["partition"] for r in rows}:
        raise ValueError("Development needs nonempty train, val_seen and val_unseen")
    semantic = ("n", "counts", "combo_id", "environment", "wifi_band", "user_group_id")
    for row in rows:
        if row["partition"] not in ALLOWED or row.get("source_partition") != "train" or row.get("development_partition") != row["partition"]:
            raise ValueError("Development contains an undeclared or original heldout assignment")
        if any(row[k] != original[row["record_id"]][k] for k in semantic):
            raise ValueError(f"Development metadata changed: {row['record_id']}")
        # Preserve paths, valid lengths and original provenance columns too.
        for key, value in original[row["record_id"]].items():
            if key.startswith("_") or key in {"partition", "combo_partition", "source_partition", "development_partition"}:
                continue
            if row.get(key) != value:
                raise ValueError(f"Source metadata field changed: {row['record_id']}/{key}")
    train = [r for r in rows if r["partition"] == "train"]
    unseen = [r for r in rows if r["partition"] == "val_unseen"]
    train_combos = {(r["n"], r["combo_id"]) for r in train}
    if train_combos & {(r["n"], r["combo_id"]) for r in unseen}:
        raise ValueError("Development unseen compositions overlap training")
    if not {(r["n"], r["combo_id"]) for r in rows if r["partition"] == "val_seen"} <= train_combos:
        raise ValueError("Development seen composition has no training records")
    if _positive_cells(rows) - _positive_cells(train):
        raise ValueError("Development holdout lost positive count/background support")
    return report


def development_metric_key(unseen_metrics, seen_metrics, epoch):
    """Preregistered joint criterion; never replace a failed split with zero NA."""
    values = []
    for metrics in (unseen_metrics, seen_metrics):
        exact = metrics.get(EXACT)
        mae = metrics.get("positive_count_mae")
        if exact is None or mae is None or not math.isfinite(exact) or not math.isfinite(mae) or not 0 <= exact <= 1 or mae < 0:
            raise ValueError("Development selection requires finite Exact and positive-count MAE for both holdouts")
        values.append((float(exact), float(mae)))
    u, s = values[0][0], values[1][0]
    harmonic = 2 * u * s / (u + s) if u + s else 0.0
    return harmonic, -(values[0][1] + values[1][1]) / 2, -int(epoch)


def _sources():
    return {p.name: file_hash(p) for p in sorted(Path(__file__).parent.glob("*.py"))}


def make_development_plan(base_cfg, manifest, output_root, variants, seeds=(11, 22, 33)):
    """Return a bounded immutable-plan payload; caller saves it with write-once."""
    manifest, root = Path(manifest).resolve(), Path(output_root).resolve()
    sidecar = _protocol_path(manifest)
    protocol = verify_development_manifest(manifest, sidecar)
    if not variants or not seeds or len(seeds) != len(set(seeds)):
        raise ValueError("Need nonempty variants and unique model seeds")
    labels = [v["name"] for v in variants]
    if len(labels) != len(set(labels)) or any(not re.fullmatch(r"[a-z][a-z0-9_]*", s) for s in labels):
        raise ValueError("Variant names must be unique safe lowercase identifiers")
    jobs = []
    for variant in variants:
        for seed in seeds:
            cfg = deep_update(base_cfg, variant.get("overrides", {}))
            cfg.update(manifest=str(manifest), development_protocol=str(sidecar), model_seed=int(seed),
                       output=str(root / "runs" / f"{variant['name']}_m{seed}"), cache_dir=str(root / "cache"))
            validate_config(cfg)
            jobs.append({"id": f"development/{variant['name']}_m{seed}", "variant": variant["name"], "config": cfg})
    result = {"schema": 1, "stage": "development", "protocol": PROTOCOL,
              "manifest": str(manifest), "protocol_path": str(sidecar),
              "protocol_sha256": file_hash(sidecar), "source_manifest_sha256": protocol["source_manifest_sha256"],
              "source_sha256": _sources(), "selection": SELECTION,
              "seeds": list(seeds), "variants": copy.deepcopy(variants),
              "jobs": jobs, "job_count": len(jobs), "plan_fingerprint": fingerprint(jobs),
              "test_execution": False, "original_heldout_records_included": 0}
    result["development_fingerprint"] = fingerprint(result)
    return result


def verify_development_plan(plan):
    if not isinstance(plan, dict):
        plan = _json(plan)
    unsigned = {k: v for k, v in plan.items() if k != "development_fingerprint"}
    if fingerprint(unsigned) != plan.get("development_fingerprint") or fingerprint(plan["jobs"]) != plan["plan_fingerprint"]:
        raise ValueError("Development plan changed; use a new output for an intentional new experiment")
    if plan["protocol"] != PROTOCOL or plan["selection"] != SELECTION or plan["source_sha256"] != _sources():
        raise ValueError("Development source or selection protocol changed")
    if file_hash(plan["protocol_path"]) != plan["protocol_sha256"]:
        raise ValueError("Development split protocol changed")
    verify_development_manifest(plan["manifest"], plan["protocol_path"])
    for job in plan["jobs"]:
        cfg = job["config"]
        if cfg["manifest"] != plan["manifest"] or cfg.get("development_protocol") != plan["protocol_path"]:
            raise ValueError("Development job refers to another manifest/protocol")
    return plan


def run_development_plan(plan, execute=False, max_jobs=None):
    from .experiments import run_plan
    if max_jobs is not None and max_jobs < 1:
        raise ValueError("max_jobs must be positive")
    return run_plan(verify_development_plan(plan), execute=execute, max_jobs=max_jobs)


def summarize_development(plan, output):
    """Summarize both internal holdouts without opening any formal test data."""
    from .engine import provenance, verify_run_provenance, load_predictions
    from .metrics import evaluate_counts
    plan = verify_development_plan(plan)
    destination = Path(output).resolve()
    if destination.exists() and any(destination.iterdir()):
        raise FileExistsError("Development summary output must be new or empty")
    rows = []
    records = read_manifest(plan["manifest"])
    train_records = [r for r in records if r["partition"] == "train"]
    for job in plan["jobs"]:
        cfg, folder = job["config"], Path(job["config"]["output"])
        summary = _json(folder / "training_summary.json")
        completion = _json(folder / "development_best_complete.json")
        if completion["epoch"] != summary["best_epoch"]:
            raise ValueError("Development best epoch disagrees with completion marker")
        for name in ("best.pt", "validation_best.json", "validation_best.csv",
                     "validation_seen_best.json", "validation_seen_best.csv"):
            if file_hash(folder/name) != completion["sha256"].get(name):
                raise ValueError(f"Development best artifact changed: {job['id']}/{name}")
        if _json(folder / "config.json") != cfg:
            raise ValueError(f"Saved configuration differs from plan: {job['id']}")
        verify_run_provenance(_json(folder / "provenance.json"), provenance(cfg), job["id"])
        metrics = {}
        for partition, stem in (("val_unseen", "validation_best"), ("val_seen", "validation_seen_best")):
            saved = _json(folder / f"{stem}.json")
            predictions = load_predictions(folder / f"{stem}.csv")
            expected = {r["record_id"]: r for r in records if r["partition"] == partition}
            if len(predictions) != len(expected) or {r["record_id"] for r in predictions} != set(expected):
                raise ValueError(f"Development prediction coverage mismatch: {job['id']}/{partition}")
            for r in predictions:
                if r["partition"] != partition or r["truth"] != expected[r["record_id"]]["counts"] or r["model_seed"] != cfg["model_seed"]:
                    raise ValueError("Development prediction metadata mismatch")
            fresh = evaluate_counts([r["truth"] for r in predictions], [r["pred"] for r in predictions],
                                    [expected[r["record_id"]] for r in predictions],
                                    max_occupancy=3, train_context_records=train_records)
            for key in (EXACT, "positive_count_mae", "sample_exact_match", "multiset_micro_f1", "occupancy_accuracy"):
                if not math.isclose(saved[key], fresh[key], rel_tol=1e-10, abs_tol=1e-12):
                    raise ValueError(f"Development saved metric mismatch: {job['id']}/{partition}/{key}")
            metrics[partition] = fresh
        key = development_metric_key(metrics["val_unseen"], metrics["val_seen"], summary["best_epoch"] - 1)
        if not all(math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-12)
                   for a,b in zip(key,completion["selection_key"])):
            raise ValueError("Development selection disagrees with completion marker")
        row = {"job": job["id"], "variant": job["variant"], "model_seed": cfg["model_seed"],
               "best_epoch": summary["best_epoch"], "joint_score": key[0], "mean_positive_mae": -key[1],
               "checkpoint_sha256": file_hash(folder / "best.pt")}
        for partition, values in metrics.items():
            for metric in (EXACT, "sample_exact_match", "positive_count_mae", "multiset_micro_f1", "occupancy_accuracy"):
                row[f"{partition}/{metric}"] = values[metric]
        rows.append(row)
    grouped = []
    numeric = [k for k in rows[0] if k not in {"job", "variant", "model_seed", "best_epoch", "checkpoint_sha256"}]
    for variant in [v["name"] for v in plan["variants"]]:
        group = [r for r in rows if r["variant"] == variant]
        if sorted(r["model_seed"] for r in group) != sorted(plan["seeds"]):
            raise ValueError("Development variant lacks paired seed coverage")
        grouped.append({"variant": variant, "seeds": [r["model_seed"] for r in group],
                        "metrics": {k: {"mean": statistics.mean(r[k] for r in group),
                                        "seed_sd": statistics.stdev(r[k] for r in group) if len(group) > 1 else None}
                                    for k in numeric}})
    ranking = sorted(grouped, key=lambda r: (-r["metrics"]["joint_score"]["mean"], r["metrics"]["mean_positive_mae"]["mean"], r["variant"]))
    result = {"schema": 1, "scope": "Exploratory, original-train-only development; no original formal heldout inference",
              "plan_fingerprint": plan["development_fingerprint"], "selection": SELECTION,
              "jobs": len(rows), "rows": rows, "by_variant": grouped,
              "ranking": [r["variant"] for r in ranking], "test_evaluated": False,
              "note": "Seed SD is optimization variability, not independent-person or session uncertainty. A development winner does not establish improvement on a fresh test."}
    destination.mkdir(parents=True, exist_ok=True)
    write_json(destination / "development_summary.json", result)
    with (destination / "development_runs.csv").open("x", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return {"output": str(destination), "jobs": len(rows), "ranking": result["ranking"], "test_evaluated": False}
