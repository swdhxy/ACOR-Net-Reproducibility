"""Freeze completed runs, open held-out evaluation explicitly, export tables."""
from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from .config import file_hash, fingerprint, write_json


METRICS = ("macro_exact_match_by_complete_composition", "sample_exact_match", "positive_count_mae",
           "all_count_mae", "zero_count_false_positive_rate", "multiset_micro_f1",
           "occupancy_accuracy", "occupancy_mae", "occupancy_macro_f1", "illegal_rate",
           "balanced_occupancy_macro_exact")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def load_plans(paths):
    jobs = []
    ids = set()
    for path in paths:
        plan = read_json(path)
        if plan["stage"] == "search":
            raise ValueError("Test evaluation accepts selected core/ablation plans, never all search candidates")
        if fingerprint(plan["jobs"]) != plan["plan_fingerprint"]:
            raise ValueError(f"Modified plan: {path}")
        for job in plan["jobs"]:
            if job["id"] in ids:
                raise ValueError(f"Duplicate job across plans: {job['id']}")
            ids.add(job["id"])
            jobs.append(job)
    if not jobs:
        raise ValueError("Empty plans")
    return jobs


def _checkpoints(job):
    return ("best", "last") if job["config"]["training"].get("diagnostic") is not None else ("best",)


def _bind_audit(cfg, item):
    from .data import read_manifest, WaveformStore
    audit = read_json(item["path"])
    store = WaveformStore(cfg["data_root"], cfg.get("data_index"), layout=cfg["layout"], max_length=cfg["max_length"])
    if audit["preprocessing"] != store.preprocessing_spec():
        raise ValueError("Waveform audit preprocessing/index differs from training configuration")
    with Path(item["waveform_csv"]).open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    table = {r["record_id"]: r for r in rows}
    required = read_manifest(cfg["manifest"], max_occupancy=cfg["model"]["max_occupancy"])
    if len(table) != len(rows) or set(table) != {r["record_id"] for r in required}:
        raise ValueError("Waveform audit must cover exactly the complete train/evaluation scope")
    for record in required:
        audited = table[record["record_id"]]
        if audited["status"] != "PASS" or Path(audited["path"]).resolve() != store.resolve_path(record):
            raise ValueError(f"Audit refers to different data files: {record['record_id']}")
        if audited["partition"] != record["partition"] or audited["combo_id"] != record["combo_id"]:
            raise ValueError("Audit record metadata differs from manifest")


def freeze_runs(plan_paths, audit_paths, output):
    """No test inference here. Metadata labels are used only for protocol checks."""
    from .engine import provenance, verify_runtime
    if Path(output).exists():
        raise FileExistsError("Freeze file exists; keep it immutable or choose a new protocol version")
    jobs = load_plans(plan_paths)
    audits = {}
    for path in audit_paths:
        audit = read_json(path)
        if not audit.get("ok") or not audit.get("waveforms_verified") or audit.get("metadata_only"):
            raise ValueError(f"Full waveform audit has not passed: {path}")
        csv_path = Path(path).with_name("waveform_audit.csv")
        if not csv_path.exists():
            raise FileNotFoundError(csv_path)
        audits[audit["manifest_sha256"]] = {"path": str(Path(path).resolve()), "sha256": file_hash(path),
            "waveform_csv": str(csv_path.resolve()), "waveform_csv_sha256": file_hash(csv_path)}
    frozen_jobs = {}
    bound = set()
    for job in jobs:
        cfg = job["config"]
        folder = Path(cfg["output"])
        if not (folder / "training_summary.json").exists():
            raise FileNotFoundError(f"Training incomplete: {job['id']}")
        if read_json(folder / "config.json") != cfg:
            raise ValueError(f"Completed config differs from plan: {job['id']}")
        prov = read_json(folder / "provenance.json")
        current = provenance(cfg)
        if prov["manifest_sha256"] != current["manifest_sha256"] or prov["source_sha256"] != current["source_sha256"]:
            raise ValueError(f"Code/manifest changed since training: {job['id']}")
        runtime = verify_runtime(prov, current, f"Freeze {job['id']}")
        if current["manifest_sha256"] not in audits:
            raise ValueError(f"No passed full-data audit for {cfg['manifest']}")
        binding_key = fingerprint({k: cfg.get(k) for k in ("manifest", "data_root", "data_index", "layout", "max_length", "model")})
        if binding_key not in bound:
            _bind_audit(cfg, audits[current["manifest_sha256"]])
            bound.add(binding_key)
        # Freeze must happen before opening test for this selected run.
        if any(folder.glob("evaluation_test*")):
            raise ValueError(f"Test evaluation already exists before freeze: {folder}")
        frozen_jobs[job["id"]] = {"config_sha256": fingerprint(cfg), "manifest_sha256": current["manifest_sha256"],
            "source_sha256": current["source_sha256"],
            "runtime": runtime, "training_provenance_sha256": file_hash(folder / "provenance.json"),
            "checkpoints": {name: file_hash(folder / f"{name}.pt") for name in _checkpoints(job)},
            "normalization_sha256": file_hash(folder / "normalization.json")}
    result = {"schema": 2, "status": "FROZEN_BEFORE_TEST", "test_used_for_selection": False,
              "plans": {str(Path(p).resolve()): file_hash(p) for p in plan_paths}, "audits": audits,
              "jobs": frozen_jobs, "note": "Immutable provenance record; does not prove tests were never read outside this program."}
    write_json(output, result)
    return {"freeze": str(output), "jobs": len(jobs), "audited_manifests": len(audits), "test_evaluated": False}


def verify_freeze(plan_paths, freeze_path, verify_waveforms=True):
    from .engine import provenance, verify_runtime
    jobs = load_plans(plan_paths)
    frozen = read_json(freeze_path)
    if frozen.get("schema") != 2:
        raise ValueError("Freeze lacks the runtime binding required by schema 2; do not replace an already tested protocol")
    expected_plans = {str(Path(p).resolve()): file_hash(p) for p in plan_paths}
    if frozen["plans"] != expected_plans or set(frozen["jobs"]) != {j["id"] for j in jobs}:
        raise ValueError("Plan set changed after freeze")
    checked_files = {}
    for item in frozen["audits"].values():
        if file_hash(item["path"]) != item["sha256"] or file_hash(item["waveform_csv"]) != item["waveform_csv_sha256"]:
            raise ValueError("Audit files changed after freeze")
        if verify_waveforms:
            with Path(item["waveform_csv"]).open(encoding="utf-8-sig", newline="") as stream:
                for row in csv.DictReader(stream):
                    path = row["path"]
                    if path not in checked_files:
                        checked_files[path] = file_hash(path)
                    if checked_files[path] != row["file_sha256"]:
                        raise ValueError(f"Waveform changed since audit: {path}")
    bound = set()
    for job in jobs:
        cfg = job["config"]
        item = frozen["jobs"][job["id"]]
        folder = Path(cfg["output"])
        prov = provenance(cfg)
        if fingerprint(cfg) != item["config_sha256"] or prov["manifest_sha256"] != item["manifest_sha256"]:
            raise ValueError(f"Configuration/manifest changed after freeze: {job['id']}")
        if prov["source_sha256"] != item["source_sha256"]:
            raise ValueError("Code changed after freeze; do not tune after seeing held-out results")
        verify_runtime(item["runtime"], prov, f"Frozen run {job['id']}")
        if file_hash(folder / "provenance.json") != item["training_provenance_sha256"]:
            raise ValueError("Training provenance changed after freeze")
        binding_key = fingerprint({k: cfg.get(k) for k in ("manifest", "data_root", "data_index", "layout", "max_length", "model")})
        if binding_key not in bound:
            _bind_audit(cfg, frozen["audits"][item["manifest_sha256"]])
            bound.add(binding_key)
        if file_hash(folder / "normalization.json") != item["normalization_sha256"]:
            raise ValueError("Normalization artifact changed")
        for name, digest in item["checkpoints"].items():
            if file_hash(folder / f"{name}.pt") != digest:
                raise ValueError(f"Checkpoint changed after freeze: {job['id']}:{name}")
    return jobs, frozen


def verify_evaluation(folder, checkpoint, *, partition=None, cfg=None, runtime=None):
    from .data import read_manifest
    from .engine import load_predictions
    folder = Path(folder)
    marker = folder / "evaluation_complete.json"
    if not marker.exists():
        raise ValueError(f"Incomplete evaluation at {folder}; preserve for diagnosis and move it out before retrying")
    hashes = read_json(marker)
    required = {"metrics.json", "predictions.csv", "evaluation_provenance.json"}
    if not isinstance(hashes, dict) or set(hashes) != required:
        raise ValueError("Evaluation completion marker must cover all required artifacts")
    for name, digest in hashes.items():
        if file_hash(folder / name) != digest:
            raise ValueError(f"Evaluation artifact changed: {folder / name}")
    provenance = read_json(folder / "evaluation_provenance.json")
    if provenance["checkpoint_sha256"] != file_hash(checkpoint):
        raise ValueError("Existing evaluation is from a different checkpoint")
    if partition is not None and provenance.get("partition") != partition:
        raise ValueError("Existing evaluation is from a different partition")
    if runtime is not None:
        from .engine import verify_runtime
        verify_runtime(runtime, provenance.get("training_provenance", {}), "Evaluation training")
        verify_runtime(runtime, provenance.get("evaluation_provenance", {}), "Existing evaluation")
    if cfg is not None:
        if partition is None:
            raise ValueError("Expected partition is required for cohort validation")
        records = [r for r in read_manifest(cfg["manifest"], max_occupancy=cfg["model"]["max_occupancy"])
                   if r["partition"] == partition]
        expected = {r["record_id"]: r for r in records}
        rows = load_predictions(folder / "predictions.csv")
        ids = [r["record_id"] for r in rows]
        if not expected or len(ids) != len(set(ids)) or set(ids) != set(expected):
            raise ValueError("Evaluation predictions do not exactly cover the expected partition records")
        for row in rows:
            if row.get("partition") != partition or row["truth"] != expected[row["record_id"]]["counts"]:
                raise ValueError("Evaluation record partition/ground truth differs from the frozen manifest")
            if any(row.get(k) != cfg[k] for k in ("split_seed", "model_seed", "method")):
                raise ValueError("Evaluation record split, initialization, or method differs from the plan")
        sample_count = read_json(folder / "metrics.json")["denominators_and_numerators"]["samples"]
        if sample_count != len(expected):
            raise ValueError("Evaluation metric sample count differs from the expected partition")


def evaluate_plans(plan_paths, freeze_path, device="auto"):
    from .engine import evaluate
    jobs, frozen = verify_freeze(plan_paths, freeze_path)
    results = []
    for job in jobs:
        folder = Path(job["config"]["output"])
        for name in _checkpoints(job):
            for partition in ("test_unseen", "test_seen", "test_aux"):
                destination = folder / f"evaluation_{partition}{'_last' if name == 'last' else ''}"
                checkpoint = folder / f"{name}.pt"
                if destination.exists():
                    verify_evaluation(destination, checkpoint, partition=partition, cfg=job["config"],
                                      runtime=frozen["jobs"][job["id"]]["runtime"])
                    status = "reused_verified"
                else:
                    evaluate(checkpoint, partition, destination, device=device)
                    status = "evaluated"
                results.append({"job": job["id"], "checkpoint": name, "partition": partition, "status": status})
                print(f"{status}: {job['id']} {name} {partition}", flush=True)
    write_json(Path(freeze_path).with_name("evaluation_index.json"), {"freeze_sha256": file_hash(freeze_path), "evaluations": results})
    return {"evaluations": len(results), "jobs": len(jobs)}


def _csv(path, rows):
    if not rows:
        raise ValueError(f"No rows for {path}")
    with Path(path).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def summarize_plans(plan_paths, output, freeze_path=None):
    from .engine import load_predictions
    from .metrics import paired_bootstrap
    if freeze_path is not None:
        jobs, frozen = verify_freeze(plan_paths, freeze_path)
    else:
        jobs, frozen = load_plans(plan_paths), None
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    rows, primary = [], defaultdict(list)
    for job in jobs:
        cfg = job["config"]
        folder = Path(cfg["output"])
        for name in _checkpoints(job):
            for partition in ("test_unseen", "test_seen", "test_aux"):
                destination = folder / f"evaluation_{partition}{'_last' if name == 'last' else ''}"
                verify_evaluation(destination, folder / f"{name}.pt", partition=partition, cfg=cfg,
                                  runtime=frozen["jobs"][job["id"]]["runtime"] if frozen else None)
                m = read_json(destination / "metrics.json")
                label = job["id"].split("/")[-1].rsplit("_s", 1)[0]
                rows.append({"job": job["id"], "family": job["id"].split("/")[0], "label": label,
                             "split_seed": cfg["split_seed"], "model_seed": cfg["model_seed"], "checkpoint": name,
                             "partition": partition, "records": m["denominators_and_numerators"]["samples"],
                             **{key: m[key] for key in METRICS}})
                if job["id"].startswith("core/") and name == "best" and partition == "test_unseen":
                    primary[cfg["method"]].extend(load_predictions(destination / "predictions.csv"))
    _csv(output / "runs.csv", rows)
    grouped = defaultdict(list)
    keys = ("family", "label", "split_seed", "checkpoint", "partition")
    for row in rows:
        grouped[tuple(row[k] for k in keys)].append(row)
    summaries = []
    for group, values in sorted(grouped.items()):
        row = dict(zip(keys, group))
        row["initializations"] = len(values)
        for metric in METRICS:
            available = [v[metric] for v in values if v[metric] is not None]
            row[f"{metric}_mean"] = float(np.mean(available)) if available else None
            row[f"{metric}_sd"] = float(np.std(available, ddof=1)) if len(available) > 1 else None
        summaries.append(row)
    _csv(output / "summary.csv", summaries)
    comparisons = []
    if "ours" in primary:
        for baseline in ("b4", "b5"):
            if baseline in primary:
                result = paired_bootstrap(primary["ours"], primary[baseline])
                filename = f"paired_bootstrap_ours_vs_{baseline}.json"
                write_json(output / filename, result)
                comparisons.append(filename)
    result = {"jobs": len(jobs), "evaluation_rows": len(rows), "summary_rows": len(summaries),
              "freeze_verified": frozen is not None,
              "freeze_sha256": file_hash(freeze_path) if freeze_path is not None else None,
              "comparisons": comparisons, "scope": "Per split; SD is across model initializations, not independent subject/session replications.",
              "provenance": {str(Path(p).resolve()): file_hash(p) for p in plan_paths}}
    write_json(output / "summary.json", result)
    return result
