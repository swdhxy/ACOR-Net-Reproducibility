"""Training and held-out evaluation. Training never evaluates test partitions."""
from __future__ import annotations

import csv
import dataclasses
import json
import math
import os
import platform
from importlib.metadata import version, PackageNotFoundError
import random
import subprocess
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from .config import file_hash, fingerprint, write_json
from .data import read_manifest, WaveformStore, fit_normalization, validate_normalization, CSIDataset, collate_records
from .models import CountingModel
from .objectives import enumerate_counts, supervised_loss, decode
from .metrics import evaluate_counts
from .sampling import make_epoch_plans
from .contrast import contrastive_loss


def seed_all(seed, deterministic=True, threads=4):
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(deterministic)
    torch.backends.cudnn.benchmark = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    if deterministic:
        # Avoid hardware-dependent fused attention backward paths in the
        # optional query comparator. Sequence lengths here are small.
        torch.backends.cuda.enable_flash_sdp(False)
        torch.backends.cuda.enable_mem_efficient_sdp(False)
        torch.backends.cuda.enable_math_sdp(True)


def device_for(name):
    if name == "auto":
        name = "cuda" if torch.cuda.is_available() else "cpu"
    if str(name).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; install the CUDA PyTorch build or use --device cpu")
    return torch.device(name)


def build_model(cfg, initialize_pretrained=True):
    if cfg["method"] == "ours_v4":
        from .v4_model import build_v4_model
        return build_v4_model(cfg, initialize_pretrained=initialize_pretrained)
    if cfg["method"] == "ours_v3":
        from .v3_model import build_v3_model
        return build_v3_model(cfg, initialize_pretrained=initialize_pretrained)
    if cfg["method"] == "ours_v2":
        from .v2_model import build_v2_model
        return build_v2_model(cfg, initialize_pretrained=initialize_pretrained)
    if cfg["method"] == "amar":
        from .amar import build_amar
        return build_amar(cfg)
    if cfg["method"] in ("mushot_source", "activity_counting"):
        from .domain_adapters import build_domain_adapter
        return build_domain_adapter(cfg, initialize_pretrained=initialize_pretrained)
    if cfg["method"] in ("set_transformer", "activity_cnn"):
        from .baselines import build_baseline
        return build_baseline(cfg)
    return CountingModel(**cfg["model"], regression=cfg["method"] == "b1")


def prepare_data(cfg, stats=None):
    development = bool(cfg.get("development_protocol"))
    if development:
        from .development import verify_development_manifest
        verify_development_manifest(cfg["manifest"], cfg["development_protocol"])
    records = read_manifest(cfg["manifest"], max_occupancy=cfg["model"]["max_occupancy"])
    from .audit import audit_metadata
    metadata_check = audit_metadata(records, no_aux=cfg["no_aux"], development=development)
    if not metadata_check["ok"]:
        raise ValueError("Invalid experimental partition: " + "; ".join(metadata_check["errors"]))
    train = [r for r in records if r["partition"] == "train" and (not cfg["no_aux"] or r["n"] >= 2)]
    val = [r for r in records if r["partition"] == "val_unseen"]
    if not train or not val:
        raise ValueError("Need nonempty train and val_unseen partitions")
    store = WaveformStore(cfg["data_root"], index_path=cfg.get("data_index"),
                          layout=cfg["layout"], max_length=cfg["max_length"])
    if stats is None:
        key = fingerprint({"manifest": file_hash(cfg["manifest"]), "no_aux": cfg["no_aux"],
                           "data_root": cfg["data_root"], "layout": cfg["layout"], "max_length":cfg["max_length"],
                           "index": file_hash(cfg["data_index"]) if cfg.get("data_index") else None})[:20]
        stats_path = Path(cfg["cache_dir"]) / "normalization" / f"{key}.json"
        if stats_path.exists():
            stats = json.loads(stats_path.read_text(encoding="utf-8"))
        else:
            print("Computing normalization from TRAIN valid points only...", flush=True)
            stats = fit_normalization(train, store, stats_path)
    validate_normalization(stats, train, store, verify_files=True)
    train_ds = CSIDataset(train, store, stats, expected_train_records=train)
    val_ds = CSIDataset(val, store, stats, expected_train_records=train)
    return records, train, train_ds, val_ds, store, stats


def predictions(model, dataset, cfg, device, candidates, train_records=None):
    loader = DataLoader(dataset, batch_size=cfg["evaluation"]["batch_size"], shuffle=False,
                        num_workers=cfg["workers"], collate_fn=collate_records)
    model.eval()
    truth, pred, metas = [], [], []
    with torch.inference_mode():
        for batch in loader:
            out = model.predict_potentials(batch["X"].to(device), batch["valid"].to(device))
            c = decode_outputs(out, cfg, candidates)
            truth.extend(batch["counts"].tolist())
            pred.extend(c.cpu().tolist())
            metas.extend(batch["meta"])
    metrics = evaluate_counts(truth, pred, metas, max_occupancy=cfg["model"]["max_occupancy"],
                              train_context_records=train_records)
    rows = []
    for y, yh, meta in zip(truth, pred, metas):
        row = {k: meta.get(k) for k in ("record_id", "combo_id", "partition", "environment", "wifi_band", "user_group_id")}
        row.update(split_seed=cfg["split_seed"], model_seed=cfg["model_seed"],
                   method=cfg["method"], truth=y, pred=yh, n=sum(y), predicted_n=sum(yh))
        rows.append(row)
    return metrics, rows


def decode_outputs(out, cfg, candidates):
    if cfg["method"] == "ours_v4":
        from .v4_objectives import decode_v4
        return decode_v4(out, cfg, candidates)
    if cfg["method"] == "ours_v3":
        from .v3_objectives import decode_v3
        return decode_v3(out, cfg, candidates)
    if cfg["method"] == "amar":
        from .amar import decode_amar
        return decode_amar(out)
    if cfg["method"] in ("mushot_source", "activity_counting"):
        from .domain_adapters import domain_decode
        return domain_decode(out,cfg)
    if cfg["method"] in ("set_transformer", "activity_cnn"):
        from .baselines import baseline_decode
        return baseline_decode(out, cfg)
    method = "b4" if cfg["method"] in ("groupdro", "mldg", "ours_v2") else cfg["method"]
    return decode(out, method=method, candidates=candidates,
                  lambda_occ=cfg["training"]["lambda_occ"],
                  project_regression=cfg["evaluation"].get("project_regression", False))


def save_predictions(path, rows):
    if not rows:
        raise ValueError("Cannot export empty predictions")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v) if isinstance(v, (list, dict)) else v for k, v in row.items()})


def load_predictions(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        for key in ("truth", "pred"):
            row[key] = json.loads(row[key])
        for key in ("split_seed", "model_seed", "n", "predicted_n"):
            row[key] = int(row[key])
    return rows


def gamma_at(epoch, t):
    if epoch < t["contrast_warmup"]:
        return 0.0
    return t["gamma"] * min(1.0, (epoch - t["contrast_warmup"] + 1) / max(1,t["contrast_ramp"]))


def lr_at(epoch, t):
    w = t["warmup_epochs"]
    if epoch < w:
        return t["learning_rate"] * (epoch + 1) / max(w, 1)
    progress = (epoch - w) / max(1, t["epochs"] - w - 1)
    return t["lr_min"] + .5 * (t["learning_rate"] - t["lr_min"]) * (1 + math.cos(math.pi * progress))


def metric_key(metrics, epoch):
    # Explicit aliases support the public metrics module's descriptive names.
    exact = metrics.get("macro_exact_match_by_complete_composition", metrics.get("macro_combo_exact"))
    mae = metrics.get("positive_count_mae")
    if isinstance(mae, dict):
        mae = mae.get("value")
    if exact is None:
        raise ValueError("Validation macro-composition exact match missing")
    return (float(exact), -float(mae) if mae is not None else -math.inf, -epoch)


RUNTIME_KEYS = ("python", "torch", "numpy", "torchvision", "cuda_runtime")


def runtime_signature(value):
    """Extract the pinned numerical runtime; CPU execution may use CUDA wheels.

    GPU presence/name and the OS are deliberately not part of this signature:
    login and compute nodes may differ while sharing the same Conda runtime.
    Missing fields are not evidence that two runtimes match.
    """
    missing = [key for key in RUNTIME_KEYS if key not in value]
    if missing:
        raise ValueError(f"Runtime provenance is incomplete: {', '.join(missing)}")
    return {key: value[key] for key in RUNTIME_KEYS}


def verify_runtime(saved, current, context="Run"):
    old, new = runtime_signature(saved), runtime_signature(current)
    for key in RUNTIME_KEYS:
        if old[key] != new[key]:
            raise ValueError(f"{context} runtime {key} changed; restore the recorded environment or start a new experiment")
    return old


def verify_run_provenance(saved, current, context="Run"):
    if saved["manifest_sha256"] != current["manifest_sha256"]:
        raise ValueError(f"{context} manifest changed")
    if saved["source_sha256"] != current["source_sha256"]:
        raise ValueError(f"{context} source changed")
    if saved.get("development") != current.get("development"):
        raise ValueError(f"{context} development protocol changed")
    return verify_runtime(saved, current, context)


def provenance(cfg):
    try:
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL,
                                         cwd=Path(__file__).resolve().parents[2], text=True).strip()
    except (OSError, subprocess.CalledProcessError):
        commit = None
    source = Path(__file__).resolve().parent
    try:
        vision_version = version("torchvision")
    except PackageNotFoundError:
        vision_version = None
    result = {"manifest_sha256":file_hash(cfg["manifest"]), "code_commit":commit,
            "source_sha256": {p.name:file_hash(p) for p in sorted(source.glob("*.py"))},
            "python":platform.python_version(), "torch":str(torch.__version__), "numpy":np.__version__,
            "torchvision":vision_version,
            "cuda_runtime":torch.version.cuda, "platform":platform.platform(),
            "gpu":torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "scope":"training on supplied data; no built-in scientific performance claims"}
    if cfg["method"] in ("mushot_source", "activity_counting"):
        from .domain_adapters import domain_provenance
        result["domain_adapter"] = domain_provenance(cfg)
    if cfg["method"] == "amar":
        from .amar import UPSTREAM_COMMIT
        result["domain_adapter"] = {"kind":"AMAR no-RVQ source-grounded task adaptation",
            "repository":"https://github.com/amirhosseinmhd/AMAR","commit":UPSTREAM_COMMIT,
            "upstream_license":None,"upstream_code_vendored":False}
    if cfg["method"] in ("ours_v2", "ours_v3", "ours_v4"):
        from .domain_adapters import domain_provenance
        result[cfg["method"].replace("ours_", "")+"_pretraining"] = domain_provenance({**cfg, "method": "activity_counting"})
    if cfg.get("development_protocol"):
        from .development import verify_development_manifest
        protocol = verify_development_manifest(cfg["manifest"], cfg["development_protocol"])
        result["development"] = {"protocol_sha256": file_hash(cfg["development_protocol"]),
                                 "protocol": protocol}
    return result


def rng_state():
    ns = np.random.get_state()
    return {"python":random.getstate(), "numpy":[ns[0],ns[1].tolist(),ns[2],ns[3],ns[4]],
            "torch":torch.get_rng_state(), "cuda":torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}


def restore_rng(state):
    random.setstate(state["python"])
    ns=state["numpy"]
    np.random.set_state((ns[0],np.array(ns[1],dtype=np.uint32),ns[2],ns[3],ns[4]))
    torch.set_rng_state(state["torch"].cpu())
    if torch.cuda.is_available() and state["cuda"]:
        torch.cuda.set_rng_state_all([x.cpu() for x in state["cuda"]])


def save_checkpoint(payload, path):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def reconcile_history(path, committed_epochs):
    """Keep checkpoint-committed epochs; discard only an unfinished final append."""
    path = Path(path)
    lines = path.read_bytes().splitlines() if path.exists() else []
    kept = []
    for index, line in enumerate(lines):
        try:
            text = line.decode("utf-8")
            record = json.loads(text)
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            if index == len(lines) - 1 and index >= committed_epochs:
                break
            raise ValueError("Committed training history is corrupt; preserve it for diagnosis") from error
        if not isinstance(record, dict) or record.get("epoch") != index + 1:
            raise ValueError("Training history has missing, duplicated, or reordered epochs")
        if index < committed_epochs:
            kept.append(text)
    if len(kept) != committed_epochs:
        raise ValueError("Training history is missing checkpoint-committed epochs")
    if path.exists():
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text("".join(line + "\n" for line in kept), encoding="utf-8")
        temporary.replace(path)


def early_stopped(completed_epochs, stale, training):
    return (training.get("diagnostic") is None
            and completed_epochs > training["early_stop_after"]
            and stale >= training["patience"])


def make_optimizer(model, cfg):
    t = cfg["training"]
    if cfg["method"] in ("ours_v2", "ours_v3", "ours_v4"):
        settings_key = cfg["method"].replace("ours_", "")
        multiplier = cfg.get(settings_key, {}).get("backbone_lr_multiplier", .1)
        if not math.isfinite(multiplier) or multiplier <= 0:
            raise ValueError("V2 backbone learning-rate multiplier must be positive and finite")
        backbone = list(model.backbone.parameters())
        backbone_ids = {id(p) for p in backbone}
        heads = [p for p in model.parameters() if id(p) not in backbone_ids]
        return torch.optim.AdamW([
            {"params": backbone, "lr_multiplier": multiplier, "group_name": "backbone"},
            {"params": heads, "lr_multiplier": 1., "group_name": "projection_and_heads"},
        ], lr=t["learning_rate"], weight_decay=t["weight_decay"])
    if cfg["method"] == "activity_counting":
        settings = cfg.get("baseline", {})
        groups = []
        for name, module, multiplier in (("projection",model.projection,1.0),
                ("backbone",model.backbone,settings.get("backbone_lr_multiplier",.1)),
                ("head",model.head,settings.get("head_lr_multiplier",.1))):
            if not math.isfinite(multiplier) or multiplier <= 0:
                raise ValueError("ActivityCounting learning-rate multipliers must be finite and positive")
            groups.append({"params":module.parameters(),"lr":t["learning_rate"]*multiplier,
                           "lr_multiplier":multiplier,"group_name":name})
        return torch.optim.AdamW(groups,lr=t["learning_rate"],weight_decay=t["weight_decay"])
    return torch.optim.AdamW(model.parameters(),lr=t["learning_rate"],weight_decay=t["weight_decay"])


def train(cfg, resume=None):
    seed_all(cfg["model_seed"], cfg["deterministic"], cfg["threads"])
    device = device_for(cfg["device"])
    output = Path(cfg["output"])
    if output.exists() and any(output.iterdir()) and not resume:
        raise FileExistsError(f"Refusing to overwrite nonempty run: {output}; use --resume or a new --output")
    output.mkdir(parents=True, exist_ok=True)
    ckpt = torch.load(resume, map_location=device, weights_only=True) if resume else None
    if resume and Path(ckpt["config"]["output"]).resolve()!=output.resolve():
        raise ValueError("Resume must use the original run output directory, including its best.pt")
    records, train_records, train_ds, val_ds, store, stats = prepare_data(cfg, stats=ckpt["stats"] if ckpt else None)
    seen_ds = (CSIDataset([r for r in records if r["partition"] == "val_seen"], store, stats,
                         expected_train_records=train_records) if cfg.get("development_protocol") else None)
    model = build_model(cfg, initialize_pretrained=not bool(resume)).to(device)
    candidates = enumerate_counts(K=9,M=cfg["model"]["max_occupancy"]).to(device)
    t = cfg["training"]
    optimizer = make_optimizer(model,cfg)
    amp = cfg["amp"] and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=amp)
    start, best, stale = 0, None, 0
    group_state = None
    prov = provenance(cfg)
    if resume:
        old_cfg = dict(ckpt["config"]); now_cfg = dict(cfg)
        for key in ("output", "device", "workers", "threads"):
            old_cfg.pop(key,None); now_cfg.pop(key,None)
        if old_cfg != now_cfg or ckpt["provenance"]["manifest_sha256"] != prov["manifest_sha256"]:
            raise ValueError("Resume config/manifest changed; start a new run")
        if ckpt["provenance"]["source_sha256"] != prov["source_sha256"]:
            raise ValueError("Source changed since checkpoint; exact continuation refused")
        if ckpt["provenance"].get("development") != prov.get("development"):
            raise ValueError("Development protocol changed since checkpoint")
        verify_runtime(ckpt["provenance"], prov, "Resume")
        model.load_state_dict(ckpt["model"]); optimizer.load_state_dict(ckpt["optimizer"])
        scaler.load_state_dict(ckpt["scaler"])
        start,best,stale=ckpt["epoch"]+1,(tuple(ckpt["best_key"]) if ckpt["best_key"] is not None else None),ckpt["stale"]
        restore_rng(ckpt["rng"])
        group_state=ckpt.get("group_state")
        if best is not None and not (output / "best.pt").exists():
            raise FileNotFoundError("Resume needs the original best.pt as well as last.pt")
        completed = output / "training_summary.json"
        if completed.exists():
            if file_hash(resume) != file_hash(output / "last.pt"):
                raise ValueError("A completed run can only be reopened idempotently from its last.pt")
            if start < t["epochs"] and not early_stopped(start, stale, t):
                raise ValueError("Completion marker disagrees with checkpoint stopping state")
            reconcile_history(output / "history.jsonl", start)
            return json.loads(completed.read_text(encoding="utf-8"))
        # If a process stopped after logging but before checkpoint commit,
        # remove uncommitted epoch log entries before replaying that epoch.
        reconcile_history(output / "history.jsonl", start)
    write_json(output/"config.json",cfg); write_json(output/"provenance.json",prov)
    write_json(output/"normalization.json",stats)
    if not resume:
        # An interruption during the first epoch must also have an exact
        # continuation point. run-plan already discovers this last.pt.
        save_checkpoint({"model":model.state_dict(),"optimizer":optimizer.state_dict(),"scaler":scaler.state_dict(),
            "config":cfg,"stats":stats,"provenance":prov,"epoch":-1,"best_key":None,"stale":0,
            "rng":rng_state(),"group_state":group_state}, output/"last.pt")
    if device.type=="cuda": torch.cuda.reset_peak_memory_stats(device)
    completed_epochs = start
    # The process may have stopped after committing the stopping epoch but
    # before writing the completion marker. Do not perform an extra update.
    stop = t["epochs"] if not early_stopped(start, stale, t) else start
    for epoch in range(start,stop):
        epoch_start=time.perf_counter(); model.train()
        for pg in optimizer.param_groups: pg["lr"]=lr_at(epoch,t)*pg.get("lr_multiplier",1.0)
        plans=make_epoch_plans(train_records,batch_size=t["batch_size"],groups_per_batch=t["target_groups"],
                               seed=cfg["model_seed"],epoch=epoch,kind=t["sampler"])
        if t["save_batch_plan"]:
            write_json(output/"batch_plans"/f"epoch_{epoch+1:03d}.json",[
                {"record_ids":[train_records[i]["record_id"] for i in p.indices],"quadruplets":p.quadruplets} for p in plans])
        gen=torch.Generator().manual_seed(cfg["model_seed"]+epoch*100003)
        loader=DataLoader(train_ds,batch_sampler=[p.indices for p in plans],num_workers=cfg["workers"],
                          collate_fn=collate_records,generator=gen,pin_memory=device.type=="cuda")
        loss_sum=0.; pair_logs=[]; step_times=[]
        gamma=gamma_at(epoch,t)
        for step,(plan,batch) in enumerate(zip(plans,loader)):
            tick=time.perf_counter(); optimizer.zero_grad(set_to_none=True)
            x=batch["X"].to(device); valid=batch["valid"].to(device); counts=batch["counts"].to(device)
            with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=amp):
                out=model(x,valid)
            if cfg["method"] == "ours_v4":
                from .v4_objectives import v4_supervised_loss
                loss, diagnostics = v4_supervised_loss(out, counts, cfg, candidates)
            elif cfg["method"] == "ours_v3":
                from .v3_objectives import v3_supervised_loss
                loss, diagnostics = v3_supervised_loss(out, counts, cfg, candidates)
            elif cfg["method"] == "ours_v2":
                from .v2_objectives import v2_supervised_loss
                loss, diagnostics = v2_supervised_loss(out, counts, cfg, candidates)
            elif cfg["method"] == "amar":
                from .amar import amar_set_loss
                settings = cfg.get("baseline", {})
                loss = amar_set_loss(out,counts,empty_weight=settings.get("amar_empty_weight",.25),
                    label_smoothing=settings.get("amar_label_smoothing",.2),aux_weight=settings.get("amar_aux_weight",.25))
                diagnostics = {"amar_set_loss": float(loss.detach())}
            elif cfg["method"] in ("mushot_source", "activity_counting"):
                from .domain_adapters import domain_loss
                loss, diagnostics = domain_loss(out, counts, cfg)
            elif cfg["method"] in ("groupdro","mldg","set_transformer","activity_cnn"):
                from .baselines import baseline_loss
                loss, diagnostics, group_state=baseline_loss(model,out,x,valid,counts,batch["meta"],cfg,candidates,group_state)
            else:
                loss,diagnostics=supervised_loss(out,counts,method=cfg["method"],candidates=candidates,
                                                eta=t["eta"],lambda_occ=t["lambda_occ"])
            pair_log={}
            if cfg["method"] in ("b5","ours","ours_v4"):
                variant="supcon" if cfg["method"]=="b5" else t.get("contrast_variant","ours")
                diag=t.get("diagnostic")
                if diag is not None: variant={"erm":"cross"}.get(diag,diag)
                cc,pair_log=contrastive_loss(out["p"].float(),batch["meta"],variant=variant,
                    seed=cfg["model_seed"]+epoch*100003+step,quadruplets=plan.quadruplets if diag else None,
                    temperature=t["temperature"],max_positives=t["max_positives"],max_negatives_per_count=t["max_negatives_per_count"])
                loss=loss+(0.0 if diag=="erm" else gamma)*cc
                if cfg["method"] == "ours_v4":
                    effective_gamma = 0.0 if diag=="erm" else gamma
                    pair_log.update(contrast_loss=float(cc.detach()), contrast_effective_weight=effective_gamma,
                        active_anchor_exposures=pair_log["retained_anchors"] if effective_gamma > 0 else 0)
                    if step == 0:
                        # Descriptive first-batch measurement, before clipping;
                        # no extra forward, optimizer step, or random draw.
                        from .v4_objectives import v4_loss_components
                        parts = v4_loss_components(out, counts, cfg, candidates)
                        settings = cfg.get("v4", {})
                        weighted = {"mse": parts["mse"],
                            "occupancy": settings.get("occupancy_weight", .25)*parts["occupancy_ce"],
                            "joint": settings.get("joint_weight", .1)*parts["joint_nll"],
                            "contrast": effective_gamma*cc}
                        norms = {}
                        for name, term in weighted.items():
                            grad_h = torch.autograd.grad(term, out["h"], retain_graph=True, allow_unused=True)[0]
                            norms[name] = float(grad_h.detach().float().norm()) if grad_h is not None else 0.
                        pair_log["first_batch_weighted_loss_grad_norm_at_h"] = norms
            if not torch.isfinite(loss): raise FloatingPointError(f"Nonfinite loss at epoch {epoch+1}, step {step}")
            scaler.scale(loss).backward(); scaler.unscale_(optimizer)
            grad=torch.nn.utils.clip_grad_norm_(model.parameters(),t["gradient_clip"],error_if_nonfinite=True)
            scaler.step(optimizer); scaler.update()
            loss_sum+=float(loss.detach()); pair_log.update(step=step,loss=float(loss.detach()),gradient_norm=float(grad),**diagnostics)
            pair_logs.append(pair_log)
            if device.type=="cuda": torch.cuda.synchronize(device)
            step_times.append(time.perf_counter()-tick)
            if (step+1)%t["log_every"]==0: print(f"epoch={epoch+1} step={step+1}/{len(plans)} loss={loss_sum/(step+1):.5f}",flush=True)
        metrics,rows=predictions(model,val_ds,cfg,device,candidates,train_records)
        seen_metrics = None
        if seen_ds is not None:
            from .development import development_metric_key
            seen_metrics, seen_rows = predictions(model,seen_ds,cfg,device,candidates,train_records)
            key = development_metric_key(metrics,seen_metrics,epoch)
        else:
            key=metric_key(metrics,epoch)
        improved=best is None or key>best
        if improved: best=key; stale=0
        else: stale+=1
        payload={"model":model.state_dict(),"optimizer":optimizer.state_dict(),"scaler":scaler.state_dict(),
                 "config":cfg,"stats":stats,"provenance":prov,"epoch":epoch,"best_key":best,"stale":stale,
                 "rng":rng_state(),"group_state":group_state}
        if improved:
            save_checkpoint(payload,output/"best.pt"); write_json(output/"validation_best.json",metrics)
            save_predictions(output/"validation_best.csv",rows)
            if seen_metrics is not None:
                write_json(output/"validation_seen_best.json",seen_metrics)
                save_predictions(output/"validation_seen_best.csv",seen_rows)
                write_json(output/"development_best_complete.json", {
                    "epoch": epoch+1, "selection_key": list(key),
                    "sha256": {name:file_hash(output/name) for name in (
                        "best.pt", "validation_best.json", "validation_best.csv",
                        "validation_seen_best.json", "validation_seen_best.csv")}})
        write_json(output/"pair_logs"/f"epoch_{epoch+1:03d}.json",pair_logs)
        summary={"epoch":epoch+1,"training_loss":loss_sum/len(plans),"gamma":gamma,"learning_rate":lr_at(epoch,t),
                 "validation":metrics,"best_epoch":-best[2]+1,"elapsed_seconds":time.perf_counter()-epoch_start,
                 "mean_update_seconds":sum(step_times)/len(step_times),"updates":len(plans)}
        if seen_metrics is not None:
            summary.update(validation_seen=seen_metrics, development_selection_score=key[0])
        with (output/"history.jsonl").open("a",encoding="utf-8") as f: f.write(json.dumps(summary,ensure_ascii=False,allow_nan=False)+"\n")
        save_checkpoint(payload,output/"last.pt")
        completed_epochs = epoch + 1
        print(f"epoch={epoch+1} selection_score={key[0]:.4f} best_epoch={-best[2]+1}",flush=True)
        if early_stopped(completed_epochs, stale, t): break
    result={"best_epoch":-best[2]+1 if best else None,"best_validation_macro_exact":best[0] if best else None,
            "training_records":len(train_records),"parameter_count":sum(p.numel() for p in model.parameters()),
            "peak_cuda_memory_bytes":torch.cuda.max_memory_allocated(device) if device.type=="cuda" else None,
            "test_evaluated":False,"output":str(output),"completed_epochs":completed_epochs,
            "stop_reason":"early_stopping" if early_stopped(completed_epochs,stale,t) else "max_epochs"}
    if seen_ds is not None:
        from .development import SELECTION
        best_unseen = json.loads((output/"validation_best.json").read_text(encoding="utf-8"))
        result.update(selection=SELECTION, best_selection_score=best[0],
                      best_validation_macro_exact=best_unseen["macro_exact_match_by_complete_composition"])
    write_json(output/"training_summary.json",result)
    return result


def evaluate(checkpoint, partition="test_unseen", output=None, data_root=None, device="auto"):
    if partition not in ("val_unseen","val_seen","val_aux","test_unseen","test_seen","test_aux"):
        raise ValueError("Evaluation partition not allowed")
    ckpt=torch.load(checkpoint,map_location="cpu",weights_only=True)
    cfg=ckpt["config"]
    if cfg.get("development_protocol") and partition.startswith("test"):
        raise ValueError("Development checkpoints only support internal development partitions")
    if data_root: cfg["data_root"]=str(Path(data_root).resolve())
    if file_hash(cfg["manifest"])!=ckpt["provenance"]["manifest_sha256"]:
        raise ValueError("Checkpoint manifest hash mismatch")
    cfg["device"]=device; dev=device_for(device)
    verify_run_provenance(ckpt["provenance"], provenance(cfg), "Evaluation")
    seed_all(cfg["model_seed"],cfg["deterministic"],cfg["threads"])
    records,train_records,_,_,store,stats=prepare_data(cfg,stats=ckpt["stats"])
    chosen=[r for r in records if r["partition"]==partition]
    if not chosen: raise ValueError(f"Empty {partition}")
    ds=CSIDataset(chosen,store,stats,expected_train_records=train_records)
    model=build_model(cfg, initialize_pretrained=False).to(dev); model.load_state_dict(ckpt["model"])
    candidates=enumerate_counts(K=9,M=cfg["model"]["max_occupancy"]).to(dev)
    metrics,rows=predictions(model,ds,cfg,dev,candidates,train_records)
    destination=Path(output or Path(checkpoint).parent/f"evaluation_{partition}")
    if (destination/"predictions.csv").exists(): raise FileExistsError(f"Evaluation exists: {destination}")
    destination.mkdir(parents=True,exist_ok=True)
    write_json(destination/"metrics.json",metrics);save_predictions(destination/"predictions.csv",rows)
    write_json(destination/"evaluation_provenance.json",{"checkpoint_sha256":file_hash(checkpoint),"epoch":ckpt["epoch"]+1,
                "partition":partition,"config":cfg,"training_provenance":ckpt["provenance"],
                "evaluation_provenance":provenance(cfg)})
    write_json(destination/"evaluation_complete.json", {name:file_hash(destination/name) for name in
               ("metrics.json", "predictions.csv", "evaluation_provenance.json")})
    return metrics
