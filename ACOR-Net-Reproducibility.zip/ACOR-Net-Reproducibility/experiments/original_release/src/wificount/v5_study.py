"""Frozen V4 main method plus the original comparator families.

This is a bounded, original-train-only comparison. It does not turn already
reviewed formal test records into a fresh test, or select a replacement main
method from the joint-loss diagnostic.
"""
from __future__ import annotations

from collections import Counter
import copy
import datetime as dt
import json
import math
from pathlib import Path
import tarfile
import tempfile

from .config import ROOT, deep_update, file_hash, fingerprint, load_config, write_json
from .development import (make_development_manifest, make_development_plan,
    run_development_plan, summarize_development, verify_development_plan)


VERSION = "v5_comparators_20261025"
MAIN = "v4_controlled_cross"
BASELINES = ("b1", "b2", "b3", "b4", "b5", "amar", "mushot_source",
             "activity_counting", "mldg")
V4_NAMES = (MAIN, "v4_controlled_erm", "v4_controlled_within", "v4_controlled_any",
            "v4_supcon", "v4_controlled_cross_joint0")
COUNTS = {"pilot": 15, "search": 24, "full": 45}
LR_GRID = (.0003, .001)
B5_GAMMA_GRID = (0., .025, .1, .4)
SPLIT_COUNTS = {"train": 3318, "val_seen": 246, "val_unseen": 156, "val_aux": 498}


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)


def _sign(plan):
    plan["plan_fingerprint"] = fingerprint(plan["jobs"])
    plan.pop("development_fingerprint", None)
    plan["development_fingerprint"] = fingerprint(plan)
    return plan


def _recipe(name, cfg, role, family=None):
    return {"name": name, "role": role, "family": family or name, "overrides": cfg}


def baseline_config(method, data_root, device="cuda", epochs=80):
    """Load full paper-adapter settings; never inherit inactive V4 defaults."""
    if method not in BASELINES:
        raise ValueError(f"Unknown baseline family: {method}")
    config_name = method if method in ("amar", "mushot_source", "activity_counting") else "server_l20"
    cfg = load_config(ROOT / "configs" / f"{config_name}.yaml", {
        "method": method, "data_root": str(Path(data_root).resolve()), "device": device,
        "amp": False, "training": {"epochs": epochs, "batch_size": 16,
            "target_groups": 1, "gamma": .1 if method == "b5" else 0.,
            "sampler": "matched" if method in BASELINES[:5] else "uniform",
            "diagnostic": None, "contrast_warmup": 10, "contrast_ramp": 10,
            "temperature": .1}, "evaluation": {"batch_size": 16,
            "project_regression": False}})
    if method == "mldg":
        cfg = deep_update(cfg, {"baseline": {"inner_learning_rate": .001, "meta_weight": 1.}})
    return cfg


def frozen_v4_recipes(data_root, device="cuda", epochs=60):
    from .v4_study import variants
    old = {entry["name"]: entry["overrides"] for entry in variants()}
    base = load_config(ROOT / "configs/development_v4.yaml", {
        "data_root": str(Path(data_root).resolve()), "device": device,
        "training": {"epochs": epochs}})
    result = []
    for name in V4_NAMES:
        parent = MAIN if name.endswith("_joint0") else name
        cfg = deep_update(base, old[parent])
        if name.endswith("_joint0"):
            cfg["v4"]["joint_weight"] = 0.
        result.append(_recipe(name, cfg, "frozen_main" if name == MAIN else
            ("targeted_diagnostic" if name.endswith("_joint0") else "mechanism_control")))
    return result


def stage_recipes(stage, data_root, device="cuda"):
    if stage not in ("pilot", "search"):
        raise ValueError("Use verified search selection to construct the full stage")
    entries = []
    for method in BASELINES:
        cfg = baseline_config(method, data_root, device, 3 if stage == "pilot" else 80)
        if stage == "pilot":
            cfg["training"]["learning_rate"] = .0003
            if method == "b5":
                # Software/exposure check only, not a short performance search.
                cfg["training"].update(contrast_warmup=1, contrast_ramp=3)
            entries.append(_recipe(method, cfg, "baseline", method))
        else:
            for lr in LR_GRID:
                for gamma in B5_GAMMA_GRID if method == "b5" else (0.,):
                    candidate = deep_update(cfg, {"training": {"learning_rate": lr, "gamma": gamma}})
                    suffix = f"lr{lr:g}_g{gamma:g}".replace(".", "p")
                    entries.append(_recipe(f"{method}_{suffix}", candidate, "baseline_search", method))
    if stage == "pilot":
        entries += frozen_v4_recipes(data_root, device, 3)
    return entries


def select_verified_rows(plan, summary):
    """Pure selector; callers must obtain summary from the artifact verifier."""
    if plan.get("comparison_stage") != "search":
        raise ValueError("Baseline selection requires the V5 search stage")
    jobs = {job["id"]: job for job in plan["jobs"]}
    rows = summary["rows"]
    if len(rows) != len(jobs) or {row["job"] for row in rows} != set(jobs):
        raise ValueError("Selection needs every candidate exactly once")
    families = {entry["name"]: entry["family"] for entry in plan["variants"]}
    selected, candidates = {}, {method: [] for method in BASELINES}
    for row in rows:
        job = jobs[row["job"]]
        if row["model_seed"] != 11 or row["variant"] != job["variant"]:
            raise ValueError("Search selection is seed 11 only")
        cfg = job["config"]
        key = (row["joint_score"], -row["mean_positive_mae"], -row["best_epoch"],
               -cfg["training"]["gamma"], -cfg["training"]["learning_rate"])
        if not all(math.isfinite(value) for value in key):
            raise ValueError("Nonfinite selection score")
        family = families[job["variant"]]
        item = {"job": job["id"], "variant": job["variant"], "rank_key": list(key),
                "checkpoint_sha256": row["checkpoint_sha256"], "config": copy.deepcopy(cfg)}
        candidates[family].append(item)
        if family not in selected or key > tuple(selected[family]["rank_key"]):
            selected[family] = item
    if set(selected) != set(BASELINES):
        raise ValueError("A baseline family is missing from the search")
    return {"search_fingerprint": plan["development_fingerprint"], "selected": selected,
        "candidates": candidates,
        "selection_rule": "seed11 H, lower mean positive MAE, earlier best epoch, smaller gamma, smaller LR",
        "test_used_for_selection": False, "main_method_reselected": False}


def audited_search_selection(search_plan):
    plan = verify_comparison_plan(search_plan)
    if plan["comparison_stage"] != "search":
        raise ValueError("Expected a completed V5 search plan")
    # summarize_development validates all configs, provenance, checkpoints,
    # completion markers and recalculates both holdout metrics from CSVs.
    parent = Path(plan["jobs"][0]["config"]["output"]).parents[1]
    with tempfile.TemporaryDirectory(prefix=".selection-audit-", dir=parent) as folder:
        summarize_development(plan, folder)
        summary = read_json(Path(folder) / "development_summary.json")
    return plan, select_verified_rows(plan, summary)


def prepare_stage(stage, output, *, data_root=None, device="cuda", manifest=None, search_plan=None):
    output = Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("Choose an empty stage directory; use run to resume its frozen plan")
    if stage == "full":
        if search_plan is None:
            raise ValueError("Full preparation requires --search-plan")
        source, selection = audited_search_selection(search_plan)
        first = source["jobs"][0]["config"]
        if data_root is not None and Path(data_root).resolve() != Path(first["data_root"]):
            raise ValueError("Full data root must match the completed search")
        data_root, device = first["data_root"], first["device"]
        entries = [_recipe(method, selection["selected"][method]["config"], "baseline", method)
                   for method in BASELINES] + frozen_v4_recipes(data_root, device)
        manifest = source["manifest"]
        seeds = (11, 22, 33)
    else:
        if stage not in ("pilot", "search") or data_root is None:
            raise ValueError("Pilot/search preparation requires --data-root")
        if not Path(data_root).is_dir():
            raise FileNotFoundError(data_root)
        split = make_development_manifest(manifest or ROOT / "data/manifests/sample_manifest_seed2026.csv",
                                           output / "development_manifest.csv")
        if split["partition_counts"] != SPLIT_COUNTS:
            raise ValueError("V5 requires the frozen V4 development split counts")
        manifest, seeds = split["manifest"], (11,)
        entries = stage_recipes(stage, data_root, device)
    plan = make_development_plan(load_config(ROOT / "configs/default.yaml"), manifest, output, entries, seeds)
    plan.update(comparison_version=VERSION, comparison_stage=stage, frozen_main_method=MAIN,
        main_method_reselected=False, original_proposal_baselines=list(BASELINES),
        selection_amendment="Retain V2-V4 internal-development H selection, rather than original proposal val_unseen-only selection.",
        information_budget="All model fitting uses original-train records only; MU-SHOT-Fi target adaptation is disabled.")
    if stage == "full":
        plan.update(search_plan=str(Path(search_plan).resolve()), search_plan_sha256=file_hash(search_plan),
                    baseline_selection=selection)
        for job in plan["jobs"]:
            if job["variant"] in BASELINES and job["config"]["model_seed"] == 11:
                chosen = selection["selected"][job["variant"]]
                job["config"] = copy.deepcopy(chosen["config"])
                job["reuse_completed_run"] = chosen["config"]["output"]
    _sign(plan)
    verify_comparison_plan(plan, verify_search_results=False)
    _write_new(output / "plan.json", plan)
    if stage == "full":
        _write_new(output / "baseline_selection.json", selection)
    return {"plan": str(output / "plan.json"), "stage": stage, "job_count": plan["job_count"],
            "new_training_runs": plan["job_count"] - (9 if stage == "full" else 0),
            "frozen_main_method": MAIN, "formal_test_execution": False}


def _semantic_config(cfg):
    return {key: value for key, value in cfg.items() if key not in
            {"manifest", "development_protocol", "output", "cache_dir", "model_seed"}}


def verify_comparison_plan(plan, *, verify_search_results=True):
    plan = verify_development_plan(plan)
    stage = plan.get("comparison_stage")
    if (plan.get("comparison_version") != VERSION or stage not in COUNTS
            or plan["job_count"] != COUNTS[stage] or len(plan["jobs"]) != COUNTS[stage]
            or plan["seeds"] != ([11, 22, 33] if stage == "full" else [11])
            or plan.get("frozen_main_method") != MAIN or plan.get("main_method_reselected") is not False):
        raise ValueError("V5 stage contract mismatch")
    first = plan["jobs"][0]["config"]
    if read_json(plan["protocol_path"])["partition_counts"] != SPLIT_COUNTS:
        raise ValueError("V5 development split changed")
    if stage == "full":
        if file_hash(plan["search_plan"]) != plan["search_plan_sha256"]:
            raise ValueError("Linked search plan changed")
        source = verify_comparison_plan(plan["search_plan"])
        selection = plan["baseline_selection"]
        if source["development_fingerprint"] != selection["search_fingerprint"]:
            raise ValueError("Baseline selection refers to another search")
        if verify_search_results:
            _, fresh = audited_search_selection(plan["search_plan"])
            if fresh != selection:
                raise ValueError("Search evidence or selected baseline changed")
        expected = [_recipe(method, selection["selected"][method]["config"], "baseline", method)
                    for method in BASELINES] + frozen_v4_recipes(first["data_root"], first["device"])
    else:
        expected = stage_recipes(stage, first["data_root"], first["device"])
    expected = {entry["name"]: entry for entry in expected}
    if [entry["name"] for entry in plan["variants"]] != list(expected):
        raise ValueError("V5 recipe matrix changed")
    coverage = Counter()
    for job in plan["jobs"]:
        name, cfg = job["variant"], job["config"]
        coverage[(name, cfg["model_seed"])] += 1
        if _semantic_config(cfg) != _semantic_config(expected[name]["overrides"]):
            raise ValueError(f"Frozen recipe changed: {name}")
        if stage == "full" and name in BASELINES and cfg["model_seed"] == 11:
            chosen = selection["selected"][name]["config"]
            if cfg != chosen or job.get("reuse_completed_run") != chosen["output"]:
                raise ValueError("Selected seed 11 must reuse the exact verified search run")
    if coverage != Counter({(name, seed): 1 for name in expected for seed in plan["seeds"]}):
        raise ValueError("V5 seed/recipe coverage mismatch")
    return plan


def run_stage(plan, execute=False, max_jobs=None):
    return run_development_plan(verify_comparison_plan(plan), execute, max_jobs)


def _b5_exposure(plan):
    from .engine import gamma_at
    result = []
    for job in plan["jobs"]:
        cfg = job["config"]
        if cfg["method"] != "b5":
            continue
        folder = Path(cfg["output"])
        summary = read_json(folder / "training_summary.json")
        completed = summary["completed_epochs"]
        history = [json.loads(line) for line in (folder / "history.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
        if [h["epoch"] for h in history] != list(range(1, completed + 1)):
            raise ValueError("B5 history coverage mismatch")
        paths = sorted((folder / "pair_logs").glob("epoch_*.json"))
        if {p.name for p in paths} != {f"epoch_{e:03d}.json" for e in range(1, completed + 1)}:
            raise ValueError("B5 pair log coverage mismatch")
        active = 0
        before_best = 0
        for epoch, (path, hist) in enumerate(zip(paths, history), 1):
            logs = read_json(path)
            if len(logs) != hist["updates"] or [r["step"] for r in logs] != list(range(hist["updates"])):
                raise ValueError("B5 pair update coverage mismatch")
            if gamma_at(epoch - 1, cfg["training"]) > 0:
                count = sum(int(row["retained_anchors"]) for row in logs)
                active += count
                before_best += count if epoch <= summary["best_epoch"] else 0
        expected = cfg["training"]["gamma"] > 0
        result.append({"job": job["id"], "expected_contrast": expected,
            "active_anchor_exposures": active, "through_best_active_anchor_exposures": before_best,
            "missing_expected_exposure": expected and active == 0,
            "derivation": "Frozen gamma_at(epoch-1) times retained anchors; B5 legacy logs do not store a separate actual-weight field."})
    return result


def report_stage(plan, output, require_exposure=False):
    plan = verify_comparison_plan(plan)
    result = summarize_development(plan, output)
    from .development_diagnostics import summarize_diagnostics
    from .v4_study import contrast_exposure, metric_comparison
    result["diagnostics"] = summarize_diagnostics(plan, output)
    summary = read_json(Path(output) / "development_summary.json")
    exposure = contrast_exposure(plan)
    b5 = _b5_exposure(plan)
    comparison = metric_comparison(summary)
    comparison["primary_innovation_candidate"] = MAIN
    audit = {"comparison_stage": plan["comparison_stage"], "frozen_main_method": MAIN,
        "main_method_reselected": False, "test_evaluated": False,
        "baseline_families": list(BASELINES), "contrast_exposure": exposure,
        "b5_contrast_exposure": b5, "comparison": comparison,
        "ranking_scope": "Search ranks candidate configurations only; full ranks one selected configuration per baseline and fixed V4 controls.",
        "interpretation": "The joint0 row is a diagnostic and does not automatically replace the frozen main method. TCN baselines are not capacity-matched V4 controls."}
    write_json(Path(output) / "v5_baseline_and_mechanism_comparison.json", audit)
    if plan["comparison_stage"] == "search":
        write_json(Path(output) / "baseline_selection.json", select_verified_rows(plan, summary))
    if require_exposure and any(row["missing_expected_exposure"] for row in exposure + b5):
        raise ValueError("Contrast-enabled pilot has zero active anchor exposure")
    result["v5_audit"] = str(Path(output) / "v5_baseline_and_mechanism_comparison.json")
    return result


def pack_results(run_root, output):
    """Include all search candidates and partial failures, never CSI or weights."""
    root, output = Path(run_root).resolve(), Path(output).resolve()
    if not root.is_dir():
        raise FileNotFoundError(root)
    plans = [root / stage / "plan.json" for stage in COUNTS if (root / stage / "plan.json").is_file()]
    statuses = []
    for path in plans:
        # A diagnostic archive must remain available after preflight, source,
        # preparation or provenance failures. Running/reporting still reject
        # these failures; packing records them rather than declaring success.
        try:
            plan = verify_comparison_plan(path, verify_search_results=False)
            statuses.append({"stage": plan["comparison_stage"], "jobs": plan["job_count"],
                "completed_jobs": sum((Path(job["config"]["output"]) / "training_summary.json").is_file() for job in plan["jobs"]),
                "plan_verified": True, "plan_sha256": file_hash(path)})
        except Exception as exc:
            statuses.append({"stage": path.parent.name, "plan_verified": False,
                "verification_error": f"{type(exc).__name__}: {exc}",
                "plan_sha256": file_hash(path)})
    files = [(p, "comparison/" + p.relative_to(root).as_posix()) for p in root.rglob("*")
             if p.is_file() and "cache" not in p.relative_to(root).parts
             and not any(part.startswith(".selection-audit-") for part in p.parts)
             and p.suffix in {".json", ".jsonl", ".csv", ".log"}]
    for directory in ("src", "configs", "scripts", "docs", "tests", "data/manifests"):
        files += [(p, "source/" + p.relative_to(ROOT).as_posix()) for p in (ROOT / directory).rglob("*")
                  if p.is_file() and "__pycache__" not in p.parts and p.suffix in
                  {".py", ".sh", ".yaml", ".yml", ".md", ".bib", ".csv", ".json"}]
    for name in ("release_files.json", "VALIDATION.json", "requirements-tested.txt", "README.md", "v4_source_snapshot.json"):
        if (ROOT / name).is_file():
            files.append((ROOT / name, "source/" + name))
    status = {"created_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "stages": statuses,
              "all_present_stages_complete": bool(statuses) and all(row["plan_verified"] and
                  row["jobs"] == row["completed_jobs"] for row in statuses),
              "full_stage_present": any(row["stage"] == "full" for row in statuses),
              "no_plan_preparation_failed": not bool(plans),
              "completion_basis": "Training-summary markers only; status-*.json stage exit codes and successful reports establish execution success. An archive can contain failed/partial work.",
              "checkpoint_files_included": False, "formal_test_inference": False}
    checksum = output.with_name(output.name + ".sha256")
    if output.exists() or checksum.exists():
        raise FileExistsError("Result archive/checksum already exists")
    output.parent.mkdir(parents=True, exist_ok=True)
    import io
    with output.open("xb") as stream:
        with tarfile.open(fileobj=stream, mode="w:gz") as archive:
            for path, name in sorted(files, key=lambda entry: entry[1]):
                archive.add(path, arcname=name, recursive=False)
            payload = json.dumps(status, indent=2).encode("utf-8")
            info = tarfile.TarInfo("package_status.json")
            info.size = len(payload)
            archive.addfile(info, io.BytesIO(payload))
    digest = file_hash(output)
    checksum.write_bytes(f"{digest}  {output.name}\n".encode("ascii"))
    return {"archive": str(output), "sha256": digest, **status}
