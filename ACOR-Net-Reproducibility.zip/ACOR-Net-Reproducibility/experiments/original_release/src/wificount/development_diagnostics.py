"""Descriptive diagnostics; never replace the frozen checkpoint selection rule."""
from collections import Counter, defaultdict
import json
from pathlib import Path

from .config import write_json
from .data import ACTIONS, read_manifest
from .engine import load_predictions
from .development import verify_development_plan


def prediction_diagnostics(rows):
    if not rows:
        raise ValueError("Cannot diagnose empty predictions")
    by_combo = defaultdict(list)
    by_n = defaultdict(list)
    q_confusion = Counter()
    action = {a: Counter() for a in ACTIONS}
    single = repeated_error = q_exact = n_exact = exact = 0
    for row in rows:
        y, p = row["truth"], row["pred"]
        q, qhat = sum(v > 0 for v in y), sum(v > 0 for v in p)
        good = y == p
        exact += good
        q_exact += q == qhat
        n_exact += sum(y) == sum(p)
        single += qhat == 1
        repeated_error += max(y) <= 1 and max(p) >= 2
        q_confusion[f"{q}->{qhat}"] += 1
        by_combo[row["combo_id"]].append(good)
        by_n[sum(y)].append(good)
        for a, true, pred in zip(ACTIONS, y, p):
            if true > 0:
                action[a]["positives"] += 1
                action[a]["missed"] += pred == 0
                action[a]["positive_absolute_error"] += abs(true-pred)
            else:
                action[a]["negatives"] += 1
                action[a]["false_positives"] += pred > 0
    count = len(rows)
    return {"records": count, "exact_records": exact,
            "sample_exact": exact/count, "occupancy_accuracy": n_exact/count,
            "support_accuracy": q_exact/count,
            "predicted_single_action_fraction": single/count,
            "false_repetition_fraction_all_records": repeated_error/count,
            "support_confusion": dict(q_confusion),
            "per_composition": {k: {"samples":len(v), "correct":sum(v)} for k,v in by_combo.items()},
            "per_occupancy": {str(k): {"samples":len(v), "correct":sum(v)} for k,v in by_n.items()},
            "per_action": {k:dict(v) for k,v in action.items()}}


def summarize_diagnostics(plan_path, output):
    plan = verify_development_plan(plan_path)
    # verify_development_plan validates in place but returns the verified plan.
    records = {r["record_id"]: r for r in read_manifest(plan["manifest"]) if r["partition"] == "train"}
    reports = []
    for job in plan["jobs"]:
        root = Path(job["config"]["output"])
        pair = {part: prediction_diagnostics(load_predictions(root/name))
                for part,name in [("val_unseen","validation_best.csv"), ("val_seen","validation_seen_best.csv")]}
        exposure = Counter()
        unique = set()
        summary = json.loads((root/"training_summary.json").read_text(encoding="utf-8"))
        completed = summary["completed_epochs"]
        if not isinstance(completed, int) or completed < 1:
            raise ValueError("Exposure diagnostics require completed training epochs")
        files = sorted((root/"batch_plans").glob("epoch_*.json"))
        expected = {f"epoch_{epoch:03d}.json" for epoch in range(1, completed+1)}
        if {file.name for file in files} != expected:
            raise ValueError(f"Saved batch plan coverage mismatch: {job['id']}")
        history = [json.loads(line) for line in (root/"history.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
        if [row["epoch"] for row in history] != list(range(1, completed+1)):
            raise ValueError(f"Training history epoch coverage mismatch: {job['id']}")
        for file, epoch_log in zip(files, history):
            batches = json.loads(file.read_text(encoding="utf-8"))
            if not batches or len(batches) != epoch_log["updates"]:
                raise ValueError(f"Saved batch plan update count mismatch: {job['id']}/{file.name}")
            for batch in batches:
                ids = batch["record_ids"]
                if not ids:
                    raise ValueError("Empty physical batch in saved plan")
                if len(set(ids)) != len(ids):
                    raise ValueError("Duplicate record inside physical batch")
                for rid in ids:
                    if rid not in records:
                        raise ValueError("Nontraining record in saved batch plan")
                    row = records[rid]
                    exposure[f"n={row['n']},q={sum(v>0 for v in row['counts'])}"] += 1
                    unique.add(rid)
        reports.append({"job": job["id"], "variant":job["variant"],
                        "seed":job["config"]["model_seed"], **pair,
                        "completed_epochs_verified":completed,
                        "training_resources": {
                            "parameter_count":summary["parameter_count"],
                            "peak_cuda_memory_bytes":summary["peak_cuda_memory_bytes"],
                            "total_logged_epoch_seconds":sum(row["elapsed_seconds"] for row in history),
                            "optimizer_updates":sum(row["updates"] for row in history),
                            "note":"Epoch time includes validation; excludes initialization and interrupted work. Not inference latency."},
                        "training_exposure_n_q":dict(exposure),
                        "unique_training_records_exposed":len(unique)})
    target = Path(output)/"composition_diagnostics.json"
    write_json(target, {"scope":"Descriptive only; same seed predictions are not independent samples",
                        "selection_changed":False,"test_evaluated":False,"runs":reports})
    return str(target)
