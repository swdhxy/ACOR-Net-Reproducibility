"""Global evidence with presence/positive-count factorization for V3.

All inference inputs are CSI and its validity mask. The support head predicts
the number of distinct actions *conditional on candidate occupancy*; it never
receives the true occupancy. This is a hypothesis to test, not an accuracy claim.
"""

from __future__ import annotations

import math

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from .domain_adapters import CSISpatialProjection
from .v2_model import CSIMultiviewProjection, _pretrained_spatial_backbone


def validate_v3_settings(settings: dict) -> None:
    """Reject malformed settings before preparing an expensive experiment."""
    if not isinstance(settings, dict):
        raise ValueError("v3 settings must be a mapping")
    if settings.get("pretrained", True) is not True:
        raise ValueError("V3 requires official pretrained weights; no random fallback")
    if settings.get("input_view", "amplitude") not in {"amplitude", "multiview"}:
        raise ValueError("V3 input_view must be amplitude or multiview")
    if not isinstance(settings.get("use_support", True), bool):
        raise ValueError("V3 use_support must be a boolean")
    for name, default in (("hidden_dim", 256), ("resolution", 270)):
        value = settings.get(name, default)
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f"V3 {name} must be a positive integer")
    for name, default in (("dropout", 0.1), ("warp_probability", 0.5),
                          ("lambda_support", 1.), ("presence_weight", 1.),
                          ("multiplicity_weight", .5), ("support_ce_weight", .25),
                          ("gamma_pos", 0.), ("gamma_neg", 2.)):
        raw = settings.get(name, default)
        if isinstance(raw, bool) or not isinstance(raw, (int, float)):
            raise ValueError(f"V3 {name} must be a finite nonnegative number")
        value = float(raw)
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"V3 {name} must be finite and nonnegative")
        if name == "dropout" and value >= 1:
            raise ValueError("V3 dropout must be in [0,1)")
        if name == "warp_probability" and value > 1:
            raise ValueError("V3 warp_probability must be in [0,1]")


class V3CountingModel(nn.Module):
    """Pretrained spatial backbone and a global MLP with dedicated output heads.

    Unlike the V2 shared action MLP, the presence and positive multiplicity heads
    have separate parameters for every action. Counts 2 and 3 remain legitimate.
    A supplied backbone is reserved for software tests and must produce a grid.
    """

    def __init__(self, *, initialize_pretrained=True, backbone=None, feature_dim=None,
                 input_view="amplitude", hidden_dim=256, dropout=.1,
                 warp_probability=.5, resolution=270, length=3000,
                 max_occupancy=3, num_actions=9, use_support=True):
        super().__init__()
        validate_v3_settings(dict(input_view=input_view, hidden_dim=hidden_dim,
                                  dropout=dropout, warp_probability=warp_probability,
                                  resolution=resolution, use_support=use_support))
        for name, value in (("length", length), ("max_occupancy", max_occupancy),
                            ("num_actions", num_actions)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"V3 {name} must be a positive integer")
        self.num_actions, self.max_occupancy = num_actions, max_occupancy
        self.use_support, self.input_view = use_support, input_view
        projection = CSISpatialProjection if input_view == "amplitude" else CSIMultiviewProjection
        self.projection = projection(warp_probability=warp_probability,
                                     length=length, resolution=resolution)
        if backbone is None:
            backbone, feature_dim = _pretrained_spatial_backbone(initialize_pretrained)
        elif isinstance(feature_dim, bool) or not isinstance(feature_dim, int) or feature_dim < 1:
            raise ValueError("Injected test backbone requires a positive feature_dim")
        self.backbone, self.feature_dim = backbone, feature_dim
        self.global_mlp = nn.Sequential(nn.Linear(feature_dim, hidden_dim), nn.GELU(),
                                        nn.Dropout(dropout))
        self.presence_head = nn.Linear(hidden_dim, num_actions)
        self.multiplicity_head = nn.Linear(hidden_dim, num_actions * max_occupancy)
        self.occupancy_head = nn.Linear(hidden_dim, max_occupancy + 1)
        if use_support:
            self.support_head = nn.Linear(hidden_dim, (max_occupancy + 1) ** 2)

    def _encode(self, x: Tensor, valid: Tensor) -> Tensor:
        spatial = self.backbone(self.projection(x, valid))
        if (spatial.ndim != 4 or spatial.shape[1] != self.feature_dim
                or spatial.shape[-1] < 1 or spatial.shape[-2] < 1):
            raise ValueError("V3 backbone must return a nonempty [B,feature_dim,H,W] grid")
        return self.global_mlp(spatial.mean(dim=(-1, -2)))

    def _potentials(self, h: Tensor) -> dict[str, Tensor]:
        presence = self.presence_head(h)
        multiplicity = self.multiplicity_head(h).reshape(-1, self.num_actions, self.max_occupancy)
        # Compute log probabilities in float32 even under autocast. For each
        # action, exp(a0) + sum_{r=1..M} exp(ar) is exactly one up to roundoff.
        p = presence.float()
        a = torch.cat((F.logsigmoid(-p)[..., None],
                       F.logsigmoid(p)[..., None] + F.log_softmax(multiplicity.float(), -1)), -1)
        result = {"a": a, "b": self.occupancy_head(h),
                  "presence": presence, "multiplicity": multiplicity}
        if self.use_support:
            result["d"] = self.support_head(h).reshape(-1, self.max_occupancy + 1,
                                                       self.max_occupancy + 1)
        return result

    def forward(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        h = self._encode(x, valid)
        return {**self._potentials(h), "h": h}

    def predict_potentials(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        return self._potentials(self._encode(x, valid))


def build_v3_model(cfg: dict, initialize_pretrained=True) -> V3CountingModel:
    settings = cfg.get("v3", {})
    validate_v3_settings(settings)
    if cfg.get("model", {}).get("in_channels", 270) != 270:
        raise ValueError("V3 spatial projection requires 270 CSI channels")
    allowed = ("input_view", "hidden_dim", "dropout", "warp_probability", "resolution", "use_support")
    return V3CountingModel(initialize_pretrained=initialize_pretrained,
                           max_occupancy=cfg["model"].get("max_occupancy", 3),
                           num_actions=cfg["model"].get("num_actions", 9),
                           length=cfg.get("max_length", 3000),
                           **{name: settings[name] for name in allowed if name in settings})
