"""AMAR w/o RVQ, independently implemented for the frozen count task.

Source-grounded algorithm adapter, NOT the original experiment reproduction.
See docs/AMAR_ADAPTER.md for provenance and documented source/paper differences.
"""
from __future__ import annotations

from itertools import permutations
import math

import torch
from torch import Tensor, nn
from torch.nn import functional as F


UPSTREAM_COMMIT = "dc47ddb00eaee58e45334930eed24a0e1e547fda"


class MaskedBatchNorm(nn.BatchNorm1d):
    """BatchNorm over valid observations; all-valid behavior matches BatchNorm1d."""

    def forward(self, x: Tensor, valid: Tensor) -> Tensor:
        mask = valid[:, None].to(x.dtype)
        n = mask.sum()
        if self.training:
            mean = (x * mask).sum((0, 2)) / n
            variance = ((x - mean[None, :, None]).square() * mask).sum((0, 2)) / n
            with torch.no_grad():
                self.num_batches_tracked.add_(1)
                factor = self.momentum if self.momentum is not None else 1 / float(self.num_batches_tracked)
                self.running_mean.lerp_(mean.detach().to(self.running_mean), factor)
                # A singleton remains well-defined; no unbiased estimate exists.
                if float(n) > 1:
                    self.running_var.lerp_((variance.detach() * n / (n - 1)).to(self.running_var), factor)
        else:
            mean, variance = self.running_mean, self.running_var
        result = (x - mean[None, :, None]) * torch.rsqrt(variance[None, :, None] + self.eps)
        result = result * self.weight[None, :, None] + self.bias[None, :, None]
        return result.masked_fill(~valid[:, None], 0)


class MaskedConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel, stride=1, dilation=1, separable=True):
        super().__init__()
        self.kernel, self.stride, self.dilation = kernel, stride, dilation
        self.padding = dilation * (kernel // 2)
        if separable:
            self.conv = nn.Sequential(
                nn.Conv1d(in_channels, in_channels, kernel, stride, self.padding,
                          dilation=dilation, groups=in_channels),
                nn.Conv1d(in_channels, out_channels, 1))
        else:
            self.conv = nn.Conv1d(in_channels, out_channels, kernel, stride,
                                  self.padding, dilation=dilation)
        self.norm = MaskedBatchNorm(out_channels)

    def forward(self, x, valid):
        x = self.conv(x.masked_fill(~valid[:, None], 0))
        valid = F.conv1d(valid[:, None].float(), x.new_ones((1, 1, self.kernel)).float(),
                         stride=self.stride, padding=self.padding, dilation=self.dilation)[:, 0] > 0
        return F.relu(self.norm(x, valid)), valid


class AMARBackbone(nn.Module):
    def __init__(self, in_channels=270, width=64, compression_channels=180):
        super().__init__()
        self.blocks = nn.ModuleList([
            MaskedConvBlock(in_channels, compression_channels, 3),
            MaskedConvBlock(compression_channels, width, 5, stride=4),
            MaskedConvBlock(width, width, 5, stride=2),
            *[MaskedConvBlock(width, width, 3, dilation=d, separable=False) for d in (1, 2, 4)],
            MaskedConvBlock(width, width, 5, stride=2),
        ])

    def forward(self, x, valid):
        for block in self.blocks:
            x, valid = block(x, valid)
        return x.transpose(1, 2), valid


class AMAREncoderBlock(nn.Module):
    """Preserve upstream pre-norm block and its enclosing extra residual."""
    def __init__(self, width, heads, dropout):
        super().__init__()
        self.norm_attention = nn.LayerNorm(width, eps=1e-6)
        self.norm_ff = nn.LayerNorm(width, eps=1e-6)
        self.attention = nn.MultiheadAttention(width, heads, dropout=dropout, batch_first=True)
        self.ff = nn.Sequential(nn.Linear(width, width), nn.ReLU(), nn.Dropout(dropout), nn.Linear(width, width))
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, valid):
        q = self.norm_attention(x)
        attended = self.attention(q, q, q, key_padding_mask=~valid, need_weights=False)[0]
        residual = x + self.dropout(attended)
        inner = residual + self.dropout(self.ff(self.norm_ff(residual)))
        return (x + inner).masked_fill(~valid[:, :, None], 0)


class AMARDecoderBlock(nn.Module):
    def __init__(self, width, heads, feedforward, dropout):
        super().__init__()
        self.cross_attention = nn.MultiheadAttention(width, heads, dropout=dropout, batch_first=True)
        self.self_attention = nn.MultiheadAttention(width, heads, dropout=dropout, batch_first=True)
        self.norms = nn.ModuleList([nn.LayerNorm(width) for _ in range(3)])
        self.dropout = nn.Dropout(dropout)
        self.ff = nn.Sequential(nn.Linear(width, feedforward), nn.ReLU(), nn.Dropout(dropout),
                                nn.Linear(feedforward, width))

    def forward(self, state, query, memory, position, valid):
        crossed = self.cross_attention(state + query, memory + position, memory,
                                       key_padding_mask=~valid, need_weights=False)[0]
        state = self.norms[0](state + self.dropout(crossed))
        attended = self.self_attention(state, state, state, need_weights=False)[0]
        state = self.norms[1](state + self.dropout(attended))
        return self.norms[2](state + self.dropout(self.ff(state)))


def _position(memory):
    width = memory.shape[-1]
    t = torch.arange(memory.shape[1], device=memory.device, dtype=torch.float32)[:, None]
    frequency = torch.exp(torch.arange(0, width, 2, device=memory.device) * (-math.log(10000.0) / width))
    angle = t * frequency
    result = memory.new_zeros((1, memory.shape[1], width))
    result[0, :, 0::2] = angle.sin()
    result[0, :, 1::2] = angle.cos()[:, :width // 2]
    return result


class AMARCountAdapter(nn.Module):
    def __init__(self, max_occupancy=3, in_channels=270, width=64, heads=4,
                 encoder_layers=4, decoder_layers=6, feedforward=512,
                 dropout=0.1, encoder_dropout=0.2, compression_channels=180,
                 shared_decoder=True, query_slots=None):
        super().__init__()
        dimensions = (in_channels, width, heads, encoder_layers, decoder_layers, feedforward, compression_channels)
        if any(not isinstance(v, int) or v <= 0 for v in dimensions):
            raise ValueError("AMAR dimensions and depths must be positive integers.")
        if width % heads or max_occupancy not in (3, 5):
            raise ValueError("AMAR width must divide heads; task occupancy must be 3 or 5.")
        if not all(math.isfinite(p) and 0 <= p < 1 for p in (dropout, encoder_dropout)):
            raise ValueError("AMAR dropout probabilities must lie in [0,1).")
        self.in_channels, self.max_occupancy = in_channels, max_occupancy
        self.query_slots = max_occupancy if query_slots is None else query_slots
        if not isinstance(self.query_slots,int) or not max_occupancy <= self.query_slots <= 6:
            raise ValueError("AMAR query_slots must cover task occupancy and be at most 6")
        self.backbone = AMARBackbone(in_channels, width, compression_channels)
        self.encoder = nn.ModuleList([AMAREncoderBlock(width, heads, encoder_dropout) for _ in range(encoder_layers)])
        self.encoder_norm = nn.LayerNorm(width, eps=1e-6)
        self.query = nn.Parameter(torch.randn(self.query_slots, width))
        # The author code repeats one layer object, sharing its parameters.
        first = AMARDecoderBlock(width, heads, feedforward, dropout)
        self.decoder = nn.ModuleList([first if shared_decoder or i == 0 else
                                      AMARDecoderBlock(width, heads, feedforward, dropout)
                                      for i in range(decoder_layers)])
        self.classifier = nn.Linear(width, 10)

    def forward(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        if valid.ndim == 3 and valid.shape[1] == 1:
            valid = valid[:, 0]
        if x.ndim != 3 or x.shape[1] != self.in_channels or valid.shape != (x.shape[0], x.shape[-1]):
            raise ValueError("Expected x=[B,in_channels,T] with valid=[B,T].")
        valid = valid.to(device=x.device, dtype=torch.bool)
        if x.shape[0] == 0 or not bool(valid.any(1).all()):
            raise ValueError("Every AMAR record needs at least one valid sample.")
        x = x.masked_fill(~valid[:, None], 0)
        if not bool(torch.isfinite(x).all()):
            raise ValueError("Nonfinite AMAR input at valid positions.")
        memory, valid = self.backbone(x, valid)
        position = _position(memory).expand(memory.shape[0], -1, -1).masked_fill(~valid[:, :, None], 0)
        memory = (memory + position).masked_fill(~valid[:, :, None], 0)
        for layer in self.encoder:
            memory = layer(memory, valid)
        memory = self.encoder_norm(memory).masked_fill(~valid[:, :, None], 0)
        state = memory.new_zeros((len(x), self.query_slots, memory.shape[-1]))
        outputs = []
        for layer in self.decoder:
            state = layer(state, self.query[None], memory, position, valid)
            outputs.append(self.classifier(state))
        aux = torch.stack(outputs[:-1]) if len(outputs) > 1 else outputs[-1].new_empty((0, *outputs[-1].shape))
        return {"slots": outputs[-1], "aux_slots": aux}

    def predict_potentials(self, x, valid):
        return self(x, valid)


def build_amar(cfg: dict) -> AMARCountAdapter:
    settings = dict(cfg.get("baseline", {}).get("amar", {}))
    return AMARCountAdapter(max_occupancy=cfg["model"]["max_occupancy"],
                            in_channels=cfg["model"].get("in_channels", 270), **settings)


def _targets(counts, slots):
    if counts.ndim != 2 or counts.shape[1] != 9 or counts.is_complex():
        raise ValueError("AMAR targets must be integral nonnegative [B,9].")
    if not bool(torch.isfinite(counts).all()) or bool((counts < 0).any()):
        raise ValueError("AMAR targets must be finite nonnegative counts.")
    if counts.is_floating_point() and not bool((counts == counts.round()).all()):
        raise ValueError("AMAR targets must be integral counts.")
    if bool((counts.sum(1) > slots).any()):
        raise ValueError("AMAR target occupancy exceeds query capacity.")
    rows = []
    for row in counts.detach().cpu().tolist():
        labels = [i for i, value in enumerate(row) for _ in range(int(value))]
        rows.append(labels + [9] * (slots - len(labels)))
    return torch.tensor(rows, dtype=torch.long, device=counts.device)


def amar_set_loss(out: dict[str, Tensor], counts: Tensor, empty_weight=0.25,
                  label_smoothing=0.2, aux_weight=0.25) -> Tensor:
    """Author-code assignment (-probability), followed by weighted smoothed CE.

    Enumerating <=720 permutations is the exact Hungarian optimum for <=6
    slots. Final assignment is detached and reused by every auxiliary layer.
    Weighted CE is normalized per record, then averaged over the batch.
    """
    logits = out["slots"]
    if logits.ndim != 3 or logits.shape[-1] != 10 or not 1 <= logits.shape[1] <= 6 or len(logits) == 0:
        raise ValueError("AMAR logits need shape [B>0,slots<=6,10].")
    if not bool(torch.isfinite(logits).all()):
        raise ValueError("AMAR logits must be finite.")
    if not all(math.isfinite(v) for v in (empty_weight, label_smoothing, aux_weight)) or empty_weight <= 0 or not 0 <= label_smoothing <= 1 or aux_weight < 0:
        raise ValueError("Invalid AMAR loss weights or label smoothing.")
    targets = _targets(counts, logits.shape[1]).to(logits.device)
    if len(targets) != len(logits):
        raise ValueError("AMAR target/logit batch mismatch.")
    with torch.no_grad():
        order = torch.tensor(list(permutations(range(logits.shape[1]))), device=logits.device)
        alternatives = targets[:, order]
        probabilities = logits.detach().float().softmax(-1)
        costs = -probabilities[:, None].expand(-1, len(order), -1, -1).gather(
            -1, alternatives[..., None]).squeeze(-1).sum(-1)
        assigned = alternatives[torch.arange(len(logits), device=logits.device), costs.argmin(1)]
    weights = logits.new_ones(10, dtype=torch.float32)
    weights[9] = empty_weight

    def layer_loss(layer):
        if layer.shape != logits.shape or not bool(torch.isfinite(layer).all()):
            raise ValueError("AMAR auxiliary logits must be finite and match final logits.")
        numerator = F.cross_entropy(layer.float().transpose(1, 2), assigned, weight=weights,
                                    label_smoothing=label_smoothing, reduction="none").sum(1)
        return (numerator / weights[assigned].sum(1)).mean()

    loss = layer_loss(logits)
    auxiliary = out.get("aux_slots")
    if auxiliary is not None:
        if auxiliary.ndim != 4 or auxiliary.shape[1:] != logits.shape:
            raise ValueError("AMAR auxiliary logits need shape [L-1,B,M,10].")
        if len(auxiliary):
            loss = loss + aux_weight * torch.stack([layer_loss(layer) for layer in auxiliary]).mean()
    return loss


def decode_amar(out: dict[str, Tensor]) -> Tensor:
    logits = out["slots"]
    if logits.ndim != 3 or logits.shape[-1] != 10 or not bool(torch.isfinite(logits).all()):
        raise ValueError("AMAR decoding requires finite [B,M,10] logits.")
    return F.one_hot(logits.argmax(-1), 10).sum(1)[:, :9]
