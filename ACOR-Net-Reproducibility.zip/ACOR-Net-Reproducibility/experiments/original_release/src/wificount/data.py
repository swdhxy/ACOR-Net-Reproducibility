"""Strict WiMANS manifests, amplitude loading, and train-only normalization.

The official loader pads axis 0 of [time, 3, 3, 30] amplitude files on the left:
https://github.com/huangshk/WiMANS/blob/main/benchmark/wifi_csi/load_data.py
No zero-valued sample is interpreted as padding here. Converted, pre-padded
arrays must carry their original valid_length in an index CSV or NPZ archive.
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np

ACTIONS = ("jump", "lie_down", "nothing", "pick_up", "rotation", "sit_down",
           "stand_up", "walk", "wave")
ACTION_ORDER = ACTIONS
CHANNELS = 270
PARTITIONS = {"train", "val_unseen", "val_seen", "test_unseen", "test_seen", "val_aux",
              "test_aux", "excluded_4_5"}


class DataValidationError(ValueError):
    """A record violates a declared data contract; it must not be silently used."""


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False).encode("utf-8")).hexdigest()


def canonical_combo(counts: Sequence[int]) -> str:
    return ";".join(f"{action}:{int(count)}" for action, count in zip(ACTIONS, counts)
                    if count) or "EMPTY"


def _integer(value: Any, name: str) -> int:
    if isinstance(value, (bool, np.bool_)):
        raise DataValidationError(f"{name} must be an integer, not a boolean")
    try:
        converted = int(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise DataValidationError(f"Invalid integer {name}={value!r}") from error
    if isinstance(value, (float, np.floating)) and converted != value:
        raise DataValidationError(f"Nonintegral {name}={value!r}")
    return converted


def read_manifest(path: str | Path, max_occupancy: int | None = 3) -> list[dict]:
    """Validate the entire CSV, then return records in the requested task scope.

    With ``max_occupancy=None``, excluded 4/5-person rows are also returned for
    audits. This does not turn these rows into training samples. Statistical
    protocol failures such as lost support are reported by ``audit_metadata``;
    malformed labels and duplicate IDs fail immediately here.
    """
    path = Path(path).resolve()
    manifest_hash = sha256_file(path)
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        required = {"record_id", "partition", "combo_id", "number_of_users",
                    "environment", "wifi_band", *(f"count_{a}" for a in ACTIONS)}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise DataValidationError(f"Missing manifest columns: {sorted(missing)}")
        raw = list(reader)
    if not raw:
        raise DataValidationError("Manifest contains no records")
    seen: set[str] = set()
    records = []
    for line, source in enumerate(raw, 2):
        row = dict(source)
        rid = str(row["record_id"]).strip()
        if not rid or not re.fullmatch(r"[A-Za-z0-9_.-]+", rid) or rid in {".", ".."}:
            raise DataValidationError(f"Line {line}: unsafe or empty record_id {rid!r}")
        if rid in seen:
            raise DataValidationError(f"Duplicate record_id {rid!r} at line {line}")
        seen.add(rid)
        counts = [_integer(row[f"count_{a}"], f"{rid}/count_{a}") for a in ACTIONS]
        n = _integer(row["number_of_users"], f"{rid}/number_of_users")
        if not 0 <= n <= 5 or any(c < 0 for c in counts) or sum(counts) != n:
            raise DataValidationError(f"{rid}: nonnegative counts must sum to n={n}; got {counts}")
        if row["combo_id"] != canonical_combo(counts):
            raise DataValidationError(f"{rid}: combo_id does not match canonical count vector")
        partition = str(row["partition"])
        if partition not in PARTITIONS:
            raise DataValidationError(f"{rid}: unknown partition {partition!r}")
        if not row["environment"] or not row["wifi_band"]:
            raise DataValidationError(f"{rid}: environment and wifi_band must be explicit")
        if partition.startswith("excluded") and n not in (4, 5):
            raise DataValidationError(f"{rid}: excluded_4_5 must have occupancy 4 or 5")
        if max_occupancy is not None and n > max_occupancy and not partition.startswith("excluded"):
            raise DataValidationError(f"{rid}: n={n} exceeds M={max_occupancy} without excluded partition")
        if partition in {"val_unseen", "val_seen", "test_unseen", "test_seen"} and n not in (2, 3):
            raise DataValidationError(f"{rid}: core evaluation must have occupancy 2 or 3")
        if partition in {"val_aux", "test_aux"} and n not in (0, 1):
            raise DataValidationError(f"{rid}: auxiliary evaluation must have occupancy 0 or 1")
        if row.get("combo_partition"):
            expected_combo_partition = ("auxiliary" if n <= 1 else
                                        "train_combo" if partition in {"train", "val_seen", "test_seen"} else
                                        partition)
            # The frozen file names out-of-task combinations "excluded".
            if partition.startswith("excluded"):
                expected_combo_partition = "excluded"
            if row["combo_partition"] != expected_combo_partition:
                raise DataValidationError(f"{rid}: combo_partition conflicts with record partition")
        parsed = re.fullmatch(r"act_(\d+)_(\d+)", rid)
        derived_group = parsed.group(1) if parsed else "UNVERIFIED"
        supplied_group = str(row.get("user_group_id", "")).strip()
        if supplied_group and derived_group != "UNVERIFIED" and supplied_group != derived_group:
            raise DataValidationError(f"{rid}: supplied user_group_id conflicts with record ID")
        row.update(record_id=rid, counts=counts, n=n,
                   user_group_id=supplied_group or derived_group,
                   _manifest_sha256=manifest_hash, _manifest_path=str(path))
        if max_occupancy is None or (n <= max_occupancy and not partition.startswith("excluded")):
            records.append(row)
    if not records:
        raise DataValidationError("No records remain in the requested occupancy scope")
    return records


def _longest_run(mask: np.ndarray) -> int:
    padded = np.concatenate(([False], np.asarray(mask, dtype=bool), [False]))
    edges = np.flatnonzero(padded[1:] != padded[:-1])
    return int((edges[1::2] - edges[::2]).max(initial=0))


class WaveformStore:
    """Read raw amplitude NPY/NPZ files without inferring masks from values.

    ``layout`` is ``wimans`` (T,3,3,30), ``tc`` (T,270), or ``ct`` (270,T).
    ``auto`` accepts only the official 4-D shape; it never guesses a 2-D axis.
    Index columns: record_id,path[,valid_length,layout]. Relative paths resolve
    against ``root``. NPZ fields: amplitude[,valid_length]. When valid_length is
    shorter than the stored time dimension, *left padding* is explicitly assumed.
    """

    def __init__(self, root: str | Path, index_path: str | Path | None = None,
                 layout: str = "auto", max_length: int = 3000,
                 nonfinite_fraction_max: float = 0.01,
                 nonfinite_contiguous_samples_max: int = 50):
        self.root = Path(root).resolve()
        self.layout = self._layout_name(layout)
        self.max_length = _integer(max_length, "max_length")
        self.nonfinite_fraction_max = float(nonfinite_fraction_max)
        self.nonfinite_contiguous_samples_max = _integer(
            nonfinite_contiguous_samples_max, "nonfinite_contiguous_samples_max")
        if self.max_length <= 0 or not 0 <= self.nonfinite_fraction_max <= 1:
            raise ValueError("max_length must be positive and missing fraction must be in [0,1]")
        if self.nonfinite_contiguous_samples_max < 0:
            raise ValueError("Contiguous missing-sample limit must be nonnegative")
        self.index: dict[str, dict] = {}
        self.index_path = Path(index_path).resolve() if index_path else None
        self.index_sha256 = sha256_file(self.index_path) if self.index_path else None
        if self.index_path:
            with self.index_path.open(encoding="utf-8-sig", newline="") as stream:
                reader = csv.DictReader(stream)
                if not {"record_id", "path"} <= set(reader.fieldnames or []):
                    raise DataValidationError("Waveform index requires record_id,path columns")
                for row in reader:
                    rid = row["record_id"]
                    if not rid or rid in self.index or not row["path"]:
                        raise DataValidationError(f"Duplicate/empty waveform index row: {rid!r}")
                    self.index[rid] = dict(row)

    @staticmethod
    def _layout_name(layout: str) -> str:
        aliases = {"t_3_3_30": "wimans", "time_tx_rx_subcarrier": "wimans",
                   "time_channel": "tc", "channel_time": "ct"}
        layout = aliases.get(str(layout).lower(), str(layout).lower())
        if layout not in {"auto", "wimans", "tc", "ct"}:
            raise DataValidationError(f"Unknown layout {layout!r}; use wimans, tc, or ct")
        return layout

    def preprocessing_spec(self) -> dict:
        return {"schema_version": 1, "channels": CHANNELS, "layout": self.layout,
                "max_length": self.max_length, "padding": "left_from_original_length",
                "long_sequence": "first_max_length_valid_points", "transform": "log1p",
                "nonfinite_fraction_max": self.nonfinite_fraction_max,
                "nonfinite_contiguous_samples_max": self.nonfinite_contiguous_samples_max,
                "negative_amplitude": "reject", "all_zero_channel": "audit_warning",
                "repair": "per_channel_linear_nearest_endpoint",
                "index_sha256": self.index_sha256}

    def resolve_path(self, record: Mapping[str, Any] | str) -> Path:
        rid = record if isinstance(record, str) else str(record["record_id"])
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", rid) or rid in {".", ".."}:
            raise DataValidationError(f"Unsafe record_id {rid!r}")
        if self.index_path:
            if rid not in self.index:
                raise FileNotFoundError(f"{rid}: no row in waveform index {self.index_path}")
            path = Path(self.index[rid]["path"])
            path = path if path.is_absolute() else self.root / path
            if not path.is_file():
                raise FileNotFoundError(f"{rid}: waveform file missing: {path}")
            return path.resolve()
        candidates = [self.root / f"{rid}{suffix}" for suffix in (".npy", ".npz")]
        found = [p for p in candidates if p.is_file()]
        if not found:
            raise FileNotFoundError(f"{rid}: no .npy/.npz amplitude file under {self.root}; "
                                    "download and point to real WiMANS amplitude files")
        if len(found) != 1:
            raise DataValidationError(f"{rid}: both .npy and .npz exist; supply an explicit index")
        return found[0].resolve()

    def _to_channels_time(self, array: np.ndarray, layout: str, rid: str) -> np.ndarray:
        if array.dtype.kind not in "fiu" or np.iscomplexobj(array):
            raise DataValidationError(f"{rid}: expected real numeric amplitude, got {array.dtype}")
        if layout == "auto":
            if array.ndim != 4 or array.shape[1:] != (3, 3, 30):
                raise DataValidationError(f"{rid}: ambiguous/unrecognized shape {array.shape}; "
                                          "set layout='tc' or 'ct' explicitly for converted arrays")
            layout = "wimans"
        if layout == "wimans":
            if array.ndim != 4 or array.shape[1:] != (3, 3, 30):
                raise DataValidationError(f"{rid}: wimans layout requires [T,3,3,30], got {array.shape}")
            return np.asarray(array.reshape(array.shape[0], CHANNELS).T, dtype=np.float64)
        if layout == "tc":
            if array.ndim != 2 or array.shape[1] != CHANNELS:
                raise DataValidationError(f"{rid}: tc layout requires [T,270], got {array.shape}")
            return np.asarray(array.T, dtype=np.float64)
        if array.ndim != 2 or array.shape[0] != CHANNELS:
            raise DataValidationError(f"{rid}: ct layout requires [270,T], got {array.shape}")
        return np.asarray(array, dtype=np.float64)

    def load_detailed(self, record: Mapping[str, Any] | str, *, hashes: bool = False
                      ) -> tuple[np.ndarray, np.ndarray, dict]:
        rid = record if isinstance(record, str) else str(record["record_id"])
        path = self.resolve_path(record)
        row = self.index.get(rid, {})
        return self._read_path(rid, path, row, hashes)

    def load_file(self, path: str | Path) -> tuple[np.ndarray, np.ndarray]:
        """Read precisely the selected standalone file, without ID lookup.

        Index metadata is deliberately not applied to a standalone inference
        file. An NPZ can carry its own explicit valid_length.
        """
        path = Path(path).resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        amplitude, valid, _ = self._read_path(path.stem, path, {}, False)
        return amplitude, valid

    def _read_path(self, rid: str, path: Path, row: Mapping, hashes: bool):
        layout = self._layout_name(row.get("layout") or self.layout)
        archive_length = None
        if path.suffix.lower() == ".npy":
            array = np.load(path, mmap_mode="r", allow_pickle=False)
        elif path.suffix.lower() == ".npz":
            with np.load(path, allow_pickle=False) as archive:
                if "amplitude" not in archive:
                    raise DataValidationError(f"{rid}: NPZ must contain 'amplitude'")
                array = archive["amplitude"]
                if "valid_length" in archive:
                    stored = archive["valid_length"]
                    if stored.size != 1:
                        raise DataValidationError(f"{rid}: valid_length must be scalar")
                    archive_length = _integer(stored.item(), f"{rid}/valid_length")
        else:
            raise DataValidationError(f"{rid}: unsupported suffix {path.suffix}; use .npy or .npz")
        amplitude = self._to_channels_time(array, layout, rid)
        stored_length = int(amplitude.shape[1])
        index_length = (_integer(row["valid_length"], f"{rid}/index_valid_length")
                        if row.get("valid_length", "") != "" else None)
        if index_length is not None and archive_length is not None and index_length != archive_length:
            raise DataValidationError(f"{rid}: NPZ and CSV valid_length disagree")
        valid_length = index_length if index_length is not None else archive_length
        if valid_length is None:
            valid_length = stored_length
        if not 0 < valid_length <= stored_length:
            raise DataValidationError(f"{rid}: valid_length={valid_length} outside 1..{stored_length}")
        # Explicit left-padding convention. Never inspect zeros to locate this slice.
        amplitude = np.array(amplitude[:, stored_length - valid_length:], dtype=np.float64, copy=True)
        bad = ~np.isfinite(amplitude)
        if np.any(amplitude[np.isfinite(amplitude)] < 0):
            raise DataValidationError(f"{rid}: negative amplitude values; do not apply abs() to conceal bad input")
        if np.any(np.all(bad, axis=1)):
            raise DataValidationError(f"{rid}: at least one channel has no finite samples")
        bad_fraction = float(bad.mean())
        longest = max((_longest_run(channel) for channel in bad), default=0)
        if bad_fraction > self.nonfinite_fraction_max + 1e-15:
            raise DataValidationError(f"{rid}: nonfinite fraction {bad_fraction:.6f} exceeds "
                                      f"{self.nonfinite_fraction_max}")
        if longest > self.nonfinite_contiguous_samples_max:
            raise DataValidationError(f"{rid}: missing run {longest} exceeds "
                                      f"{self.nonfinite_contiguous_samples_max}")
        info = {"record_id": rid, "path": str(path), "stored_length": stored_length,
                "original_valid_length": valid_length,
                "explicit_valid_length": index_length is not None or archive_length is not None,
                "used_length": min(valid_length, self.max_length),
                "left_padding": max(0, self.max_length - valid_length),
                "truncated_points": max(0, valid_length - self.max_length),
                "nonfinite_count": int(bad.sum()), "nonfinite_fraction": bad_fraction,
                "longest_nonfinite_run": longest,
                "zero_channels": int(np.all(amplitude == 0, axis=1).sum())}
        if hashes:
            # Canonical raw valid amplitude catches copied arrays across containers.
            canonical = np.ascontiguousarray(amplitude, dtype="<f8")
            canonical[~np.isfinite(canonical)] = np.nan
            digest = hashlib.sha256()
            digest.update(str(canonical.shape).encode("ascii"))
            digest.update(canonical.tobytes())
            info["file_sha256"] = sha256_file(path)
            info["raw_valid_amplitude_sha256"] = digest.hexdigest()
        if bad.any():
            time = np.arange(valid_length)
            for channel in np.flatnonzero(bad.any(axis=1)):
                good = ~bad[channel]
                amplitude[channel, bad[channel]] = np.interp(time[bad[channel]], time[good],
                                                            amplitude[channel, good])
        amplitude = amplitude[:, :self.max_length]
        if np.any(amplitude > np.finfo(np.float32).max):
            raise DataValidationError(f"{rid}: amplitude exceeds float32 range")
        used = amplitude.shape[1]
        output = np.zeros((CHANNELS, self.max_length), dtype=np.float32)
        output[:, -used:] = amplitude.astype(np.float32)
        mask = np.zeros(self.max_length, dtype=bool)
        mask[-used:] = True
        if hashes:
            digest = hashlib.sha256()
            digest.update(output.tobytes())
            digest.update(mask.tobytes())
            info["model_input_sha256"] = digest.hexdigest()
        return output, mask, info

    def load(self, record: Mapping[str, Any] | str) -> tuple[np.ndarray, np.ndarray]:
        amplitude, valid, _ = self.load_detailed(record)
        return amplitude, valid


def _training_identity(records: Sequence[Mapping[str, Any]]) -> dict:
    if not records or any(r["partition"] != "train" for r in records):
        raise DataValidationError("Normalization fitting requires a nonempty, train-only record list")
    ids = sorted(str(r["record_id"]) for r in records)
    if len(ids) != len(set(ids)):
        raise DataValidationError("Normalization training IDs are duplicated")
    manifest_hashes = {r.get("_manifest_sha256") for r in records}
    if len(manifest_hashes) != 1 or None in manifest_hashes:
        raise DataValidationError("Use records returned by read_manifest from one manifest")
    label_records = sorted((r["record_id"], list(r["counts"]), r["partition"]) for r in records)
    return {"manifest_sha256": next(iter(manifest_hashes)), "training_record_ids": ids,
            "training_record_ids_sha256": _json_hash(ids),
            "training_records_sha256": _json_hash(label_records),
            "training_occupancies": sorted({int(r["n"]) for r in records})}


def fit_normalization(records: Sequence[Mapping[str, Any]], store: WaveformStore,
                      output: str | Path | None = None, *, std_floor: float = 1e-6) -> dict:
    """Streaming population moments of log1p amplitude from valid training points.

    All records must pass; this function never silently excludes missing or bad
    files. Train-only subset changes (including no_aux) require fresh statistics.
    """
    identity = _training_identity(records)
    if not np.isfinite(std_floor) or std_floor <= 0:
        raise ValueError("std_floor must be positive and finite")
    mean = np.zeros(CHANNELS, dtype=np.float64)
    m2 = np.zeros(CHANNELS, dtype=np.float64)
    count = 0
    waveform_hashes = []
    for record in sorted(records, key=lambda r: r["record_id"]):
        amplitude, valid, info = store.load_detailed(record, hashes=True)
        values = np.log1p(amplitude[:, valid].astype(np.float64))
        n = values.shape[1]
        local_mean = values.mean(axis=1)
        local_m2 = ((values - local_mean[:, None]) ** 2).sum(axis=1)
        delta = local_mean - mean
        total = count + n
        m2 += local_m2 + delta * delta * count * n / total
        mean += delta * n / total
        count = total
        waveform_hashes.append([record["record_id"], info["file_sha256"]])
    std = np.maximum(np.sqrt(np.maximum(m2 / count, 0.0)), std_floor)
    stats = {"schema_version": 1, "action_order": list(ACTIONS), "channels": CHANNELS,
             "transform": "log1p", "mean": mean.tolist(), "std": std.tolist(),
             "std_floor": std_floor, "valid_points_per_channel": count,
             "num_records": len(records), "preprocessing": store.preprocessing_spec(),
             "training_waveforms_sha256": _json_hash(waveform_hashes),
             "training_file_sha256": dict(waveform_hashes), **identity}
    stats["normalization_sha256"] = _json_hash(stats)
    if output is not None:
        from .config import write_json
        write_json(output, stats)
    return stats


def read_normalization(stats: Mapping[str, Any] | str | Path) -> dict:
    return (dict(stats) if isinstance(stats, Mapping)
            else json.loads(Path(stats).read_text(encoding="utf-8")))


def validate_normalization(stats: Mapping[str, Any] | str | Path,
                           training_records: Sequence[Mapping[str, Any]],
                           store: WaveformStore, *, verify_files: bool = False) -> dict:
    """Reject statistics from another fold, training subset, or preprocessing."""
    stats = read_normalization(stats)
    fingerprint = stats.get("normalization_sha256")
    payload = {k: v for k, v in stats.items() if k != "normalization_sha256"}
    if fingerprint != _json_hash(payload):
        raise DataValidationError("Normalization content checksum is invalid")
    for name, expected in _training_identity(training_records).items():
        if stats.get(name) != expected:
            raise DataValidationError(f"Normalization {name} does not match this training fold/subset")
    if stats.get("preprocessing") != store.preprocessing_spec():
        raise DataValidationError("Normalization preprocessing specification does not match this store")
    mean = np.asarray(stats.get("mean"), dtype=float)
    std = np.asarray(stats.get("std"), dtype=float)
    if mean.shape != (CHANNELS,) or std.shape != (CHANNELS,):
        raise DataValidationError("Normalization mean/std must each have 270 entries")
    if not np.isfinite(mean).all() or not np.isfinite(std).all() or np.any(std <= 0):
        raise DataValidationError("Normalization statistics must be finite, with positive std")
    if verify_files:
        for record in training_records:
            rid = record["record_id"]
            if sha256_file(store.resolve_path(record)) != stats["training_file_sha256"].get(rid):
                raise DataValidationError(f"{rid}: training waveform changed after normalization")
    return stats


class CSIDataset:
    """Map-style PyTorch dataset; Torch is imported only when tensors are needed.

    Evaluation datasets require the expected training list to prevent accidental
    reuse of all-auxiliary normalization in a no_aux experiment, or another fold.
    """

    def __init__(self, records: Sequence[Mapping[str, Any]], store: WaveformStore,
                 stats: Mapping[str, Any] | str | Path,
                 expected_train_records: Sequence[Mapping[str, Any]] | None = None):
        self.records = list(records)
        self.store = store
        if not self.records:
            raise DataValidationError("Cannot construct an empty CSI dataset")
        if expected_train_records is None:
            if any(r["partition"] != "train" for r in self.records):
                raise DataValidationError("Evaluation datasets require expected_train_records")
            expected_train_records = self.records
        self.stats = validate_normalization(stats, expected_train_records, store)
        if any(r.get("_manifest_sha256") != self.stats["manifest_sha256"] for r in self.records):
            raise DataValidationError("Dataset and normalization originate from different manifests")
        self.mean = np.asarray(self.stats["mean"], dtype=np.float64)[:, None]
        self.std = np.asarray(self.stats["std"], dtype=np.float64)[:, None]

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> dict:
        import torch

        record = self.records[index]
        amplitude, valid = self.store.load(record)
        values = (np.log1p(amplitude.astype(np.float64)) - self.mean) / self.std
        values[:, ~valid] = 0.0
        if not np.isfinite(values).all() or np.any(np.abs(values) > np.finfo(np.float32).max):
            raise DataValidationError(f"{record['record_id']}: nonfinite/overflow normalized input")
        return {"X": torch.from_numpy(values.astype(np.float32)),
                "valid": torch.from_numpy(valid),
                "counts": torch.tensor(record["counts"], dtype=torch.long),
                "meta": dict(record)}


def collate_records(items: Sequence[Mapping[str, Any]]) -> dict:
    import torch

    if not items:
        raise DataValidationError("Cannot collate an empty batch")
    return {"X": torch.stack([item["X"] for item in items]),
            "valid": torch.stack([item["valid"] for item in items]),
            "counts": torch.stack([item["counts"] for item in items]),
            "meta": [item["meta"] for item in items]}
