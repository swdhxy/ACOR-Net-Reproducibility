"""Command-line entry points. Synthetic fixtures are always explicit."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from .config import ROOT, METHODS, load_config, write_json


def _csv_ints(value): return [int(v) for v in value.split(",")]


def main(argv=None):
    parser=argparse.ArgumentParser(prog="wificount",description="WiMANS unseen-composition activity counting")
    sub=parser.add_subparsers(dest="command",required=True)
    def common(p):
        p.add_argument("--config",default=str(ROOT/"configs/default.yaml"))
        p.add_argument("--manifest");p.add_argument("--data-root");p.add_argument("--output")
    p=sub.add_parser("audit",help="Audit metadata or supplied amplitude files; never auto-delete")
    common(p);p.add_argument("--metadata-only",action="store_true");p.add_argument("--no-aux",action="store_true")
    p=sub.add_parser("train",help="Train with val_unseen selection; does not evaluate test")
    common(p);p.add_argument("--method",choices=METHODS);p.add_argument("--seed",type=int)
    p.add_argument("--device");p.add_argument("--resume");p.add_argument("--no-aux",action="store_true")
    p.add_argument("--epochs",type=int);p.add_argument("--batch-size",type=int);p.add_argument("--lr",type=float)
    p.add_argument("--gamma",type=float)
    p=sub.add_parser("evaluate",help="Explicitly evaluate one checkpoint and one held-out partition")
    p.add_argument("--checkpoint",required=True);p.add_argument("--partition",default="test_unseen")
    p.add_argument("--output");p.add_argument("--data-root");p.add_argument("--device",default="auto")
    p=sub.add_parser("infer",help="Predict a standalone amplitude file without labels")
    p.add_argument("--checkpoint",required=True);p.add_argument("--input",required=True)
    p.add_argument("--layout",default="auto");p.add_argument("--output");p.add_argument("--device",default="auto")
    p=sub.add_parser("smoke",help="Generate explicitly synthetic fixtures and exercise the pipeline")
    p.add_argument("--output",default=str(ROOT/"runs/smoke"));p.add_argument("--all-methods",action="store_true")
    p=sub.add_parser("profile",help="Measure forward/backward cost using explicitly synthetic inputs")
    common(p);p.add_argument("--steps",type=int,default=10);p.add_argument("--batch-size",type=int,default=2)
    p.add_argument("--device",default="cpu")
    p=sub.add_parser("plan",help="Freeze a search, core, or ablation plan without starting training")
    common(p);p.add_argument("--stage",choices=["search","core","ablations"],default="search")
    p.add_argument("--methods",default="b1,b2,b3,b4,b5,ours")
    p.add_argument("--splits",type=_csv_ints,default=[2026,2027,2028]);p.add_argument("--seeds",type=_csv_ints,default=[11,22,33])
    p.add_argument("--selection");p.add_argument("--run-root",default=str(ROOT/"runs/matrix"))
    p=sub.add_parser("run-plan",help="Dry-run by default; --execute starts queued training jobs")
    p.add_argument("--plan",required=True);p.add_argument("--execute",action="store_true");p.add_argument("--max-jobs",type=int)
    p=sub.add_parser("select",help="Select each method inside its own split using completed validation results")
    p.add_argument("--plan",required=True);p.add_argument("--output",required=True)
    p=sub.add_parser("compare",help="Paired, within-split descriptive composition bootstrap")
    p.add_argument("--a",nargs="+",required=True);p.add_argument("--b",nargs="+",required=True)
    p.add_argument("--replicates",type=int,default=2000);p.add_argument("--output",required=True)
    p=sub.add_parser("score-predictions",help="Score external predictions with exact frozen record coverage")
    p.add_argument("--manifest",required=True);p.add_argument("--predictions",required=True)
    p.add_argument("--partition",default="test_unseen");p.add_argument("--output",required=True)
    p=sub.add_parser("freeze",help="Freeze all completed selected experiments before opening held-out tests")
    p.add_argument("--plans",nargs="+",required=True);p.add_argument("--audits",nargs="+",required=True)
    p.add_argument("--output",required=True)
    p=sub.add_parser("evaluate-plan",help="Evaluate all frozen selected runs; verify existing results on restart")
    p.add_argument("--plans",nargs="+",required=True);p.add_argument("--freeze",required=True)
    p.add_argument("--device",default="auto")
    p=sub.add_parser("summarize",help="Export per-initialization and per-split result tables")
    p.add_argument("--plans",nargs="+",required=True);p.add_argument("--output",required=True)
    p.add_argument("--freeze",help="Verify the frozen protocol and numerical runtime before producing formal tables")
    p=sub.add_parser("support-audit",help="Audit count/background support and optional actual training exposures")
    p.add_argument("--manifest",required=True);p.add_argument("--output",required=True)
    p.add_argument("--no-aux",action="store_true");p.add_argument("--run-directory")
    p=sub.add_parser("stress-manifest",help="Create a separate source-only-validation held-environment protocol")
    p.add_argument("--manifest",required=True);p.add_argument("--environment",required=True)
    p.add_argument("--output",required=True)
    p=sub.add_parser("diagnose-representation",help="Validation-only action embedding retrieval from a training bank")
    p.add_argument("--checkpoint",required=True);p.add_argument("--output",required=True)
    p.add_argument("--device",default="auto");p.add_argument("--representation",choices=("z","p"),default="z")
    args=parser.parse_args(argv)
    try:
        result=dispatch(args)
        if result is not None: print(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
        if args.command=="audit" and not result["ok"]:
            parser.exit(2,"Audit failed; review the saved audit before training.\n")
    except (ValueError,FileNotFoundError,FileExistsError,RuntimeError) as exc:
        parser.exit(2,f"Error: {exc}\n")


def configured(args):
    changes={}
    for key in ("manifest","data_root","output"):
        if getattr(args,key,None): changes[key]=str(Path(getattr(args,key)).resolve())
    if getattr(args,"manifest",None):
        match=re.fullmatch(r"sample_manifest_seed(\d+)\.csv",Path(args.manifest).name)
        if match: changes["split_seed"]=int(match.group(1))
    for key in ("method","device"):
        if getattr(args,key,None) is not None: changes[key]=getattr(args,key)
    if getattr(args,"seed",None) is not None: changes["model_seed"]=args.seed
    if getattr(args,"no_aux",False): changes["no_aux"]=True
    training={}
    for arg,key in (("epochs","epochs"),("batch_size","batch_size"),("lr","learning_rate"),("gamma","gamma")):
        if getattr(args,arg,None) is not None: training[key]=getattr(args,arg)
    if "batch_size" in training:
        training["target_groups"]=max(1,min(4,training["batch_size"]//16))
    if training: changes["training"]=training
    return load_config(args.config,changes)


def dispatch(args):
    if args.command=="support-audit":
        from .research_checks import support_audit
        return support_audit(args.manifest,args.output,args.no_aux,args.run_directory)
    if args.command=="stress-manifest":
        from .research_checks import make_environment_stress
        return make_environment_stress(args.manifest,args.environment,args.output)
    if args.command=="diagnose-representation":
        from .research_checks import diagnose_representation
        return diagnose_representation(args.checkpoint,args.output,args.device,args.representation)
    if args.command=="freeze":
        from .reporting import freeze_runs
        return freeze_runs(args.plans,args.audits,args.output)
    if args.command=="evaluate-plan":
        from .reporting import evaluate_plans
        return evaluate_plans(args.plans,args.freeze,args.device)
    if args.command=="summarize":
        from .reporting import summarize_plans
        return summarize_plans(args.plans,args.output,freeze_path=args.freeze)
    if args.command=="audit":
        from .audit import audit_dataset
        from .data import WaveformStore
        cfg=configured(args)
        store=None if args.metadata_only else WaveformStore(cfg["data_root"],cfg.get("data_index"),layout=cfg["layout"],max_length=cfg["max_length"])
        destination=args.output or str(ROOT/"runs"/f"audit_seed{cfg['split_seed']}")
        return audit_dataset(cfg["manifest"],store,destination,metadata_only=args.metadata_only,
                             no_aux=cfg["no_aux"],max_occupancy=cfg["model"]["max_occupancy"])
    if args.command=="train":
        from .engine import train
        return train(configured(args),resume=args.resume)
    if args.command=="evaluate":
        from .engine import evaluate
        return evaluate(args.checkpoint,args.partition,args.output,args.data_root,args.device)
    if args.command=="infer":
        from .inference import predict_file
        result=predict_file(args.checkpoint,args.input,args.layout,args.device)
        if args.output: write_json(args.output,result)
        return result
    if args.command=="smoke":
        from .smoke import run_smoke
        return run_smoke(args.output,args.all_methods)
    if args.command=="profile":
        from .smoke import profile_model
        result=profile_model(configured(args),args.steps,args.batch_size,args.device)
        if args.output: write_json(args.output,result)
        return result
    if args.command=="plan":
        from .experiments import make_plan
        selection=json.loads(Path(args.selection).read_text(encoding="utf-8")) if args.selection else None
        result=make_plan(configured(args),args.stage,args.run_root,args.methods.split(","),args.splits,args.seeds,selection)
        destination=args.output or str(ROOT/"runs"/f"{args.stage}_plan.json")
        write_json(destination,result)
        return {"plan":destination,"job_count":result["job_count"],"test_execution":False}
    if args.command=="run-plan":
        from .experiments import run_plan
        return run_plan(json.loads(Path(args.plan).read_text(encoding="utf-8")),args.execute,args.max_jobs)
    if args.command=="select":
        from .experiments import select_search
        result=select_search(json.loads(Path(args.plan).read_text(encoding="utf-8")))
        write_json(args.output,result);return {"selection":args.output,"groups":len(result["selected"])}
    if args.command=="compare":
        from .engine import load_predictions
        from .metrics import paired_bootstrap
        a=[r for p in args.a for r in load_predictions(p)]
        b=[r for p in args.b for r in load_predictions(p)]
        result=paired_bootstrap(a,b,replicates=args.replicates)
        write_json(args.output,result);return result
    if args.command=="score-predictions":
        from .inference import score_external
        result=score_external(args.manifest,args.predictions,args.partition)
        write_json(args.output,result);return result

