"""Pretrained spatial evidence and action-specific pooling for V2 development.

This is an experimental extension, not a claim of improved accuracy.  Inputs
remain amplitude and an explicit validity mask; labels, occupancy and identities
are never arguments to inference.  The amplitude/global configuration is a
predefined pretrained structured control, with query pooling and multiview
inputs exposed separately for ablation.
"""

from __future__ import annotations

import math

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from .domain_adapters import CSISpatialProjection, _reflect_to_length, _validated_input


class CSIMultiviewProjection(nn.Module):
    """Preserve amplitude alongside temporal residual and first-difference views.

    The first view retains train-normalized absolute amplitude information for
    occupancy. The other views suppress record-specific constant offsets. They
    share a per-record residual RMS scale floored at one in the normalized input
    units: a nearly constant record is never amplified by a tiny variance.
    Views are formed from real valid points before reflection. Spatial geometry
    matches the existing comparator: image height is time and width is channel.
    """

    def __init__(self, *, warp_probability=0.5, warp_range=(0.95, 1.05),
                 length=3000, resolution=270):
        super().__init__()
        if (not math.isfinite(warp_probability) or not 0 <= warp_probability <= 1
                or len(warp_range) != 2
                or not all(math.isfinite(x) for x in warp_range)
                or not 0 < warp_range[0] <= warp_range[1]):
            raise ValueError("Invalid temporal warping parameters")
        if length < 1 or resolution < 1:
            raise ValueError("Projection dimensions must be positive")
        self.warp_probability = float(warp_probability)
        self.warp_range = tuple(warp_range)
        self.length, self.resolution = int(length), int(resolution)
        self.mix = nn.Conv2d(3, 3, 1)
        with torch.no_grad():
            self.mix.weight.copy_(torch.eye(3).reshape(3, 3, 1, 1))
            self.mix.bias.zero_()

    @staticmethod
    def views(signal: Tensor) -> Tensor:
        """Three [channel,time] views with no estimated test-set statistics."""
        residual = signal - signal.mean(dim=-1, keepdim=True)
        scale = residual.square().mean().clamp_min(1.0).sqrt()
        difference = torch.cat((torch.zeros_like(signal[:, :1]),
                                signal[:, 1:] - signal[:, :-1]), dim=-1)
        return torch.stack((signal, residual / scale, difference / scale))

    def forward(self, x: Tensor, valid: Tensor) -> Tensor:
        x, valid = _validated_input(x, valid)
        images = []
        for signal, mask in zip(x, valid):
            positions = mask.nonzero(as_tuple=False).flatten()
            if int(positions[-1] - positions[0] + 1) != len(positions):
                raise ValueError("Spatial projection requires one contiguous valid interval")
            signal = signal[:, positions[0]:positions[-1] + 1]
            if self.training and bool(torch.rand((), device=x.device) < self.warp_probability):
                scale = float(torch.empty((), device=x.device).uniform_(*self.warp_range))
                target_length = max(1, round(signal.shape[-1] * scale))
                signal = F.interpolate(signal[None], size=target_length,
                                       mode="linear", align_corners=False)[0]
            views = _reflect_to_length(self.views(signal), self.length)
            image = F.interpolate(views.transpose(-1, -2)[None],
                                  size=(self.resolution, self.resolution),
                                  mode="bicubic", align_corners=False, antialias=True)
            images.append(image[0])
        return self.mix(torch.stack(images))


def _pretrained_spatial_backbone(initialize_pretrained: bool):
    # Reuse the existing official-URL and checkpoint-hash validation. During
    # checkpoint restoration only, random construction is followed by strict load.
    from .domain_adapters import _convnext_tiny
    backbone, dimension = _convnext_tiny(initialize_pretrained)
    # ConvNeXt's classifier normalization is channel LayerNorm2d. Applied before
    # pooling, it keeps the same pretrained per-channel affine parameters while
    # retaining the spatial feature grid for action queries.
    return nn.Sequential(backbone.features, backbone.classifier[0]), dimension


class V2CountingModel(nn.Module):
    """ConvNeXt spatial features -> global or per-action evidence -> legal counts.

    ``backbone`` injection is exclusively for software tests, and must return
    [B,feature_dim,H,W]. Production builders always request the verified official
    pretrained ConvNeXt-Tiny weights. Outputs preserve the existing a/b/h/z/p
    interface, allowing the original legal candidate decoder and contrast audit.
    """

    def __init__(self, *, initialize_pretrained=True, backbone=None, feature_dim=None,
                 pooling="query", input_view="amplitude", feature_width=128,
                 attention_heads=4, dropout=0.1, warp_probability=0.5,
                 resolution=270, length=3000, max_occupancy=3, num_actions=9):
        super().__init__()
        if pooling not in {"global", "query"}:
            raise ValueError("pooling must be global or query")
        if input_view not in {"amplitude", "multiview"}:
            raise ValueError("input_view must be amplitude or multiview")
        if (feature_width < 1 or attention_heads < 1 or feature_width % attention_heads
                or not math.isfinite(dropout) or not 0 <= dropout < 1
                or max_occupancy < 1 or num_actions < 1):
            raise ValueError("Invalid feature dimensions, dropout, or counting dimensions")
        if not math.isfinite(warp_probability) or not 0 <= warp_probability <= 1:
            raise ValueError("warp_probability must be finite and in [0,1]")
        self.pooling, self.input_view = pooling, input_view
        self.max_occupancy, self.num_actions = max_occupancy, num_actions
        projection = CSISpatialProjection if input_view == "amplitude" else CSIMultiviewProjection
        self.projection = projection(warp_probability=warp_probability, length=length,
                                     resolution=resolution)
        if backbone is None:
            backbone, feature_dim = _pretrained_spatial_backbone(initialize_pretrained)
        elif feature_dim is None or feature_dim < 1:
            raise ValueError("Injected test backbone requires a positive feature_dim")
        self.backbone = backbone
        self.feature_dim = int(feature_dim)
        self.token_projection = nn.Sequential(nn.Linear(self.feature_dim, feature_width),
                                              nn.LayerNorm(feature_width))
        self.activity_embedding = nn.Embedding(num_actions, 32)
        if pooling == "query":
            self.action_queries = nn.Embedding(num_actions, feature_width)
            nn.init.normal_(self.action_queries.weight, std=0.02)
            self.action_attention = nn.MultiheadAttention(feature_width, attention_heads,
                                                         dropout=dropout, batch_first=True)
            self.attention_norm = nn.LayerNorm(feature_width)
        self.activity_mlp = nn.Sequential(nn.Linear(feature_width + 32, 128), nn.GELU(),
                                          nn.Dropout(dropout), nn.Linear(128, 64))
        self.count_head = nn.Linear(64, max_occupancy + 1)
        self.occupancy_head = nn.Linear(feature_width, max_occupancy + 1)
        self.contrast_projection = nn.Sequential(nn.Linear(64, 64), nn.GELU(), nn.Linear(64, 32))

    def _encode(self, x: Tensor, valid: Tensor):
        spatial = self.backbone(self.projection(x, valid))
        if (spatial.ndim != 4 or spatial.shape[1] != self.feature_dim
                or spatial.shape[-1] < 1 or spatial.shape[-2] < 1):
            raise ValueError("V2 backbone must return a nonempty [B,feature_dim,H,W] spatial grid")
        tokens = self.token_projection(spatial.flatten(2).transpose(1, 2))
        h = tokens.mean(dim=1)
        if self.pooling == "query":
            query = self.action_queries.weight[None].expand(x.shape[0], -1, -1)
            evidence, _ = self.action_attention(query, tokens, tokens, need_weights=False)
            evidence = self.attention_norm(query + evidence)
        else:
            evidence = h[:, None].expand(-1, self.num_actions, -1)
        action = self.activity_embedding.weight[None].expand(x.shape[0], -1, -1)
        z = self.activity_mlp(torch.cat((evidence, action), dim=-1))
        return h, z

    def _potentials(self, h: Tensor, z: Tensor):
        return {"a": self.count_head(z), "b": self.occupancy_head(h)}

    def forward(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        h, z = self._encode(x, valid)
        return {**self._potentials(h, z), "h": h, "z": z,
                "p": F.normalize(self.contrast_projection(z), dim=-1, eps=1e-8)}

    def predict_potentials(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        h, z = self._encode(x, valid)
        return self._potentials(h, z)


def build_v2_model(cfg: dict, initialize_pretrained=True) -> V2CountingModel:
    settings = cfg.get("v2", {})
    if settings.get("pretrained", True) is not True:
        raise ValueError("V2 requires official pretrained ConvNeXt weights; no random fallback")
    if cfg.get("model", {}).get("in_channels", 270) != 270:
        raise ValueError("V2 spatial projection requires 270 CSI channels")
    allowed = ("pooling", "input_view", "feature_width", "attention_heads", "dropout",
               "warp_probability", "resolution")
    kwargs = {name: settings[name] for name in allowed if name in settings}
    return V2CountingModel(initialize_pretrained=initialize_pretrained,
                           max_occupancy=cfg["model"].get("max_occupancy", 3),
                           num_actions=cfg["model"].get("num_actions", 9),
                           length=cfg.get("max_length", 3000), **kwargs)
