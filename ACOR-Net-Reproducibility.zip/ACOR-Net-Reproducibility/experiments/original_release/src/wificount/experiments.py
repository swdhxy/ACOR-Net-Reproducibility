"""Predeclared within-split searches, selection, and matched experiment plans."""
from __future__ import annotations

import copy
import json
from pathlib import Path

from .config import CORE_METHODS, deep_update, fingerprint, write_json, validate_config


def _job(cfg, name, root, **extra):
    cfg=copy.deepcopy(cfg)
    cfg["output"]=str(Path(root).resolve()/name)
    return {"id":name,"config":cfg,**extra}


def _split(cfg, seed):
    cfg=copy.deepcopy(cfg); cfg["split_seed"]=seed
    current=Path(cfg["manifest"])
    cfg["manifest"]=str(current.with_name(f"sample_manifest_seed{seed}.csv"))
    if not Path(cfg["manifest"]).exists(): raise FileNotFoundError(cfg["manifest"])
    return cfg


def make_plan(cfg, stage, root, methods=CORE_METHODS, split_seeds=(2026,2027,2028),
              model_seeds=(11,22,33), selection=None):
    jobs=[]
    if stage=="search":
        for split in split_seeds:
            for method in methods:
                for lr in (0.0003,0.001):
                    for gamma in ((0,.025,.1,.4) if method in ("b5","ours") else (0,)):
                        c=_split(cfg,split); c.update(method=method,model_seed=11)
                        c["training"].update(learning_rate=lr,gamma=gamma)
                        jobs.append(_job(c,f"search/{method}_s{split}_lr{lr:g}_g{gamma:g}",root))
    elif stage in ("core","ablations"):
        if selection is None: raise ValueError("This stage requires selection.json from completed validation-only searches")
        def selected(method,split):
            key=f"{method}:{split}"
            if key not in selection["selected"]: raise ValueError(f"No validation-selected configuration: {key}")
            return copy.deepcopy(selection["selected"][key])
        if stage=="core":
            for split in split_seeds:
                for method in methods:
                    parent=selected(method,split)
                    for seed in model_seeds:
                        c=copy.deepcopy(parent["config"]); c["model_seed"]=seed
                        job=_job(c,f"core/{method}_s{split}_m{seed}",root)
                        if seed==11:
                            job["reuse_completed_run"]=parent["config"]["output"]
                            job["config"]["output"]=parent["config"]["output"]
                        jobs.append(job)
        else:
            if tuple(split_seeds)!=(2026,):
                raise ValueError("Frozen ablations use --splits 2026; expanding needs a new pre-test plan")
            base=selected("ours",2026)["config"]
            for seed in model_seeds:
                for label,changes in (("uniform_erm",{"method":"b4","training":{"sampler":"uniform","gamma":0}}),
                                      ("eta0",{"training":{"eta":0}}),("lambda0",{"training":{"lambda_occ":0}}),
                                      ("no_n",{"training":{"contrast_variant":"no_n"}})):
                    # The ordinary-sampler ERM inherits B4's own selected hyperparameters.
                    parent=selected("b4",2026)["config"] if label=="uniform_erm" else base
                    c=deep_update(parent,changes);c["model_seed"]=seed
                    jobs.append(_job(c,f"ablations/{label}_s2026_m{seed}",root))
                for method in CORE_METHODS:
                    c=selected(method,2026)["config"];c.update(no_aux=True,model_seed=seed)
                    jobs.append(_job(c,f"ablations/no_aux_{method}_s2026_m{seed}",root))
                for variant in ("erm","within","cross","any"):
                    c=deep_update(base,{"model_seed":seed,"training":{"sampler":"controlled","diagnostic":variant,
                        "learning_rate":.001,"gamma":.1,"temperature":.1,"epochs":80}})
                    jobs.append(_job(c,f"diagnostics/{variant}_s2026_m{seed}",root))
    else: raise ValueError("Unknown plan stage")
    for job in jobs:
        validate_config(job["config"])
    return {"schema":1,"stage":stage,"test_used_for_selection":False,
            "warning":"No test execution in this plan. Freeze all methods before opening test results.",
            "jobs":jobs,"job_count":len(jobs),"plan_fingerprint":fingerprint(jobs)}


def select_search(plan):
    from .engine import provenance, verify_run_provenance
    if plan.get("stage")!="search": raise ValueError("Selection requires a search plan")
    if fingerprint(plan["jobs"])!=plan["plan_fingerprint"]:
        raise ValueError("Search plan changed since freezing")
    winners={}; candidates={}
    for job in plan["jobs"]:
        cfg=job["config"];out=Path(cfg["output"])
        metric_path=out/"validation_best.json"
        if not metric_path.exists(): raise FileNotFoundError(f"Search incomplete: {metric_path}")
        actual=json.loads((out/"config.json").read_text(encoding="utf-8"))
        if actual!=cfg: raise ValueError(f"Search config differs from planned job: {job['id']}")
        saved_provenance=json.loads((out/"provenance.json").read_text(encoding="utf-8"))
        verify_run_provenance(saved_provenance, provenance(cfg), f"Search {job['id']}")
        m=json.loads(metric_path.read_text(encoding="utf-8"))
        summary=json.loads((out/"training_summary.json").read_text(encoding="utf-8"))
        k=(m["macro_exact_match_by_complete_composition"],-m["positive_count_mae"],
           -summary["best_epoch"],-cfg["training"]["gamma"],-cfg["training"]["learning_rate"])
        key=f"{cfg['method']}:{cfg['split_seed']}"
        candidates.setdefault(key,[]).append({"job":job["id"],"ranking":list(k)})
        if key not in winners or k>tuple(winners[key]["ranking"]):
            winners[key]={"config":cfg,"ranking":list(k),"validation":m,"job":job["id"]}
    return {"schema":1,"selected":winners,"candidates":candidates,"search_plan_fingerprint":plan["plan_fingerprint"],
            "selection_scope":"each split's own val_unseen; no cross-split configuration transfer"}


def run_plan(plan, execute=False, max_jobs=None):
    from .engine import train, provenance, verify_run_provenance
    if fingerprint(plan["jobs"])!=plan["plan_fingerprint"]:
        raise ValueError("Plan changed since freezing; regenerate intentionally before testing")
    selected=plan["jobs"][:max_jobs] if max_jobs is not None else plan["jobs"]
    result=[]
    for job in selected:
        cfg=job["config"];out=Path(cfg["output"])
        summary=out/"training_summary.json"
        if summary.exists():
            actual=json.loads((out/"config.json").read_text(encoding="utf-8"))
            if actual!=cfg: raise ValueError(f"Completed run has different configuration: {out}")
            saved_provenance=json.loads((out/"provenance.json").read_text(encoding="utf-8"))
            verify_run_provenance(saved_provenance, provenance(cfg), f"Completed run {job['id']}")
            result.append({"job":job["id"],"status":"reused_completed"});continue
        if job.get("reuse_completed_run"): raise FileNotFoundError(f"Selected search run missing: {out}")
        if not execute:
            result.append({"job":job["id"],"status":"planned","output":str(out)});continue
        last=out/"last.pt"
        train(cfg,resume=str(last) if last.exists() else None)
        result.append({"job":job["id"],"status":"trained"})
    return result

