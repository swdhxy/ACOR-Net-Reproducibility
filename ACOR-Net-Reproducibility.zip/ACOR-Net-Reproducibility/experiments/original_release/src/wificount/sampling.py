"""Deterministic, metadata-only training batch schedules.

The schedule is independent of the method/loss. Reusing ``seed`` and ``epoch``
therefore gives matched ERM, SupCon and ours exactly the same physical batches.
No waveform or test/validation annotation is required by this module.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from hashlib import blake2b
from math import ceil
import random
from typing import Any, Mapping, Sequence


@dataclass
class BatchPlan:
    indices: list[int]
    # Indices here are local to this physical batch. The first two members
    # share composition A, and the final two share composition B.
    quadruplets: list[dict[str, Any]] = field(default_factory=list)


def stable_seed(seed: int, *parts: Any) -> int:
    """Avoid Python's process-dependent hash when deriving random streams."""
    payload = repr((int(seed), *parts)).encode("utf-8")
    return int.from_bytes(blake2b(payload, digest_size=8).digest(), "little")


def validate_training_records(records: Sequence[Mapping[str, Any]]) -> None:
    """Reject test leakage and ambiguous/invalid record-level annotations."""
    seen = set()
    for record in records:
        if record.get("partition") != "train":
            raise ValueError("Sampling/contrast accepts only partition='train'.")
        record_id = record.get("record_id")
        if not isinstance(record_id, str) or not record_id or record_id in seen:
            raise ValueError("Each training record needs a unique nonempty record_id.")
        seen.add(record_id)
        counts = record.get("counts")
        if counts is None or len(counts) != 9:
            raise ValueError("counts must contain the nine canonical action counts.")
        if any(isinstance(v, bool) or int(v) != v or int(v) < 0 for v in counts):
            raise ValueError("Counts must be nonnegative integers.")
        if (int(record.get("n", -1)) != record.get("n")
            or int(record["n"]) != sum(counts)):
            raise ValueError("n must equal the sum of counts.")
        for key in ("environment", "wifi_band", "combo_id"):
            if key not in record or record[key] is None or str(record[key]) == "":
                raise ValueError(f"Missing training metadata: {key}")
    # A composition ID must be a bijection with complete count vectors. This
    # prevents accidental identity/position-dependent composition definitions.
    combo_counts: dict[str, tuple[int, ...]] = {}
    count_combos: dict[tuple[int, ...], str] = {}
    for record in records:
        combo = str(record["combo_id"])
        counts = tuple(int(v) for v in record["counts"])
        if combo in combo_counts and combo_counts[combo] != counts:
            raise ValueError("One combo_id maps to multiple count vectors.")
        if counts in count_combos and count_combos[counts] != combo:
            raise ValueError("One count vector maps to multiple combo_id values.")
        combo_counts[combo] = counts
        count_combos[counts] = combo


def make_epoch_plans(
    records: Sequence[Mapping[str, Any]],
    batch_size: int = 64,
    groups_per_batch: int = 4,
    seed: int = 11,
    epoch: int = 0,
    kind: str = "matched",
) -> list[BatchPlan]:
    """Build ``ceil(N/batch_size)`` finite, reproducible batch plans.

    ``matched`` selects two different composition records per eligible
    (occupancy, target action, positive count) group. ``controlled`` selects
    two distinct records from each of two compositions. Both add up to one
    same-environment/band negative per other target count, capacity permitting.
    Unfilled slots are sampled uniformly over available occupancy, composition,
    and then record, removing selected records from availability. Across steps
    replacement is intentional. ``uniform`` uses only this hierarchical filler.
    ``support_balanced`` instead draws uniformly at each available level of
    occupancy -> number of positive action categories -> composition ->
    (environment, band) -> record. It is a separate sampling ablation, not an
    assertion that the existing composition-balanced filler is unbalanced.

    A tiny physical batch can legitimately have no contrastive anchors. Never
    duplicate a record to manufacture a positive, or increase contrast set size
    through gradient accumulation.
    """
    if kind not in {"matched", "uniform", "controlled", "support_balanced"}:
        raise ValueError(f"Unknown sampler kind: {kind}")
    if batch_size <= 0 or groups_per_batch < 0 or epoch < 0:
        raise ValueError("batch_size must be positive; groups/epoch nonnegative.")
    validate_training_records(records)
    if not records:
        return []

    rng = random.Random(stable_seed(seed, "batch_schedule", epoch))
    target_size = min(batch_size, len(records))
    if kind == "support_balanced":
        return _support_balanced_plans(records, batch_size, target_size, rng)
    hierarchy: dict[int, dict[str, list[int]]] = defaultdict(lambda: defaultdict(list))
    cells: dict[tuple, dict[tuple, dict[str, list[int]]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(list))
    )
    negatives: dict[tuple, dict[int, list[int]]] = defaultdict(lambda: defaultdict(list))
    for i, record in enumerate(records):
        n = int(record["n"])
        combo = str(record["combo_id"])
        cell = (str(record["environment"]), str(record["wifi_band"]))
        hierarchy[n][combo].append(i)
        for k, count in enumerate(record["counts"]):
            r = int(count)
            negatives[(n, k, *cell)][r].append(i)
            if r > 0:
                cells[(n, k, r)][cell][combo].append(i)

    per_combo = 2 if kind == "controlled" else 1
    eligible: dict[tuple, list[tuple]] = {}
    for group, contexts in cells.items():
        n, k, r = group
        available = []
        for cell, combos in contexts.items():
            if sum(len(ids) >= per_combo for ids in combos.values()) < 2:
                continue
            if not any(q != r and ids for q, ids in negatives[(n, k, *cell)].items()):
                continue
            available.append(cell)
        if available:
            eligible[group] = sorted(available)
    groups = sorted(eligible)
    rng.shuffle(groups)
    cursor = 0
    plans = []
    for _ in range(ceil(len(records) / batch_size)):
        selected: list[int] = []
        selected_set: set[int] = set()
        quads: list[dict[str, Any]] = []

        def add(index: int) -> None:
            if index not in selected_set and len(selected) < target_size:
                selected.append(index)
                selected_set.add(index)

        if kind != "uniform" and groups:
            for _group in range(min(groups_per_batch, len(groups))):
                group = groups[cursor % len(groups)]
                cursor += 1
                n, k, r = group
                cell = rng.choice(eligible[group])
                choices = cells[group][cell]
                combos = sorted(c for c, ids in choices.items() if len(ids) >= per_combo)
                chosen_combos = rng.sample(combos, 2)
                members = [j for c in chosen_combos for j in rng.sample(choices[c], per_combo)]
                if len(selected_set.union(members)) > target_size:
                    continue
                for j in members:
                    add(j)
                if kind == "controlled":
                    quads.append({"indices": members, "n": n, "k": k, "r": r})
                other_counts = sorted(q for q in negatives[(n, k, *cell)] if q != r)
                rng.shuffle(other_counts)
                for q in other_counts:
                    options = negatives[(n, k, *cell)][q]
                    # Already-present negatives also meet the selected group
                    # requirement, while saving physical batch capacity.
                    present = [j for j in options if j in selected_set]
                    add(rng.choice(present or options))

        # Removing occupied records before every draw is finite even when only
        # one occupancy/composition remains. Rejection sampling can hang here.
        remaining = {
            n: {c: [j for j in ids if j not in selected_set] for c, ids in combos.items()}
            for n, combos in hierarchy.items()
        }
        remaining = {n: {c: ids for c, ids in combos.items() if ids} for n, combos in remaining.items()}
        remaining = {n: combos for n, combos in remaining.items() if combos}
        while len(selected) < target_size and remaining:
            n = rng.choice(sorted(remaining))
            combo = rng.choice(sorted(remaining[n]))
            options = remaining[n][combo]
            j = rng.choice(options)
            add(j)
            options.remove(j)
            if not options:
                del remaining[n][combo]
            if not remaining[n]:
                del remaining[n]

        # Shuffle batch order without changing designated quadruplet membership.
        rng.shuffle(selected)
        local = {index: pos for pos, index in enumerate(selected)}
        for quad in quads:
            quad["indices"] = [local[j] for j in quad["indices"]]
        plans.append(BatchPlan(indices=selected, quadruplets=quads))
    return plans


def _support_balanced_plans(
    records: Sequence[Mapping[str, Any]],
    batch_size: int,
    target_size: int,
    rng: random.Random,
) -> list[BatchPlan]:
    """Draw only existing train records, with no within-batch replacement.

    q counts distinct positive categories: [3, 0, ...] has q=1, not q=3.
    An exhausted leaf and its empty ancestors are removed before the next draw.
    Thus sparse cells cannot hang or force duplicate examples. Balancing is in
    expectation over *available* children; it is not a fixed quota when a sparse
    child has been exhausted. Each new batch resets availability, matching the
    existing sampler's epoch step budget and between-batch replacement policy.
    """
    tree: dict = {}
    for index, record in enumerate(records):
        n = int(record["n"])
        q = sum(int(count) > 0 for count in record["counts"])
        combo = str(record["combo_id"])
        cell = (str(record["environment"]), str(record["wifi_band"]))
        tree.setdefault(n, {}).setdefault(q, {}).setdefault(combo, {}).setdefault(cell, []).append(index)

    plans = []
    for _ in range(ceil(len(records) / batch_size)):
        remaining = {
            n: {q: {combo: {cell: list(ids) for cell, ids in cells.items()}
                    for combo, cells in combos.items()}
                for q, combos in supports.items()}
            for n, supports in tree.items()
        }
        selected = []
        while len(selected) < target_size and remaining:
            n = rng.choice(sorted(remaining))
            q = rng.choice(sorted(remaining[n]))
            combo = rng.choice(sorted(remaining[n][q]))
            cell = rng.choice(sorted(remaining[n][q][combo]))
            ids = remaining[n][q][combo][cell]
            index = rng.choice(ids)
            selected.append(index)
            ids.remove(index)
            if not ids:
                del remaining[n][q][combo][cell]
            if not remaining[n][q][combo]:
                del remaining[n][q][combo]
            if not remaining[n][q]:
                del remaining[n][q]
            if not remaining[n]:
                del remaining[n]
        rng.shuffle(selected)
        plans.append(BatchPlan(indices=selected))
    return plans
