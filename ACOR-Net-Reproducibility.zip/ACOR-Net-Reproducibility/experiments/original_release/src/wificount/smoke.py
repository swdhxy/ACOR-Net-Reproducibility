"""Explicitly synthetic software tests, never scientific evaluation data."""
from __future__ import annotations

import csv
import json
import time
from pathlib import Path
import numpy as np
import torch

from .config import ROOT, CORE_METHODS, load_config, deep_update, write_json
from .data import ACTIONS, canonical_combo


def create_fixture(root):
    root=Path(root);amp=root/"amplitude"
    amp.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(915)
    rows=[]
    def add(counts,partition,repeats):
        c=list(counts)+[0]*(9-len(counts))
        for _ in range(repeats):
            rid=f"act_1_{len(rows)+1}"
            length=int(rng.integers(48,81))
            x=rng.uniform(.2,1.2,(length,3,3,30)).astype(np.float32)
            for k,n in enumerate(c):
                x[:,k//3,k%3,:] += n*.1 if k<9 else 0
            np.save(amp/f"{rid}.npy",x)
            combo_partition="auxiliary" if sum(c)<=1 else "train_combo" if partition in ("train","test_seen") else partition
            row=dict(record_id=rid,partition=partition,combo_partition=combo_partition,
                     combo_id=canonical_combo(c),number_of_users=sum(c),environment="synthetic_room",wifi_band="5")
            row.update({f"count_{action}":n for action,n in zip(ACTIONS,c)})
            rows.append(row)
    for c in ([2,0,0,0],[0,2,0,0],[0,0,2,0],[0,0,0,2],[1,1,0,0],[1,0,1,0],[1,0,0,1],[0,1,1,0]):
        add(c,"train",4)
    add([0,1,0,1],"val_unseen",4);add([0,0,1,1],"test_unseen",4)
    add([1,1,0,0],"test_seen",2)
    add([0,0,0,0],"train",2);add([1,0,0,0],"train",2)
    add([0,0,0,0],"test_aux",2)
    manifest=root/"manifest.csv"
    with manifest.open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (root/"SYNTHETIC_ONLY.txt").write_text("Random positive arrays for software tests. NOT WiMANS. NOT research results.\n",encoding="utf-8")
    return manifest,amp


def run_smoke(output,all_methods=False):
    from .engine import train,evaluate
    from .inference import predict_file
    root=Path(output).resolve()
    if root.exists() and any(root.iterdir()): raise FileExistsError(f"Smoke output already exists: {root}")
    manifest,amp=create_fixture(root/"fixture")
    cfg=load_config(ROOT/"configs/default.yaml")
    cfg=deep_update(cfg,{"manifest":str(manifest),"data_root":str(amp),"max_length":80,"cache_dir":str(root/"cache"),
        "device":"cpu","threads":2,"model":{"channels":8,"dilations":[1],"dropout":0},
        "training":{"epochs":1,"batch_size":8,"target_groups":1,"contrast_warmup":0,"contrast_ramp":1,"log_every":1000},
        "evaluation":{"batch_size":8}})
    results={}
    for method in (CORE_METHODS if all_methods else ("b4","b5","ours")):
        c=deep_update(cfg,{"method":method,"output":str(root/method)})
        result=train(c)
        metric=evaluate(root/method/"best.pt",output=root/method/"synthetic_test",device="cpu")
        prediction=predict_file(root/method/"best.pt",amp/"act_1_1.npy",device="cpu")
        results[method]={"train_completed":result["best_epoch"] is not None,"evaluation_records":metric["denominators_and_numerators"]["samples"],
                         "inference_dimensions":len(prediction["counts"])}
    report={"software_smoke_passed":all(x["train_completed"] and x["inference_dimensions"]==9 for x in results.values()),
            "synthetic_data_only":True,"research_performance_verified":False,"methods":results}
    write_json(root/"smoke_report.json",report)
    return report


def profile_model(cfg,steps=10,batch_size=2,device="cpu"):
    from .engine import build_model,device_for,seed_all
    from .objectives import enumerate_counts,supervised_loss
    if steps < 1 or batch_size < 1:
        raise ValueError("steps and batch_size must be positive")
    seed_all(cfg["model_seed"],cfg["deterministic"],cfg["threads"])
    dev=device_for(device);model=build_model(cfg).to(dev);model.train()
    if cfg["method"] not in CORE_METHODS: raise ValueError("Use a core method for this minimal profile")
    x=torch.rand(batch_size,270,cfg["max_length"],device=dev)
    valid=torch.ones(batch_size,cfg["max_length"],dtype=torch.bool,device=dev)
    target=torch.zeros(batch_size,9,dtype=torch.long,device=dev);target[:,0]=2
    legal=enumerate_counts(9,cfg["model"]["max_occupancy"]).to(dev)
    opt=torch.optim.AdamW(model.parameters(),lr=.001)
    if dev.type=="cuda":torch.cuda.reset_peak_memory_stats(dev)
    times=[]
    for step in range(steps+2):
        if dev.type=="cuda":torch.cuda.synchronize(dev)
        start=time.perf_counter();opt.zero_grad(set_to_none=True)
        out=model(x,valid);loss,_=supervised_loss(out,target,cfg["method"],legal)
        loss.backward();opt.step()
        if dev.type=="cuda":torch.cuda.synchronize(dev)
        if step>=2:times.append(time.perf_counter()-start)
    return {"device":str(dev),"gpu":torch.cuda.get_device_name(dev) if dev.type=="cuda" else None,
            "batch_size":batch_size,"measured_steps":steps,"mean_update_seconds":sum(times)/len(times),
            "peak_cuda_bytes":torch.cuda.max_memory_allocated(dev) if dev.type=="cuda" else None,
            "parameters":sum(p.numel() for p in model.parameters()),"input_length":cfg["max_length"],
            "scope":"synthetic supervised forward/backward/optimizer; excludes disk IO, validation, pair selection and contrast loss"}
