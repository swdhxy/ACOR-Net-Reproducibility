"""Frozen V4 recipes and descriptive multi-metric/contrast-exposure audit."""
from collections import Counter
import json
from pathlib import Path
import math

from .config import write_json
from .development import verify_development_plan


def variants():
    entries = []
    for name, sampler in [("activity_uniform", "uniform"),
                          ("activity_balanced", "support_balanced"),
                          ("activity_matched", "matched")]:
        entries.append({"name": name, "overrides": {"method": "activity_counting",
            "training": {"sampler": sampler}, "baseline": {"pretrained": True,
                "warp_probability": .5, "backbone_lr_multiplier": .1, "head_lr_multiplier": .1}}})
    entries.append({"name": "v2_global_factor", "overrides": {"method": "ours_v2",
        "training": {"sampler": "uniform"}, "v2": {"pooling": "global",
            "input_view": "amplitude", "action_ce_weight": .5}}})
    entries.append({"name": "v4_regression_uniform", "overrides": {
        "v4": {"occupancy_weight": 0., "joint_weight": 0., "lambda_occ": 0.},
        "training": {"sampler": "uniform"}}})
    entries.append({"name": "v4_energy_uniform", "overrides": {"training": {"sampler": "uniform"}}})
    for name, variant, gamma in [("v4_matched_erm", "ours", 0.),
                                 ("v4_supcon", "supcon", .05),
                                 ("v4_ours", "ours", .05)]:
        entries.append({"name": name, "overrides": {"training": {
            "sampler": "matched", "contrast_variant": variant, "gamma": gamma}}})
    for variant in ("erm", "within", "cross", "any"):
        entries.append({"name": "v4_controlled_" + variant, "overrides": {"training": {
            "sampler": "controlled", "diagnostic": variant,
            "gamma": 0. if variant == "erm" else .05}}})
    return entries


def contrast_exposure(plan):
    """Require complete logs and distinguish planned pairs from active training."""
    from .engine import gamma_at
    reports = []
    for job in plan["jobs"]:
        cfg = job["config"]
        if cfg["method"] != "ours_v4":
            continue
        root = Path(cfg["output"])
        summary = json.loads((root / "training_summary.json").read_text(encoding="utf-8"))
        completed, best = summary["completed_epochs"], summary["best_epoch"]
        files = sorted((root / "pair_logs").glob("epoch_*.json"))
        if {p.name for p in files} != {f"epoch_{e:03d}.json" for e in range(1, completed+1)}:
            raise ValueError("Incomplete contrast exposure logs")
        history = [json.loads(s) for s in (root / "history.jsonl").read_text(encoding="utf-8").splitlines() if s.strip()]
        if [h["epoch"] for h in history] != list(range(1, completed+1)):
            raise ValueError("Incomplete contrast history")
        totals, at_best, by_count = Counter(), Counter(), Counter()
        for epoch, (path, hist) in enumerate(zip(files, history), 1):
            logs = json.loads(path.read_text(encoding="utf-8"))
            if len(logs) != hist["updates"]:
                raise ValueError("Contrast step coverage mismatch")
            if [s["step"] for s in logs] != list(range(hist["updates"])):
                raise ValueError("Contrast step order/coverage mismatch")
            expected_weight = 0. if cfg["training"].get("diagnostic") == "erm" else gamma_at(epoch-1, cfg["training"])
            for step in logs:
                weight = step["contrast_effective_weight"]
                active = step["active_anchor_exposures"]
                if (not math.isfinite(weight) or weight != expected_weight
                        or active != (step["retained_anchors"] if weight > 0 else 0)):
                    raise ValueError("Invalid actual contrast exposure")
                d = {"planned_anchor_exposures": step["retained_anchors"],
                     "active_anchor_exposures": active, "active_updates": int(active > 0)}
                for key in ("selected_cross_positive_pairs", "selected_within_positive_pairs"):
                    d["active_" + key] = step[key] if weight > 0 else 0
                totals.update(d)
                if epoch <= best:
                    at_best.update(d)
                if weight > 0:
                    for group, count in step["group_anchor_counts"].items():
                        by_count[group.split(",")[-1]] += count
        expected = cfg["training"]["gamma"] > 0 and cfg["training"].get("diagnostic") != "erm"
        reports.append({"job": job["id"], "variant": job["variant"], "seed": cfg["model_seed"],
            "expected_contrast": expected, "completed_epochs": completed, "best_epoch": best,
            "whole_training": dict(totals), "through_best_checkpoint": dict(at_best),
            "active_anchor_exposures_by_positive_count": dict(by_count),
            "best_has_contrast_exposure": bool(at_best["active_anchor_exposures"]),
            "missing_expected_exposure": expected and totals["active_anchor_exposures"] == 0})
    return reports


METRICS = {"joint_score": 1,
    "val_seen/macro_exact_match_by_complete_composition": 1,
    "val_unseen/macro_exact_match_by_complete_composition": 1,
    "val_unseen/sample_exact_match": 1, "val_unseen/multiset_micro_f1": 1,
    "val_unseen/positive_count_mae": -1, "val_unseen/occupancy_accuracy": 1}


def metric_comparison(summary):
    """Report winners/Pareto jointly; never splice per-metric winners into a model."""
    groups = {g["variant"]: g["metrics"] for g in summary["by_variant"]}
    value = lambda name, key: groups[name][key]["mean"] * METRICS[key]
    wins = {name: [] for name in groups}
    for key in METRICS:
        best = max(value(name, key) for name in groups)
        for name in groups:
            if math.isclose(value(name, key), best, abs_tol=1e-12, rel_tol=0):
                wins[name].append(key)
    dominated = {}
    for name in groups:
        dominated[name] = [other for other in groups if other != name
            and all(value(other, k) >= value(name, k) for k in METRICS)
            and any(value(other, k) > value(name, k) for k in METRICS)]
    return {"metric_directions": METRICS, "best_metrics_including_ties": wins,
        "pareto_frontier": [name for name in groups if not dominated[name]],
        "dominated_by": dominated, "highest_frozen_joint_rank": summary["ranking"][0],
        "primary_innovation_candidate": "v4_ours" if "v4_ours" in groups else None,
        "rule": "Checkpoint and recipe ranking remain mean paired-seed H, then mean positive MAE. Metric win counts are descriptive and correlated, not a new selection objective.",
        "status": "Development evidence only; no final performance or novelty claim is automatic."}


def summarize_v4(plan_path, output, require_exposure=False):
    plan = verify_development_plan(plan_path)
    exposure = contrast_exposure(plan)
    summary = json.loads((Path(output) / "development_summary.json").read_text(encoding="utf-8"))
    result = {"selection_changed": False, "test_evaluated": False,
              "contrast_exposure": exposure, "comparison": metric_comparison(summary)}
    write_json(Path(output) / "v4_mechanism_and_comparison.json", result)
    if require_exposure and any(r["missing_expected_exposure"] for r in exposure):
        raise ValueError("Contrast-enabled pilot has zero active anchor exposures; full launch refused")
    return str(Path(output) / "v4_mechanism_and_comparison.json")
