"""Explicit per-action supervision added to the unchanged legal-space objective."""

from __future__ import annotations

import math

import torch
from torch import Tensor
from torch.nn import functional as F

from .objectives import supervised_loss


def balanced_action_count_ce(logits: Tensor, counts: Tensor) -> Tensor:
    """Average action CE, giving present and absent strata equal weight per action.

    Multiplicity remains a categorical target 0..M, including r=2/3. Missing
    strata contribute neither loss nor an artificial zero: the available strata
    for an action are averaged. Weights depend solely on this training batch's
    targets, never on validation/test frequency or future predicted labels.
    """
    if logits.ndim != 3 or counts.shape != logits.shape[:2] or counts.numel() == 0:
        raise ValueError("Expected nonempty logits [B,K,M+1] and counts [B,K]")
    if (not bool(torch.isfinite(counts).all()) or bool((counts < 0).any())
            or bool((counts != counts.long()).any()) or int(counts.max()) >= logits.shape[-1]):
        raise ValueError("Targets must be finite integer counts within the head range")
    counts = counts.to(device=logits.device, dtype=torch.long)
    ce = F.cross_entropy(logits.float().transpose(1, 2), counts, reduction="none")
    present = counts > 0
    sums = torch.stack(((ce * present).sum(0), (ce * ~present).sum(0)))
    sizes = torch.stack((present.sum(0), (~present).sum(0)))
    available = sizes > 0
    per_stratum = sums / sizes.clamp_min(1)
    per_action = per_stratum.sum(0) / available.sum(0).clamp_min(1)
    return per_action.mean()


def v2_supervised_loss(outputs: dict[str, Tensor], counts: Tensor, cfg: dict,
                       candidates: Tensor | None = None):
    settings, training = cfg.get("v2", {}), cfg["training"]
    weight = float(settings.get("action_ce_weight", 0.0))
    if not math.isfinite(weight) or weight < 0:
        raise ValueError("action_ce_weight must be finite and nonnegative")
    base, logs = supervised_loss(outputs, counts, method="ours", candidates=candidates,
                                 eta=training.get("eta", 0.25),
                                 lambda_occ=training.get("lambda_occ", 1.0))
    action = balanced_action_count_ce(outputs["a"], counts) if weight else base.new_zeros(())
    loss = base + weight * action
    return loss, {**logs, "supervised": float(loss.detach()),
                  "action_positive_zero_ce": float(action.detach()), "action_ce_weight": weight}
