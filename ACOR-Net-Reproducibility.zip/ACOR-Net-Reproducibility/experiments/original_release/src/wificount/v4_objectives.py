"""Regression and soft occupancy evidence over the complete legal count space."""

from __future__ import annotations

import math

import torch
from torch import Tensor
from torch.nn import functional as F

from .objectives import enumerate_counts
from .v4_model import validate_v4_settings


def _candidates(outputs: dict[str, Tensor], candidates: Tensor | None) -> Tensor:
    mu, b = outputs["regression"], outputs["b"]
    if (mu.ndim != 2 or b.ndim != 2 or len(mu) == 0 or mu.shape[1] < 1
            or len(mu) != len(b) or b.shape[1] < 2 or mu.device != b.device):
        raise ValueError("V4 requires regression [B,K] and b [B,M+1] on the same device")
    if not bool(torch.isfinite(mu).all()) or bool((mu < 0).any()) or not bool(torch.isfinite(b).all()):
        raise ValueError("V4 requires finite nonnegative regression and finite occupancy logits")
    k, m = mu.shape[1], b.shape[1] - 1
    if candidates is None:
        return enumerate_counts(k, m).to(mu.device)
    if (candidates.ndim != 2 or candidates.shape[1] != k
            or len(candidates) != math.comb(k + m, m)
            or not bool(torch.isfinite(candidates).all()) or bool((candidates < 0).any())
            or bool((candidates != candidates.long()).any())
            or bool((candidates.sum(-1) > m).any())
            or len(torch.unique(candidates, dim=0)) != len(candidates)):
        raise ValueError("Candidates must contain every legal integer count vector exactly once")
    return candidates.to(device=mu.device, dtype=torch.long)


def _settings(cfg: dict) -> dict:
    settings = cfg.get("v4", {})
    validate_v4_settings(settings)
    return settings


def _centered_scores(outputs: dict[str, Tensor], settings: dict, cand: Tensor) -> Tensor:
    """Omit -||mu||²/T, common to every candidate, for stable CE/argmax."""
    mu, c = outputs["regression"].float(), cand.float()
    score = (2 * mu @ c.T - c.square().sum(-1)) / settings.get("temperature", 1.)
    weight = settings.get("lambda_occ", .25)
    if weight:
        score = score + weight * F.log_softmax(outputs["b"].float(), -1)[:, cand.sum(-1)]
    return score


def v4_joint_scores(outputs: dict[str, Tensor], cfg: dict,
                    candidates: Tensor | None = None) -> Tensor:
    """E(c) = -||mu-c||²/T + lambda_occ log P(sum(c)|x), in float32.

    Decoding and CE use its algebraically equivalent centered form to avoid
    cancellation from a large common squared regression term.
    """
    settings = _settings(cfg)
    cand = _candidates(outputs, candidates)
    score = -(outputs["regression"].float()[:, None] - cand.float()[None]).square().sum(-1)
    score = score / settings.get("temperature", 1.)
    weight = settings.get("lambda_occ", .25)
    if weight:
        score = score + weight * F.log_softmax(outputs["b"].float(), -1)[:, cand.sum(-1)]
    return score


def decode_v4(outputs: dict[str, Tensor], cfg: dict,
              candidates: Tensor | None = None) -> Tensor:
    """Predict legal counts from model evidence, without true N, K or support."""
    settings = _settings(cfg)
    cand = _candidates(outputs, candidates)
    return cand[_centered_scores(outputs, settings, cand).argmax(-1)]


def v4_loss_components(outputs: dict[str, Tensor], counts: Tensor, cfg: dict,
                       candidates: Tensor | None = None) -> dict[str, Tensor]:
    """Unweighted differentiable terms, reusable for shared-feature diagnostics."""
    settings = _settings(cfg)
    cand = _candidates(outputs, candidates)
    mu = outputs["regression"].float()
    if (counts.shape != mu.shape or not bool(torch.isfinite(counts).all())
            or bool((counts < 0).any()) or bool((counts != counts.long()).any())
            or bool((counts.sum(-1) >= outputs["b"].shape[1]).any())):
        raise ValueError("Targets must be finite nonnegative integer counts with legal occupancy")
    y = counts.to(device=mu.device, dtype=torch.long)
    matches = (y[:, None] == cand[None]).all(-1)
    error = (mu - y.float()).square()
    mse = error.mean()
    occupancy = F.cross_entropy(outputs["b"].float(), y.sum(-1))
    joint = F.cross_entropy(_centered_scores(outputs, settings, cand), matches.long().argmax(-1))
    return {"mse": mse, "occupancy_ce": occupancy, "joint_nll": joint}


def v4_supervised_loss(outputs: dict[str, Tensor], counts: Tensor, cfg: dict,
                       candidates: Tensor | None = None) -> tuple[Tensor, dict[str, float]]:
    settings = _settings(cfg)
    parts = v4_loss_components(outputs, counts, cfg, candidates)
    mse, occupancy, joint = parts["mse"], parts["occupancy_ce"], parts["joint_nll"]
    mu = outputs["regression"].float()
    y = counts.to(device=mu.device)
    error, positive = (mu - y.float()).square(), y > 0
    positive_mse = error[positive].mean() if bool(positive.any()) else error.new_zeros(())
    zero_mse = error[~positive].mean() if bool((~positive).any()) else error.new_zeros(())
    total = (mse + settings.get("occupancy_weight", .25) * occupancy
             + settings.get("joint_weight", .1) * joint)
    return total, {"supervised": float(total.detach()), "mse": float(mse.detach()),
                   "positive_mse": float(positive_mse.detach()), "zero_mse": float(zero_mse.detach()),
                   "occupancy_ce": float(occupancy.detach()), "joint_nll": float(joint.detach()),
                   "positive_action_entries": int(positive.sum()),
                   "zero_action_entries": int((~positive).sum())}
