"""Runnable task-adapted comparators; see docs/external_baselines.md.

GroupDRO and MLDG reuse the structured TCN. The query-slot Transformer and
CNN regressor are explicitly project baselines, not official AMAR/MU-SHOT-Fi
or ActivityCounting reproductions. All adaptation uses training records only.
"""

from __future__ import annotations

from collections import defaultdict
import csv
from itertools import permutations
import math
from pathlib import Path
import random
from typing import Any

import torch
from torch import Tensor, nn
from torch.func import functional_call
from torch.nn import functional as F

from .models import ChannelLayerNorm, CountingModel
from .objectives import decode, enumerate_counts, joint_scores, supervised_loss
from .sampling import stable_seed, validate_training_records


class TemporalConvEncoder(nn.Module):
    """Independent three-stage CNN with propagated real-sample validity masks."""

    def __init__(self, in_channels: int, width: int, dropout: float):
        super().__init__()
        self.in_channels = in_channels
        self.specs = ((9, 5, 4), (5, 2, 2), (5, 2, 2))
        self.convs = nn.ModuleList([
            nn.Conv1d(in_channels if i == 0 else width, width, k, stride=s, padding=p)
            for i, (k, s, p) in enumerate(self.specs)
        ])
        self.norms = nn.ModuleList([ChannelLayerNorm(width) for _ in self.specs])
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: Tensor, valid: Tensor) -> tuple[Tensor, Tensor]:
        if valid.ndim == 3 and valid.shape[1] == 1:
            valid = valid[:, 0]
        if x.ndim != 3 or x.shape[1] != self.in_channels or valid.shape != (x.shape[0], x.shape[-1]):
            raise ValueError("Expected x=[B,in_channels,T] and matching valid=[B,T].")
        valid = valid.to(device=x.device, dtype=torch.bool)
        if not bool(valid.any(dim=1).all()):
            raise ValueError("Every record must have at least one valid sample.")
        x = x.masked_fill(~valid[:, None], 0)
        if not bool(torch.isfinite(x).all()):
            raise ValueError("Nonfinite input at a valid time position.")
        for conv, norm, (kernel, stride, padding) in zip(self.convs, self.norms, self.specs):
            x = conv(x)
            valid = F.max_pool1d(valid[:, None].float(), kernel, stride, padding)[:, 0].bool()
            if not bool(valid.any(dim=1).all()):
                raise ValueError("Empty validity mask after temporal downsampling.")
            x = x.masked_fill(~valid[:, None], 0)
            x = self.dropout(F.gelu(norm(x))).masked_fill(~valid[:, None], 0)
        return x, valid


class QuerySetTransformer(nn.Module):
    """Engineering comparator: M query slots predict nine actions plus empty."""

    def __init__(self, max_occupancy=3, in_channels=270, width=64, heads=4,
                 encoder_layers=1, decoder_layers=2, dropout=0.1):
        super().__init__()
        if width < 2 or width % heads or max_occupancy not in (3, 5):
            raise ValueError("width must divide heads; query occupancy is 3 or 5.")
        self.width = width
        self.max_occupancy = max_occupancy
        self.frontend = TemporalConvEncoder(in_channels, width, dropout)
        layer = nn.TransformerEncoderLayer(width, heads, 4 * width, dropout, activation="gelu", batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, encoder_layers, enable_nested_tensor=False)
        decoder = nn.TransformerDecoderLayer(width, heads, 4 * width, dropout, activation="gelu", batch_first=True)
        self.decoder = nn.TransformerDecoder(decoder, decoder_layers)
        self.queries = nn.Parameter(torch.randn(max_occupancy, width) * 0.02)
        self.classifier = nn.Linear(width, 10)

    def forward(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        memory, valid = self.frontend(x, valid)
        memory = memory.transpose(1, 2)
        position = torch.arange(memory.shape[1], device=x.device, dtype=torch.float32)[:, None]
        frequency = torch.exp(torch.arange(0, self.width, 2, device=x.device) * (-math.log(10000.0) / self.width))
        angle = position * frequency
        positional = memory.new_zeros((memory.shape[1], self.width))
        positional[:, 0::2] = angle.sin().to(memory.dtype)
        positional[:, 1::2] = angle.cos()[:, :positional[:, 1::2].shape[1]].to(memory.dtype)
        memory = (memory + positional[None]).masked_fill(~valid[:, :, None], 0)
        memory = self.encoder(memory, src_key_padding_mask=~valid)
        queries = self.queries[None].expand(x.shape[0], -1, -1)
        decoded = self.decoder(queries, memory, memory_key_padding_mask=~valid)
        return {"slots": self.classifier(decoded)}

    def predict_potentials(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        return self(x, valid)


class ActivityCNN(nn.Module):
    """Independent CNN nonnegative count regression; not a paper reproduction."""

    def __init__(self, in_channels=270, width=64, dropout=0.1):
        super().__init__()
        self.frontend = TemporalConvEncoder(in_channels, width, dropout)
        self.head = nn.Sequential(nn.Linear(width * 2, 128), nn.GELU(), nn.Dropout(dropout), nn.Linear(128, 9))
        nn.init.zeros_(self.head[-1].weight)
        nn.init.constant_(self.head[-1].bias, 0.5)

    def forward(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        features, valid = self.frontend(x, valid)
        mean = features.sum(dim=-1) / valid.sum(dim=-1, keepdim=True).to(features.dtype)
        maximum = features.masked_fill(~valid[:, None], -torch.inf).amax(dim=-1)
        return {"regression": F.relu(self.head(torch.cat((mean, maximum), dim=-1)))}

    def predict_potentials(self, x: Tensor, valid: Tensor) -> dict[str, Tensor]:
        return self(x, valid)


def build_baseline(cfg: dict) -> nn.Module:
    settings = cfg.get("baseline", {})
    model = cfg["model"]
    if cfg["method"] in {"groupdro", "mldg"}:
        return CountingModel(**model)
    kwargs = {"in_channels": model.get("in_channels", 270), "width": settings.get("width", 64),
              "dropout": model.get("dropout", 0.1)}
    if cfg["method"] == "activity_cnn":
        return ActivityCNN(**kwargs)
    if cfg["method"] == "set_transformer":
        return QuerySetTransformer(**kwargs, max_occupancy=model["max_occupancy"],
                                   heads=settings.get("heads", 4), encoder_layers=settings.get("encoder_layers", 1),
                                   decoder_layers=settings.get("decoder_layers", 2))
    raise ValueError(f"Not an external/task-adapted baseline: {cfg['method']}")


def counts_to_slots(counts: Tensor, max_occupancy: int) -> Tensor:
    """Pad the activity multiset with empty=9; 'nothing' remains action index 2."""
    if counts.ndim != 2 or counts.shape[1] != 9 or bool((counts < 0).any()):
        raise ValueError("counts must be nonnegative [B,9].")
    if counts.is_floating_point() and not bool((counts == counts.round()).all()):
        raise ValueError("counts must be integral.")
    targets = []
    for row in counts.detach().cpu().tolist():
        if sum(row) > max_occupancy:
            raise ValueError("Target occupancy exceeds available prediction slots.")
        labels = [k for k, c in enumerate(row) for _ in range(int(c))]
        targets.append(labels + [9] * (max_occupancy - len(labels)))
    return torch.tensor(targets, dtype=torch.long, device=counts.device)


def permutation_invariant_set_loss(logits: Tensor, counts: Tensor, empty_weight: float = 0.1) -> Tensor:
    """Exact minimum-cost assignment for M<=5, equivalent to Hungarian matching.

    Enumerating at most 5!=120 assignments avoids a SciPy CPU matching dependency.
    The matching cost and fitted objective are the same weighted slot CE. Ties
    choose the first lexicographic permutation, and matching itself is detached.
    """
    if logits.ndim != 3 or logits.shape[-1] != 10 or not 1 <= logits.shape[1] <= 5:
        raise ValueError("slot logits must have shape [B,M<=5,10].")
    if empty_weight <= 0 or not math.isfinite(empty_weight):
        raise ValueError("empty_weight must be finite and positive.")
    targets = counts_to_slots(counts, logits.shape[1])
    if targets.shape[0] != logits.shape[0]:
        raise ValueError("Target and logits batch sizes disagree.")
    permutations_tensor = torch.tensor(list(permutations(range(logits.shape[1]))), device=logits.device)
    candidate_targets = targets[:, permutations_tensor]
    log_probability = F.log_softmax(logits.float(), dim=-1)
    gathered = log_probability[:, None].expand(-1, len(permutations_tensor), -1, -1).gather(
        -1, candidate_targets[..., None]).squeeze(-1)
    weights = torch.where(candidate_targets == 9, empty_weight, 1.0)
    costs = -(gathered * weights).mean(dim=-1)
    best = costs.detach().argmin(dim=1)
    return costs[torch.arange(len(costs), device=logits.device), best].mean()


def _individual_structured_loss(out, counts, candidates, eta, lambda_occ):
    target_matches = (candidates.to(counts.device)[None] == counts[:, None]).all(dim=-1)
    if not bool((target_matches.sum(dim=1) == 1).all()):
        raise ValueError("Targets must belong to the complete legal count space.")
    target = target_matches.long().argmax(dim=1)
    return F.cross_entropy(joint_scores(out["a"], out["b"], candidates, lambda_occ), target, reduction="none") + eta * F.cross_entropy(
        out["b"].float(), counts.sum(dim=1).long(), reduction="none")


def _group_indices(meta):
    groups = defaultdict(list)
    for i, item in enumerate(meta):
        groups[str(item["combo_id"])].append(i)
    return dict(sorted(groups.items()))


def _all_training_groups(cfg):
    explicit = cfg.get("baseline", {}).get("group_ids")
    if explicit is not None:
        groups = sorted(set(map(str, explicit)))
    else:
        path = Path(cfg.get("manifest", ""))
        if not path.is_file():
            raise ValueError("GroupDRO needs a frozen manifest or baseline.group_ids containing all TRAIN groups.")
        with path.open(encoding="utf-8-sig", newline="") as handle:
            records = list(csv.DictReader(handle))
        groups = sorted({r["combo_id"] for r in records if r["partition"] == "train"
                         and (not cfg.get("no_aux", False) or int(r.get("number_of_users", r.get("n", 0))) >= 2)})
    if not groups:
        raise ValueError("No training groups available for GroupDRO.")
    return groups


def baseline_loss(model, out, x, valid, counts, meta, cfg, candidates, group_state=None):
    """Training-engine adapter; return loss, JSON diagnostics, checkpoint state."""
    method = cfg["method"]
    t = cfg["training"]
    settings = cfg.get("baseline", {})
    validate_training_records(meta)
    if method == "activity_cnn":
        loss, diagnostics = supervised_loss(out, counts, method="b1")
        return loss, diagnostics, group_state
    if method == "set_transformer":
        loss = permutation_invariant_set_loss(out["slots"], counts, settings.get("empty_weight", 0.1))
        return loss, {"set_matching_ce": float(loss.detach())}, group_state
    if method not in {"groupdro", "mldg"}:
        raise ValueError(f"Unsupported external baseline loss: {method}")
    groups = _group_indices(meta)
    per_record = _individual_structured_loss(out, counts, candidates, t["eta"], t["lambda_occ"])
    group_losses = {key: per_record[indices].mean() for key, indices in groups.items()}
    state = dict(group_state or {})
    step = int(state.get("steps", 0))
    if method == "groupdro":
        if not state:
            all_groups = _all_training_groups(cfg)
            state = {"kind": "groupdro", "groups": all_groups,
                     "log_weights": [-math.log(len(all_groups))] * len(all_groups), "steps": 0}
        if state.get("kind") != "groupdro" or not set(groups).issubset(set(state["groups"])):
            raise ValueError("GroupDRO checkpoint group vocabulary does not match training records.")
        rate = float(settings.get("dro_step_size", 0.01))
        if rate < 0 or not math.isfinite(rate):
            raise ValueError("dro_step_size must be finite and nonnegative.")
        weights = torch.tensor(state["log_weights"], dtype=torch.float64, device=counts.device)
        group_position = {g: i for i, g in enumerate(state["groups"])}
        for group, value in group_losses.items():
            weights[group_position[group]] += rate * value.detach().double()
        weights = weights - torch.logsumexp(weights, dim=0)
        # Missing groups contribute zero minibatch loss and retain their global
        # adversarial mass; no undocumented present-group renormalization.
        loss = sum(weights[group_position[g]].exp().float() * value for g, value in group_losses.items())
        state.update(log_weights=weights.detach().cpu().tolist(), steps=step + 1)
        diagnostics = {"groupdro_loss": float(loss.detach()), "observed_groups": len(groups),
                       "total_training_groups": len(state["groups"]),
                       "max_group_weight": float(weights.exp().max())}
        return loss, diagnostics, state

    if state and state.get("kind") != "mldg":
        raise ValueError("Invalid MLDG checkpoint state.")
    state = {"kind": "mldg", "steps": step + 1}
    if len(groups) < 2:
        loss = per_record.mean()
        return loss, {"mldg_fallback_erm": True, "mldg_reason": "fewer_than_two_training_compositions"}, state
    keys = list(groups)
    random.Random(stable_seed(cfg["model_seed"], "mldg_composition_split", step)).shuffle(keys)
    outer_keys = keys[:max(1, len(keys) // 2)]
    inner_keys = keys[len(outer_keys):]
    inner_loss = torch.stack([group_losses[g] for g in inner_keys]).mean()
    alpha = float(settings.get("inner_learning_rate", 0.001))
    beta = float(settings.get("meta_weight", 1.0))
    if alpha <= 0 or beta < 0 or not math.isfinite(alpha + beta):
        raise ValueError("MLDG needs finite inner_learning_rate>0 and meta_weight>=0.")
    params = dict(model.named_parameters())
    names = [key for key, value in params.items() if value.requires_grad]
    gradients = torch.autograd.grad(inner_loss, [params[name] for name in names], create_graph=True,
                                    retain_graph=True, allow_unused=True)
    adapted = dict(params)
    for name, gradient in zip(names, gradients):
        if gradient is not None:
            adapted[name] = params[name] - alpha * gradient
    outer_indices = [i for g in outer_keys for i in groups[g]]
    buffers = {key: value.clone() for key, value in model.named_buffers()}
    # functional_call never mutates the original model parameters. The inner
    # step remains connected for the exact second-order meta gradient.
    adapted_out = functional_call(model, (adapted, buffers), (x[outer_indices], valid[outer_indices]), strict=True)
    outer_per_record = _individual_structured_loss(adapted_out, counts[outer_indices], candidates, t["eta"], t["lambda_occ"])
    outer_values = []
    start = 0
    for group in outer_keys:
        length = len(groups[group])
        outer_values.append(outer_per_record[start:start + length].mean())
        start += length
    outer_loss = torch.stack(outer_values).mean()
    loss = inner_loss + beta * outer_loss
    return loss, {"mldg_inner_loss": float(inner_loss.detach()), "mldg_outer_loss": float(outer_loss.detach()),
                  "mldg_inner_compositions": sorted(inner_keys), "mldg_outer_compositions": sorted(outer_keys),
                  "mldg_second_order": True, "mldg_fallback_erm": False}, state


def baseline_decode(out, cfg):
    if cfg["method"] == "set_transformer":
        labels = out["slots"].argmax(dim=-1)
        return torch.stack([(labels == k).sum(dim=1) for k in range(9)], dim=1).long()
    if cfg["method"] == "activity_cnn":
        candidates = enumerate_counts(9, cfg["model"]["max_occupancy"]).to(out["regression"].device)
        return decode(out, "b1", candidates=candidates,
                      project_regression=cfg.get("evaluation", {}).get("project_regression", False))
    raise ValueError("GroupDRO/MLDG use ordinary structured decoding in the engine.")
