"""Reproducible metadata/waveform audits; no automatic exclusions or repartitions."""
from __future__ import annotations

import csv
import json
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Mapping, Sequence

from .data import ACTIONS, DataValidationError, WaveformStore, read_manifest, sha256_file


def audit_metadata(records: Sequence[Mapping[str, Any]], *, no_aux: bool = False,
                   development: bool = False) -> dict:
    """Check a supplied effective record set without changing its assignments.

    Complete-composition exclusion applies to core 2/3-person train versus
    val_unseen versus test_unseen. Seen testing deliberately shares compositions;
    user-group overlap is measured but is not treated as capture-session leakage.
    """
    rows = [r for r in records if not str(r["partition"]).startswith("excluded")]
    if no_aux:
        rows = [r for r in rows if int(r["n"]) in (2, 3)]
    errors: list[str] = []
    if development and any(str(r["partition"]).startswith("test") for r in rows):
        errors.append("Train-only development manifests must not contain test partitions")
    if not development and any(r["partition"] == "val_seen" for r in rows):
        errors.append("val_seen requires a verified train-only development protocol")
    ids = [str(r["record_id"]) for r in rows]
    if len(ids) != len(set(ids)):
        errors.append("Duplicate record IDs in effective subset")
    train = [r for r in rows if r["partition"] == "train"]
    if not train:
        errors.append("Effective subset contains no training records")
    partition_sets = {}
    seen_partition = "val_seen" if development else "test_seen"
    core_partitions = ("train", "val_unseen", "val_seen") if development else ("train", "val_unseen", "test_unseen", "test_seen")
    for partition in core_partitions:
        selected = [r for r in rows if r["partition"] == partition and int(r["n"]) in (2, 3)]
        partition_sets[partition] = {(int(r["n"]), r["combo_id"]) for r in selected}
        if (partition != "test_seen" or development) and not selected:
            errors.append(f"Effective subset has no core records in {partition}")
    overlaps = {}
    exclusion_pairs = (("train", "val_unseen"),) if development else (("train", "val_unseen"), ("train", "test_unseen"), ("val_unseen", "test_unseen"))
    for first, second in exclusion_pairs:
        overlap = sorted(partition_sets[first] & partition_sets[second])
        overlaps[f"{first}|{second}"] = [list(v) for v in overlap]
        if overlap:
            errors.append(f"Complete compositions overlap between {first} and {second}")
    missing_seen = sorted(partition_sets[seen_partition] - partition_sets["train"])
    if missing_seen:
        errors.append(f"Some {seen_partition} compositions lost all corresponding training records")
    train_contexts: dict[tuple, set] = defaultdict(set)
    cell_contexts: dict[tuple, dict] = defaultdict(lambda: defaultdict(list))
    for row in train:
        for k, count in enumerate(row["counts"]):
            if count > 0:
                group = (int(row["n"]), k, int(count))
                train_contexts[group].add(row["combo_id"])
                cell = (*group, row["environment"], row["wifi_band"])
                cell_contexts[cell][row["combo_id"]].append(row["record_id"])
    held_support = {}
    for partition in core_partitions[1:]:
        missing = set()
        by_count: dict[int, Counter] = defaultdict(Counter)
        unpairable_combos: dict[int, set] = defaultdict(set)
        for row in rows:
            if row["partition"] != partition:
                continue
            for k, count in enumerate(row["counts"]):
                if count <= 0:
                    continue
                key = (int(row["n"]), k, int(count))
                contexts = train_contexts[key]
                if not contexts:
                    missing.add((key[0], ACTIONS[k], int(count)))
                by_count[int(count)]["positive_entries"] += 1
                by_count[int(count)]["supported_entries"] += bool(contexts)
                by_count[int(count)]["directly_pairable_entries"] += len(contexts) >= 2
                if len(contexts) < 2:
                    unpairable_combos[int(count)].add(row["combo_id"])
        if missing:
            errors.append(f"{partition} has positive (occupancy,action,count) conditions absent from training")
        held_support[partition] = {
            "missing_positive_conditions": [list(v) for v in sorted(missing)],
            "by_positive_count": {str(count): {**dict(values),
                 "unpairable_complete_compositions": sorted(unpairable_combos[count])}
                 for count, values in sorted(by_count.items())}}
    groups = []
    observed_groups = sorted({(int(r["n"]), k, int(count)) for r in rows
                              for k, count in enumerate(r["counts"]) if count > 0})
    for group in observed_groups:
        cells = [(cell, combinations) for cell, combinations in cell_contexts.items()
                 if cell[:3] == group]
        groups.append({"n": group[0], "action": ACTIONS[group[1]], "count": group[2],
                       "train_contexts": len(train_contexts[group]),
                       "train_combo_ids": sorted(train_contexts[group]),
                       "pairable_cells": sum(len(combinations) >= 2 for _, combinations in cells),
                       "controlled_quadruplet_cells": sum(
                           sum(len(set(ids)) >= 2 for ids in combinations.values()) >= 2
                           for _, combinations in cells)})
    by_group: dict[str, Counter] = defaultdict(Counter)
    for row in rows:
        by_group[str(row.get("user_group_id", "UNVERIFIED"))][row["partition"]] += 1
    shared = sorted(group for group, partitions in by_group.items()
                    if group != "UNVERIFIED" and partitions["train"] and partitions["test_unseen"])
    return {"ok": not errors, "errors": errors, "no_aux": no_aux, "development": development,
            "effective_records": len(rows), "partition_counts": dict(Counter(r["partition"] for r in rows)),
            "normalization_train_records": len(train),
            "normalization_train_record_ids": sorted(r["record_id"] for r in train),
            "core_composition_counts": {p: len(v) for p, v in partition_sets.items()},
            "composition_overlaps": overlaps,
            "test_seen_compositions_without_training": [list(v) for v in missing_seen],
            "positive_count_support": held_support, "train_pairability": groups,
            "known_user_groups_shared_train_test": shared,
            "user_group_is_capture_session": False,
            "capture_session_status": "UNVERIFIED",
            "shared_user_group_is_allowed_for_this_fixed_subject_task": True}


def _duplicates(status_rows: Sequence[Mapping[str, Any]], field: str,
                normalization_ids: set[str]) -> list[dict]:
    groups: dict[str, list] = defaultdict(list)
    for row in status_rows:
        if row.get(field):
            groups[str(row[field])].append(row)
    result = []
    for digest, rows in sorted(groups.items()):
        if len(rows) < 2:
            continue
        partitions = sorted({r["partition"] for r in rows})
        result.append({"sha256": digest, "record_ids": sorted(r["record_id"] for r in rows),
                       "partitions": partitions, "cross_partition": len(partitions) > 1,
                       "touches_normalization_train": any(r["record_id"] in normalization_ids for r in rows),
                       "inconsistent_labels": len({r["combo_id"] for r in rows}) > 1})
    return result


def audit_dataset(manifest_path: str | Path, store: WaveformStore | None,
                  output_dir: str | Path, *, metadata_only: bool = False,
                  no_aux: bool = False, selected_record_ids: Sequence[str] | None = None,
                  max_occupancy: int = 3) -> dict:
    """Write auditable reports and an eligible-ID proposal; never alter the manifest.

    ``selected_record_ids`` allows an explicitly accepted effective subset to be
    re-audited after external quality decisions. Missing files and bad records
    make the waveform audit fail; use the written candidate ID list only after
    reviewing exclusions and lost composition/count support. No random subset or
    synthetic fallback is used when the real amplitudes are unavailable.
    """
    all_records = read_manifest(manifest_path, max_occupancy=None)
    records = [r for r in all_records if int(r["n"]) <= max_occupancy
               and not r["partition"].startswith("excluded")]
    if no_aux:
        records = [r for r in records if int(r["n"]) in (2, 3)]
    if selected_record_ids is not None:
        selected_ids = set(selected_record_ids)
        if len(selected_ids) != len(selected_record_ids):
            raise DataValidationError("Selected record ID list contains duplicates")
        unknown = selected_ids - {r["record_id"] for r in records}
        if unknown:
            raise DataValidationError(f"Selected IDs are outside this task scope: {sorted(unknown)[:10]}")
        records = [r for r in records if r["record_id"] in selected_ids]
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    metadata = audit_metadata(records, no_aux=no_aux)
    report = {"manifest": str(Path(manifest_path).resolve()),
              "manifest_sha256": sha256_file(manifest_path),
              "source_manifest_records": len(all_records),
              "audited_scope_max_occupancy": max_occupancy,
              "explicit_subset": selected_record_ids is not None,
              "metadata": metadata, "metadata_only": metadata_only,
              "waveforms_verified": False, "ok": metadata["ok"],
              "capture_session_audit": "NOT_PERFORMED; user-group IDs are not session IDs",
              "near_duplicate_audit": "NOT_PERFORMED; exact file/raw/input hashes do not detect near-duplicate or overlapping segments",
              "verification_scope": "Metadata, waveform quality and exact duplicate checks only; not proof of recording/session independence"}
    if metadata_only:
        report["status"] = "METADATA_ONLY_WAVEFORMS_PENDING"
    else:
        if store is None:
            raise ValueError("A WaveformStore is required unless metadata_only=True")
        normalization_ids = set(metadata["normalization_train_record_ids"])
        statuses = []
        accepted_records = []
        for row in records:
            status = {"record_id": row["record_id"], "partition": row["partition"],
                      "combo_id": row["combo_id"], "n": row["n"],
                      "in_normalization_train": row["record_id"] in normalization_ids}
            try:
                _, _, details = store.load_detailed(row, hashes=True)
                status.update(details)
                status.update(status="PASS", reason="")
                accepted_records.append(row)
            except (OSError, ValueError, EOFError, zipfile.BadZipFile) as error:
                status.update(status="FAIL", reason=f"{type(error).__name__}: {error}")
                # File hashes remain useful for malformed duplicate containers.
                try:
                    path = store.resolve_path(row)
                    status.update(path=str(path), file_sha256=sha256_file(path))
                except (OSError, ValueError):
                    pass
            statuses.append(status)
        columns = list(dict.fromkeys(key for row in statuses for key in row))
        with (output_dir / "waveform_audit.csv").open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=columns or ["record_id", "status", "reason"])
            writer.writeheader()
            writer.writerows(statuses)
        duplicates = {key: _duplicates(statuses, key, normalization_ids)
                      for key in ("file_sha256", "raw_valid_amplitude_sha256", "model_input_sha256")}
        duplicate_risk = any(group["cross_partition"] or group["inconsistent_labels"]
                             for groups in duplicates.values() for group in groups)
        passed = len(accepted_records)
        failed = len(records) - passed
        eligible_ids = sorted(r["record_id"] for r in accepted_records)
        candidate = {"status": "REVIEW_REQUIRED_NOT_AUTOMATICALLY_APPLIED",
                     "manifest_sha256": report["manifest_sha256"],
                     "record_ids": eligible_ids,
                     "warning": "Passing quality thresholds does not resolve duplicate/session risks."}
        (output_dir / "eligible_record_ids.json").write_text(
            json.dumps(candidate, indent=2, ensure_ascii=False), encoding="utf-8")
        effective = audit_metadata(accepted_records, no_aux=no_aux)
        report.update(waveforms_verified=bool(records) and failed == 0,
                      waveform_passed=passed, waveform_failed=failed,
                      failures_by_partition=dict(Counter(r["partition"] for r in statuses if r["status"] == "FAIL")),
                      failures_by_reason=dict(Counter(r["reason"].split(":", 1)[0] for r in statuses if r["status"] == "FAIL")),
                      preprocessing=store.preprocessing_spec(), duplicate_groups=duplicates,
                      duplicate_risk_requires_resolution=duplicate_risk,
                      effective_candidate_metadata=effective,
                      total_repaired_nonfinite_entries=sum(r.get("nonfinite_count", 0) for r in statuses),
                      truncated_records=sum(r.get("truncated_points", 0) > 0 for r in statuses),
                      records_with_zero_channels=sum(r.get("zero_channels", 0) > 0 for r in statuses),
                      ok=metadata["ok"] and failed == 0 and not duplicate_risk and effective["ok"])
        report["status"] = "PASS_WAVEFORM_AND_METADATA" if report["ok"] else "REVIEW_REQUIRED"
        if passed == 0:
            report["blocking_message"] = "No usable real CSI waveforms were loaded. Supply real files; no synthetic fallback is permitted."
    (output_dir / "audit.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return report
