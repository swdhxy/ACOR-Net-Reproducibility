"""Count metrics and descriptive paired combination bootstrap.

These functions do not assume sample-level independence. Bootstrap intervals
condition on the fixed participants, recordings, and fitted models; they are
not confidence claims for new users or capture sessions.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
import json
from typing import Any

import numpy as np


ACTION_ORDER = ("jump", "lie_down", "nothing", "pick_up", "rotation", "sit_down", "stand_up", "walk", "wave")


def _array(values: Any) -> np.ndarray:
    if hasattr(values, "detach"):
        values = values.detach().cpu().numpy()
    result = np.asarray(values)
    if result.ndim != 2:
        raise ValueError("Counts must be [N,K] arrays")
    if result.dtype.kind not in "iuf" or not np.isfinite(result).all():
        raise ValueError("Counts must be finite numeric values")
    if (result < 0).any() or not (result == np.floor(result)).all():
        raise ValueError("Counts must be nonnegative integers")
    if (result > np.iinfo(np.int64).max // max(1, result.size)).any():
        raise ValueError("Counts exceed the safe integer accumulation range")
    return result.astype(np.int64)


def _ratio(numerator: float | int, denominator: float | int) -> float | None:
    return float(numerator / denominator) if denominator else None


def _combo_key(row: np.ndarray | tuple) -> str:
    return ",".join(str(int(x)) for x in row)


def _basic(truth: np.ndarray, pred: np.ndarray, max_occupancy: int) -> dict[str, Any]:
    n, k = truth.shape
    error = np.abs(pred - truth)
    positive, zero = truth > 0, truth == 0
    exact = (truth == pred).all(axis=1)
    n_true, n_pred = truth.sum(axis=1), pred.sum(axis=1)
    true_positive = int(np.minimum(truth, pred).sum())
    false_positive = int(np.maximum(pred - truth, 0).sum())
    false_negative = int(np.maximum(truth - pred, 0).sum())
    counts = {
        "samples": n,
        "actions": k,
        "exact_records": int(exact.sum()),
        "all_absolute_error": int(error.sum()),
        "all_entries": n * k,
        "positive_absolute_error": int(error[positive].sum()),
        "positive_entries": int(positive.sum()),
        "zero_false_positive_entries": int(((pred > 0) & zero).sum()),
        "zero_entries": int(zero.sum()),
        "multiset_true_positive": true_positive,
        "multiset_false_positive": false_positive,
        "multiset_false_negative": false_negative,
        "illegal_predictions": int((n_pred > max_occupancy).sum()),
    }
    groups: dict[tuple, list[int]] = defaultdict(list)
    for index, row in enumerate(truth):
        groups[tuple(row)].append(index)
    combo_accuracy = [float(exact[indices].mean()) for indices in groups.values()]
    # Supplementary score from the proposal: first equal-weight compositions
    # within each occupancy, then give n=2 and n=3 weight 1/2 each. A missing
    # stratum is NA, not zero and not a silently renormalized single stratum.
    occupancy_combos = {
        value: [float(exact[ix].mean()) for combo, ix in groups.items() if sum(combo) == value]
        for value in (2, 3)
    }
    balanced_exact = (float(np.mean([np.mean(v) for v in occupancy_combos.values()]))
                      if all(occupancy_combos.values()) else None)
    occupancy_f1 = []
    for value in sorted(set(n_true.tolist()) | set(n_pred.tolist())):
        tp = int(((n_true == value) & (n_pred == value)).sum())
        fp = int(((n_true != value) & (n_pred == value)).sum())
        fn = int(((n_true == value) & (n_pred != value)).sum())
        occupancy_f1.append(2 * tp / (2 * tp + fp + fn))
    return {
        "macro_exact_match_by_complete_composition": float(np.mean(combo_accuracy)) if combo_accuracy else None,
        "balanced_occupancy_macro_exact": balanced_exact,
        "sample_exact_match": _ratio(int(exact.sum()), n),
        "all_count_mae": _ratio(counts["all_absolute_error"], counts["all_entries"]),
        "positive_count_mae": _ratio(counts["positive_absolute_error"], counts["positive_entries"]),
        "zero_count_false_positive_rate": _ratio(counts["zero_false_positive_entries"], counts["zero_entries"]),
        "multiset_micro_f1": _ratio(2 * true_positive, 2 * true_positive + false_positive + false_negative),
        "occupancy_accuracy": _ratio(int((n_true == n_pred).sum()), n),
        "occupancy_mae": _ratio(int(np.abs(n_true - n_pred).sum()), n),
        "occupancy_macro_f1": float(np.mean(occupancy_f1)) if occupancy_f1 else None,
        "illegal_rate": _ratio(counts["illegal_predictions"], n),
        "denominators_and_numerators": counts,
    }


def _metadata_rows(metadata: Any, length: int) -> list[dict]:
    if metadata is None:
        return [{} for _ in range(length)]
    if isinstance(metadata, Mapping):
        columns = {}
        for key, values in metadata.items():
            if hasattr(values, "detach"):
                values = values.detach().cpu().tolist()
            if len(values) != length:
                raise ValueError(f"Metadata column {key} does not match record count")
            columns[key] = values
        return [{key: values[i] for key, values in columns.items()} for i in range(length)]
    rows = list(metadata)
    if len(rows) != length or any(not isinstance(row, Mapping) for row in rows):
        raise ValueError("Metadata must be a sequence of row mappings or a mapping of columns")
    return [dict(row) for row in rows]


def evaluate_counts(
    truth: Any,
    pred: Any,
    metadata: Sequence[Mapping] | Mapping | None = None,
    max_occupancy: int = 3,
    train_context_records: Sequence[Mapping] | None = None,
) -> dict[str, Any]:
    """Evaluate integer predictions with explicit denominators and NA=None.

    Primary metrics are computed on exactly the caller's supplied partition.
    Pass only test_unseen records for the primary result, not concatenated
    test_seen/auxiliary records. Per-count strata concern individual action
    entries; other strata concern whole records.
    """
    truth, pred = _array(truth), _array(pred)
    if truth.shape != pred.shape:
        raise ValueError("Truth and prediction shapes must match")
    if max_occupancy < 0 or (truth.sum(axis=1) > max_occupancy).any():
        raise ValueError("Ground-truth occupancy exceeds evaluation maximum")
    rows = _metadata_rows(metadata, len(truth))
    result = _basic(truth, pred, max_occupancy)
    combo_indices: dict[tuple, list[int]] = defaultdict(list)
    for i, counts in enumerate(truth):
        combo_indices[tuple(counts)].append(i)
    result["per_composition"] = {
        _combo_key(combo): {"counts": [int(v) for v in combo], **_basic(truth[ix], pred[ix], max_occupancy)}
        for combo, ix in sorted(combo_indices.items())
    }
    by = {"occupancy": [int(v) for v in truth.sum(axis=1)]}
    aliases = {
        "environment": ("environment", "env"),
        "wifi_band": ("wifi_band", "band"),
        "user_group": ("user_group_id", "user_group"),
        "train_context_pairability": ("train_context_pairability", "pairability"),
    }
    for name, options in aliases.items():
        values = [next((row[key] for key in options if key in row and row[key] not in ("", None)), None) for row in rows]
        if name == "user_group":
            for i, row in enumerate(rows):
                record = str(row.get("record_id", ""))
                if values[i] is None and record.startswith("act_") and len(record.split("_")) >= 3:
                    values[i] = record.split("_")[1]
        if any(value is not None for value in values):
            by[name] = values
    result["strata"] = {}
    for name, values in by.items():
        indices: dict[str, list[int]] = defaultdict(list)
        for i, value in enumerate(values):
            indices["UNVERIFIED" if value is None else str(value)].append(i)
        result["strata"][name] = {
            value: _basic(truth[ix], pred[ix], max_occupancy)
            for value, ix in sorted(indices.items())
        }
    result["strata"]["true_count"] = {}
    for value in sorted(set(truth.ravel().tolist())):
        select = truth == value
        total = int(select.sum())
        absolute_error = int(np.abs(pred - truth)[select].sum())
        result["strata"]["true_count"][str(value)] = {
            "entries": total,
            "absolute_error": absolute_error,
            "count_mae": _ratio(absolute_error, total),
            "count_accuracy": _ratio(int((pred == truth)[select].sum()), total),
        }
    # Regression is intentionally unconstrained. Keep raw predictions in all
    # numeric metrics, but collect impossible counts in one bounded display bin.
    overflow = max_occupancy + 1
    confusion_labels = list(range(max_occupancy + 1)) + [f">{max_occupancy}"]
    action_confusion = []
    for k in range(truth.shape[1]):
        matrix = np.zeros((overflow + 1, overflow + 1), dtype=np.int64)
        np.add.at(matrix, (truth[:, k], np.minimum(pred[:, k], overflow)), 1)
        action_confusion.append({
            "action": ACTION_ORDER[k] if k < len(ACTION_ORDER) else str(k),
            "labels": confusion_labels, "matrix": matrix.tolist(),
        })
    occupancy_confusion = np.zeros((overflow + 1, overflow + 1), dtype=np.int64)
    np.add.at(occupancy_confusion, (truth.sum(axis=1), np.minimum(pred.sum(axis=1), overflow)), 1)
    result["confusion"] = {
        "orientation": "rows=true, columns=predicted",
        "actions": action_confusion,
        "occupancy": {"labels": confusion_labels, "matrix": occupancy_confusion.tolist()},
        "overflow_note": "Only visualization bins use >M; all errors and accuracy use original predictions.",
    }
    result["user_group_diagnostic"] = {
        "scope": "equal groups within n, then equal available n in {2,3}; descriptive, not causal matching",
        "per_occupancy": {},
        "equal_occupancy_group_exact": None,
    }
    if "user_group" in by:
        diagnostic_values = []
        for n in (2, 3):
            groups: dict[str, list[int]] = defaultdict(list)
            for i, group in enumerate(by["user_group"]):
                if int(truth[i].sum()) == n and group is not None:
                    groups[str(group)].append(i)
            scores = {group: float((truth[ix] == pred[ix]).all(axis=1).mean()) for group, ix in groups.items()}
            mean = float(np.mean(list(scores.values()))) if scores else None
            result["user_group_diagnostic"]["per_occupancy"][str(n)] = {
                "groups": {group: {"exact": score, "records": len(groups[group])} for group, score in scores.items()},
                "equal_group_exact": mean,
            }
            if mean is not None:
                diagnostic_values.append(mean)
        if diagnostic_values:
            result["user_group_diagnostic"]["equal_occupancy_group_exact"] = float(np.mean(diagnostic_values))
    if train_context_records is not None:
        contexts = defaultdict(set)
        seen_combos = set()
        for row in train_context_records:
            if row.get("partition") != "train":
                raise ValueError("Context support must be derived from train records only")
            counts = tuple(int(v) for v in row["counts"])
            seen_combos.add(counts)
            for k, r in enumerate(counts):
                if r > 0:
                    env, band = row.get("environment"), row.get("wifi_band")
                    if env not in (None, "") and band not in (None, ""):
                        contexts[(sum(counts),k,r,str(env),str(band))].add(counts)
        support = defaultdict(lambda: {"entries":0,"absolute_error":0,"exact_entries":0})
        for i, counts in enumerate(truth):
            for k,r in enumerate(counts):
                if r>0:
                    env, band = rows[i].get("environment"), rows[i].get("wifi_band")
                    if env in (None, "") or band in (None, ""):
                        key=f"r{r}_support_unknown"
                    else:
                        direct=len(contexts[(int(counts.sum()),k,int(r),str(env),str(band))])>=2
                        key=f"r{r}_{'direct_pairable' if direct else 'no_direct_pair'}"
                    support[key]["entries"]+=1
                    support[key]["absolute_error"]+=int(abs(pred[i,k]-r))
                    support[key]["exact_entries"]+=int(pred[i,k]==r)
        result["context_support_strata"]={k:{**v,"count_mae":v["absolute_error"]/v["entries"]} for k,v in support.items()}
        wrong=(truth!=pred).any(axis=1)
        attracted=sum(bool(wrong[i]) and tuple(row) in seen_combos for i,row in enumerate(pred))
        result["errors_to_seen_compositions"]={"all_errors":int(wrong.sum()),"seen_composition_errors":attracted,
            "conditional_fraction":_ratio(attracted,int(wrong.sum())),"all_record_fraction":_ratio(attracted,len(truth))}
        result["repeated_compositions"]={k:v for k,v in result["per_composition"].items() if max(v["counts"])>=2}
    return result


def _row_counts(row: Mapping, names: tuple[str, ...]) -> tuple[int, ...]:
    for name in names:
        if name in row:
            value = row[name]
            if isinstance(value, str):
                value = json.loads(value)
            arr = _array([value])
            return tuple(int(v) for v in arr[0])
    raise ValueError(f"Prediction row requires one of {names}")


def paired_bootstrap(
    prediction_rows_a: Sequence[Mapping],
    prediction_rows_b: Sequence[Mapping],
    replicates: int = 2000,
    seed: int | None = None,
) -> dict[str, Any]:
    """Pair exact-match differences A-B, average inits, then resample combos.

    Required row keys are ``record_id``, ``split_seed``, ``model_seed`` plus
    ``truth`` (or ``true_counts``/``counts``) and ``pred`` (or ``pred_counts``/
    ``prediction``). Duplicate or mismatched keys/targets/cohorts are errors.
    Each split is estimated separately; overlapping splits are never treated
    as independent observations. The n=2 and n=3 stratum weights are their
    observed numbers of held-out compositions (7/18 and 11/18 in the release).
    """
    if replicates < 1:
        raise ValueError("replicates must be positive")

    def index(rows: Sequence[Mapping]) -> dict[tuple, Mapping]:
        indexed = {}
        for row in rows:
            try:
                key = (str(row["split_seed"]), str(row["model_seed"]), str(row["record_id"]))
            except KeyError as error:
                raise ValueError("Bootstrap requires split_seed, model_seed, and record_id") from error
            if key in indexed:
                raise ValueError(f"Duplicate prediction key: {key}")
            if row.get("partition", "test_unseen") != "test_unseen":
                raise ValueError("Primary composition bootstrap accepts test_unseen only")
            indexed[key] = row
        return indexed

    a, b = index(prediction_rows_a), index(prediction_rows_b)
    if not a or a.keys() != b.keys():
        raise ValueError("Both methods must have identical nonempty record/split/initialization keys")
    by_split: dict[str, list[tuple[tuple, tuple, float]]] = defaultdict(list)
    truth_by_record = {}
    for key in sorted(a):
        true_a = _row_counts(a[key], ("truth", "true_counts", "counts"))
        true_b = _row_counts(b[key], ("truth", "true_counts", "counts"))
        pred_a = _row_counts(a[key], ("pred", "pred_counts", "prediction"))
        pred_b = _row_counts(b[key], ("pred", "pred_counts", "prediction"))
        if true_a != true_b or len(pred_a) != len(true_a) or len(pred_b) != len(true_a):
            raise ValueError(f"Mismatched targets/count dimensions for {key}")
        record_key = (key[0], key[2])
        if record_key in truth_by_record and truth_by_record[record_key] != true_a:
            raise ValueError("Ground truth changes across model initializations")
        truth_by_record[record_key] = true_a
        if sum(true_a) not in (2, 3):
            raise ValueError("Primary bootstrap only supports two/three-person unseen combinations")
        difference = float(pred_a == true_a) - float(pred_b == true_a)
        by_split[key[0]].append((key, true_a, difference))
    result: dict[str, Any] = {
        "comparison": "exact_match_A_minus_B",
        "scope": "descriptive conditional on fixed subjects, groups, records, and fitted models",
        "replicates": replicates, "seed": seed, "splits": {},
        "pooled_across_splits": False,
    }
    for split_index, (split, entries) in enumerate(sorted(by_split.items())):
        inits = sorted({key[1] for key, _, _ in entries})
        records = {init: {key[2] for key, _, _ in entries if key[1] == init} for init in inits}
        if any(records[init] != records[inits[0]] for init in inits):
            raise ValueError("Every initialization must predict exactly the same records within a split")
        grouped: dict[tuple, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
        for key, combo, difference in entries:
            grouped[combo][key[1]].append(difference)
        if any(set(by_init) != set(inits) for by_init in grouped.values()):
            raise ValueError("Every combination must be available in every initialization")
        combo_delta = {combo: float(np.mean([np.mean(by_init[init]) for init in inits])) for combo, by_init in grouped.items()}
        strata = {n: np.asarray([delta for combo, delta in sorted(combo_delta.items()) if sum(combo) == n]) for n in (2, 3)}
        if any(len(values) == 0 for values in strata.values()):
            raise ValueError("Both n=2 and n=3 strata are required")
        total_combos = sum(len(values) for values in strata.values())
        weights = {n: len(values) / total_combos for n, values in strata.items()}
        split_rng_seed = 10000 + int(split) if seed is None else seed + split_index
        rng = np.random.default_rng(split_rng_seed)
        boot = np.zeros(replicates, dtype=np.float64)
        balanced_boot = np.zeros(replicates, dtype=np.float64)
        for n, values in strata.items():
            samples = rng.integers(0, len(values), size=(replicates, len(values)))
            resampled_mean = values[samples].mean(axis=1)
            boot += weights[n] * resampled_mean
            balanced_boot += 0.5 * resampled_mean
        init_delta = {
            init: float(np.mean([np.mean(by_init[init]) for by_init in grouped.values()]))
            for init in inits
        }
        balanced_init_delta = {
            init: float(np.mean([
                np.mean([np.mean(by_init[init]) for combo, by_init in grouped.items() if sum(combo) == n])
                for n in (2, 3)
            ])) for init in inits
        }
        result["splits"][split] = {
            "bootstrap_seed": split_rng_seed,
            "estimate": float(np.mean(list(combo_delta.values()))),
            "percentile_interval_95": [float(x) for x in np.quantile(boot, [0.025, 0.975])],
            "initialization_estimates": init_delta,
            "initialization_range": [min(init_delta.values()), max(init_delta.values())],
            "initializations": inits,
            "stratum_compositions": {str(n): len(values) for n, values in strata.items()},
            "stratum_weights": {str(n): weight for n, weight in weights.items()},
            "per_composition_mean_difference": {_combo_key(combo): delta for combo, delta in sorted(combo_delta.items())},
            "balanced_occupancy": {
                "estimate": float(np.mean([values.mean() for values in strata.values()])),
                "percentile_interval_95": [float(x) for x in np.quantile(balanced_boot, [0.025, 0.975])],
                "stratum_weights": {"2": 0.5, "3": 0.5},
                "initialization_estimates": balanced_init_delta,
                "initialization_range": [min(balanced_init_delta.values()), max(balanced_init_delta.values())],
                "scope": "Supplementary equal-occupancy contrast; same stratified draws as the primary composition-weighted result.",
            },
        }
    return result
