#!/usr/bin/env python3
"""Read-only reuse of the original, pre-test-frozen 81 baseline runs.

Does not run inference, retrain, rewrite legacy files, or select on test scores.
The historical test benchmark has already been inspected; it is not a fresh test.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import shutil

METHODS = ("b1", "b2", "b3", "b4", "b5", "amar", "mushot_source", "activity_counting", "mldg")
SPLITS = (2026, 2027, 2028)
SEEDS = (11, 22, 33)
PARTITIONS = ("test_unseen", "test_seen", "test_aux")
LEGACY_ROOT = PurePosixPath("${HOME}/wificount")
FREEZE_SHA256 = "7840aa464718d287872206881d0c1f0e594e739afce416500fd780867dada0e6"
SELECTION_RULE = "val_unseen macro_exact_match_by_complete_composition; lower positive_count_mae; earlier epoch"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def legacy_path(root, value):
    """Map only the documented original project prefix; reject path escape."""
    suffix = PurePosixPath(value).relative_to(LEGACY_ROOT)
    require(".." not in suffix.parts, f"Unsafe legacy path: {value}")
    path = root.joinpath(*suffix.parts).resolve()
    require(path.is_relative_to(root.resolve()), f"Legacy path outside root: {value}")
    return path


def verify_hash(path, expected):
    require(file_hash(path) == expected, f"SHA256 mismatch: {path}")


def load_verified_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def same_metrics(actual, expected, context="metrics"):
    """Compare the entire nested metric report, allowing float roundoff only."""
    if isinstance(expected, dict):
        require(isinstance(actual, dict) and actual.keys() == expected.keys(), f"Metric keys differ: {context}")
        for key in expected:
            same_metrics(actual[key], expected[key], f"{context}.{key}")
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(actual) == len(expected), f"Metric length differs: {context}")
        for i, (a, b) in enumerate(zip(actual, expected)):
            same_metrics(a, b, f"{context}[{i}]")
    elif isinstance(expected, (int, float)) and not isinstance(expected, bool):
        require(isinstance(actual, (int, float)) and math.isfinite(actual) and
                math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12), f"Metric value differs: {context}")
    else:
        require(actual == expected, f"Metric value differs: {context}")


def prediction_rows(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        for key in ("truth", "pred"):
            row[key] = json.loads(row[key])
        for key in ("split_seed", "model_seed", "n", "predicted_n"):
            row[key] = int(row[key])
    return rows


def validate_predictions(rows, records, cfg, partition):
    expected = {r["record_id"]: r for r in records if r["partition"] == partition}
    ids = [r["record_id"] for r in rows]
    require(bool(expected) and len(ids) == len(set(ids)) and set(ids) == set(expected),
            f"Prediction cohort differs: {cfg['method']} {partition}")
    for row in rows:
        truth = expected[row["record_id"]]
        require(row["partition"] == partition and row["truth"] == list(truth["counts"]),
                f"Ground truth/partition mismatch: {row['record_id']}")
        require(all(row[k] == cfg[k] for k in ("method", "split_seed", "model_seed")),
                f"Prediction method/seed mismatch: {row['record_id']}")
        require(all(str(row.get(k)) == str(truth.get(k)) for k in ("environment", "wifi_band", "user_group_id")),
                f"Prediction metadata differs: {row['record_id']}")
        require(row["n"] == sum(row["truth"]), "Truth occupancy mismatch")
        require(len(row["pred"]) == 9 and all(type(v) is int and v >= 0 for v in row["pred"]),
                "Invalid predicted count vector")
    return len(expected)


def collect(original_root, output, *, manifest_root=None, metadata_only=False):
    root, output = Path(original_root).resolve(), Path(output).resolve()
    require(not output.is_relative_to(root), "Output must be outside the original project")
    freeze_path = root / "runs/plans/freeze.json"
    verify_hash(freeze_path, FREEZE_SHA256)
    frozen = read_json(freeze_path)
    require(frozen["schema"] == 2 and frozen["status"] == "FROZEN_BEFORE_TEST" and
            frozen["test_used_for_selection"] is False, "Invalid original freeze")
    copies = {"legacy/plans/freeze.json": freeze_path}
    all_jobs = []
    for old_path, digest in frozen["plans"].items():
        path = legacy_path(root, old_path)
        verify_hash(path, digest)
        plan = read_json(path)
        require(plan["test_used_for_selection"] is False, "Legacy plan is not train/validation only")
        all_jobs.extend(plan["jobs"])
        copies[f"legacy/plans/{path.name}"] = path
    require(len({j["id"] for j in all_jobs}) == len(all_jobs) and
            {j["id"] for j in all_jobs} == set(frozen["jobs"]), "Original frozen plan set differs")
    jobs = [j for j in all_jobs if j["id"].startswith("core/") and j["config"]["method"] in METHODS and
            j["config"]["training"].get("diagnostic") is None]
    expected = {(m, s, seed) for m in METHODS for s in SPLITS for seed in SEEDS}
    actual = {(j["config"]["method"], j["config"]["split_seed"], j["config"]["model_seed"]) for j in jobs}
    require(len(jobs) == 81 and actual == expected, "Expected exactly 81 selected baseline jobs")
    index_path = root / "runs/plans/evaluation_index.json"
    index = read_json(index_path)
    require(index["freeze_sha256"] == FREEZE_SHA256, "Evaluation index points to another freeze")
    indexed = [(e["job"], e["checkpoint"], e["partition"]) for e in index["evaluations"]]
    require(len(indexed) == len(set(indexed)), "Duplicate evaluation-index entries")
    require(all((j["id"], "best", p) in indexed for j in jobs for p in PARTITIONS), "Missing indexed evaluations")
    copies["legacy/plans/evaluation_index.json"] = index_path
    # V1 source is immutable and intentionally different from the new ACOR engine.
    source = frozen["jobs"][jobs[0]["id"]]["source_sha256"]
    require(all(frozen["jobs"][j["id"]]["source_sha256"] == source for j in jobs), "Multiple legacy source versions")
    for name, digest in source.items():
        path = root / "src/wificount" / name
        verify_hash(path, digest)
        copies[f"legacy/src/wificount/{name}"] = path
    data = load_verified_module(root / "src/wificount/data.py", "_acor_legacy_data")
    metrics = load_verified_module(root / "src/wificount/metrics.py", "_acor_legacy_metrics")
    # The metric implementation used for the new comparison must have exact parity.
    current_metrics = Path(__file__).resolve().parents[1] / "src/wificount/metrics.py"
    verify_hash(current_metrics, source["metrics.py"])
    manifests, records_by_split, audits_by_split = {}, {}, {}
    for split in SPLITS:
        cfg = next(j["config"] for j in jobs if j["config"]["split_seed"] == split)
        mf = (Path(manifest_root) / PurePosixPath(cfg["manifest"]).name if manifest_root
              else legacy_path(root, cfg["manifest"]))
        digest = frozen["jobs"][next(j["id"] for j in jobs if j["config"]["split_seed"] == split)]["manifest_sha256"]
        verify_hash(mf, digest)
        manifests[str(split)] = digest
        records = data.read_manifest(mf, max_occupancy=3)
        records_by_split[split] = records
        item = frozen["audits"][digest]
        audit_path, waveform_path = legacy_path(root, item["path"]), legacy_path(root, item["waveform_csv"])
        verify_hash(audit_path, item["sha256"])
        verify_hash(waveform_path, item["waveform_csv_sha256"])
        audit = read_json(audit_path)
        with waveform_path.open(encoding="utf-8-sig", newline="") as stream:
            waveforms = list(csv.DictReader(stream))
        table = {r["record_id"]: r for r in waveforms}
        require(len(table) == len(waveforms) and set(table) == {r["record_id"] for r in records}, "Audit cohort differs")
        for r in records:
            a = table[r["record_id"]]
            require(a["status"] == "PASS" and a["partition"] == r["partition"] and a["combo_id"] == r["combo_id"],
                    "Frozen waveform audit metadata mismatch")
        audits_by_split[split] = (audit, table)
        copies[f"legacy/manifests/{mf.name}"] = mf
        copies[f"legacy/audit_seed{split}/audit.json"] = audit_path
        copies[f"legacy/audit_seed{split}/waveform_audit.csv"] = waveform_path
    rows = []
    for job in jobs:
        cfg, jobid = job["config"], job["id"]
        item = frozen["jobs"][jobid]
        folder = legacy_path(root, cfg["output"])
        require(fingerprint(cfg) == item["config_sha256"] and read_json(folder / "config.json") == cfg,
                f"Config differs from freeze: {jobid}")
        verify_hash(folder / "provenance.json", item["training_provenance_sha256"])
        verify_hash(folder / "normalization.json", item["normalization_sha256"])
        prov = read_json(folder / "provenance.json")
        require(prov["source_sha256"] == source and prov["manifest_sha256"] == manifests[str(cfg["split_seed"])], "Training provenance differs")
        require(all(prov[k] == v for k, v in item["runtime"].items()), "Training runtime differs")
        require(set(item["checkpoints"]) == {"best"}, "Unexpected diagnostic checkpoint")
        if not metadata_only:
            verify_hash(folder / "best.pt", item["checkpoints"]["best"])
        records = records_by_split[cfg["split_seed"]]
        train_records = [r for r in records if r["partition"] == "train"]
        stats = read_json(folder / "normalization.json")
        audit, waveforms = audits_by_split[cfg["split_seed"]]
        require(stats["preprocessing"] == audit["preprocessing"], "Normalization preprocessing differs")
        require(set(stats["training_record_ids"]) == {r["record_id"] for r in train_records}, "Normalization is not original train-only")
        require(stats["training_file_sha256"] == {r["record_id"]: waveforms[r["record_id"]]["file_sha256"] for r in train_records},
                "Normalization waveform hashes differ from frozen audit")
        require(cfg["layout"] == audit["preprocessing"]["layout"] and cfg["max_length"] == audit["preprocessing"]["max_length"] and
                cfg["model"]["max_occupancy"] == 3 and not cfg["no_aux"], "Legacy input protocol differs")
        history = [json.loads(line) for line in (folder / "history.jsonl").read_text(encoding="utf-8").splitlines() if line]
        require(history and [h["epoch"] for h in history] == list(range(1, len(history) + 1)), "Training history incomplete")
        best = max(history, key=lambda h: (h["validation"]["macro_exact_match_by_complete_composition"],
                   -h["validation"]["positive_count_mae"], -h["epoch"]))
        summary = read_json(folder / "training_summary.json")
        require(summary["best_epoch"] == best["epoch"] and summary["completed_epochs"] == len(history), "Checkpoint selection/complete marker differs")
        require(summary["training_records"] == len(train_records), "Training budget record count differs")
        for name in ("config.json", "provenance.json", "normalization.json", "training_summary.json", "history.jsonl", "validation_best.json", "validation_best.csv"):
            require((folder / name).is_file(), f"Missing training artifact: {folder / name}")
            copies[f"runs/{jobid}/{name}"] = folder / name
        for partition in PARTITIONS:
            ev = folder / f"evaluation_{partition}"
            marker = read_json(ev / "evaluation_complete.json")
            require(set(marker) == {"metrics.json", "predictions.csv", "evaluation_provenance.json"}, "Incomplete evaluation marker")
            for name, digest in marker.items():
                verify_hash(ev / name, digest)
            ep = read_json(ev / "evaluation_provenance.json")
            require(ep["config"] == cfg and ep["partition"] == partition and ep["epoch"] == best["epoch"] and
                    ep["checkpoint_sha256"] == item["checkpoints"]["best"], "Evaluation differs from selected frozen checkpoint")
            require(ep["training_provenance"] == prov, "Embedded training provenance differs")
            evprov = ep["evaluation_provenance"]
            require(evprov["source_sha256"] == source and evprov["manifest_sha256"] == item["manifest_sha256"] and
                    all(evprov[k] == v for k, v in item["runtime"].items()), "Evaluation source/runtime/manifest differs")
            predictions = prediction_rows(ev / "predictions.csv")
            count = validate_predictions(predictions, records, cfg, partition)
            computed = metrics.evaluate_counts([r["truth"] for r in predictions], [r["pred"] for r in predictions],
                        metadata=predictions, max_occupancy=3, train_context_records=train_records)
            saved = read_json(ev / "metrics.json")
            same_metrics(computed, saved, f"{jobid}:{partition}")
            relative = f"runs/{jobid}/evaluation_{partition}"
            for name in (*marker, "evaluation_complete.json"):
                copies[f"{relative}/{name}"] = ev / name
            rows.append({"method": cfg["method"], "split_seed": cfg["split_seed"], "model_seed": cfg["model_seed"],
                         "partition": partition, "checkpoint": "best", "epoch": best["epoch"], "job": jobid,
                         "source_output": cfg["output"], "artifact_dir": relative, "checkpoint_sha256": item["checkpoints"]["best"],
                         "metrics": saved, "prediction_rows": count})
    artifact_hashes = {dest: file_hash(path) for dest, path in sorted(copies.items())}
    result = {"schema": 1, "status": "METADATA_ONLY_NOT_REUSABLE" if metadata_only else "BASELINES_VERIFIED",
              "original_root": str(root), "original_freeze_sha256": FREEZE_SHA256,
              "selection_rule": SELECTION_RULE, "methods": list(METHODS), "jobs": len(jobs), "evaluation_rows": len(rows),
              "manifest_sha256": manifests, "source_sha256": source,
              "checkpoint_bytes_verified": not metadata_only, "current_waveform_bytes_rehashed": False,
              "scope": "Reuse of immutable historical predictions. Current waveform bytes are checked by the new training preflight, not by this prediction collector.",
              "test_disclosure": "Historical test results were previously inspected; this comparison is not an untouched independent test.",
              "artifact_sha256": artifact_hashes, "rows": rows}
    # No changes occur until the full audit succeeds. Existing snapshots are immutable.
    blob = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    summary_path = output / "summary.json"
    if summary_path.exists():
        require(summary_path.read_text(encoding="utf-8") == blob, "Existing baseline snapshot differs; preserve it and use a new output directory")
    for dest, source_path in copies.items():
        target = output / dest
        if target.exists():
            verify_hash(target, artifact_hashes[dest])
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source_path, target)
            verify_hash(target, artifact_hashes[dest])
    if not summary_path.exists():
        summary_path.write_text(blob, encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original-root", type=Path, default=Path.home() / "wificount")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest-root", type=Path, help="Location of byte-identical original formal manifests")
    parser.add_argument("--metadata-only", action="store_true", help="Local archive diagnosis only: never produces reusable status; does not verify checkpoint bytes")
    args = parser.parse_args()
    result = collect(args.original_root, args.output, manifest_root=args.manifest_root, metadata_only=args.metadata_only)
    print(json.dumps({k: result[k] for k in ("status", "jobs", "evaluation_rows", "checkpoint_bytes_verified")}))


if __name__ == "__main__":
    main()
