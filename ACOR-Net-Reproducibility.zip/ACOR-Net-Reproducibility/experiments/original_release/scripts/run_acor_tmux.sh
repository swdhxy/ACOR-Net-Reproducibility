#!/usr/bin/env bash
# Immutable final method; physical GPU 5 is exposed as process-local cuda:0.
set -euo pipefail
echo 'ACOR_LAUNCHER_REVISION=20261030-final'
STAGE="${1:-check}"
GPU="${2:-5}"
[[ "$STAGE" =~ ^(check|all|train|evaluate|profile|report|pack)$ ]] || {
    echo 'Usage: bash scripts/run_acor_tmux.sh check|all|train|evaluate|profile|report|pack [GPU_INDEX=5]' >&2
    exit 2
}
[[ "$GPU" =~ ^[0-9]+$ ]] || { echo 'GPU_INDEX must be a physical integer nvidia-smi index.' >&2; exit 2; }
HELPER_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="$(cd -- "$HELPER_DIR/.." && pwd)"
REFERENCE_PROJECT="${ACOR_REFERENCE_PROJECT:-$HOME/wificount}"
DATA_ROOT="${ACOR_DATA_ROOT:-$REFERENCE_PROJECT/data/wimans/wifi_csi/amp}"
RUN_ROOT="${ACOR_RUN_ROOT:-$PROJECT/runs/final_acor}"
export ACOR_EXPECTED_CONDA_PREFIX="$HOME/.conda/envs/wifi-count"
PYTHON_BIN="$ACOR_EXPECTED_CONDA_PREFIX/bin/python"
[[ -x "$PYTHON_BIN" ]] || { echo "Required Python is missing: $PYTHON_BIN" >&2; exit 2; }
for tool in flock tee date; do
    command -v "$tool" >/dev/null || { echo "Missing required command: $tool" >&2; exit 2; }
done
export PATH="$ACOR_EXPECTED_CONDA_PREFIX/bin:$PATH"
unset -f python python3 pip pip3 2>/dev/null || true
unset PYTHONHOME BASH_ENV
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 PYTHONPATH="$PROJECT/src"
hash -r
cd "$PROJECT"
mkdir -p "$PROJECT/runs" "$PROJECT/logs" "$RUN_ROOT"
exec 9>"$RUN_ROOT/.acor_experiment.lock"
flock -n 9 || { echo "Another ACOR launcher holds $RUN_ROOT/.acor_experiment.lock" >&2; exit 3; }
stamp="$(date -u +%Y%m%d_%H%M%SUTC)-$$"
CONSOLE_LOG="$RUN_ROOT/console-$STAGE-$stamp.log"

runner() {
    "$PYTHON_BIN" "$HELPER_DIR/run_final_acor.py" "$@" --run-root "$RUN_ROOT"
}

finish() {
    local rc=$?
    trap - EXIT
    if [[ "$rc" -ne 0 ]]; then
        echo "ACOR_STAGE_FAILED stage=$STAGE exit=$rc; completed runs remain resumable." >&2
        if [[ "$STAGE" != check && "$STAGE" != pack && -f "$RUN_ROOT/plan.json" ]]; then
            echo 'Packing partial evidence; this does not turn failure into success.' >&2
            runner pack >>"$CONSOLE_LOG" 2>&1 || echo 'Partial pack also failed; preserve runs/ and logs/.' >&2
        fi
    fi
    exit "$rc"
}
trap finish EXIT

# Reporting and packaging need no GPU, raw CSI access, or tmux session.
if [[ "$STAGE" == pack || "$STAGE" == report ]]; then
    "$PYTHON_BIN" -c 'import sys; from pathlib import Path; import os; assert Path(sys.prefix).resolve() == Path(os.environ["ACOR_EXPECTED_CONDA_PREFIX"]).resolve(), sys.prefix'
    runner "$STAGE" 2>&1 | tee "$CONSOLE_LOG"
    echo "ACOR_STAGE_COMPLETE=$STAGE"
    exit 0
fi

if [[ "$STAGE" != check && -z "${TMUX:-}" ]]; then
    echo "Enter tmux first: tmux new -s acor-final; then bash scripts/run_acor_tmux.sh $STAGE $GPU" >&2
    exit 2
fi
for tool in nvidia-smi tmux; do
    command -v "$tool" >/dev/null || { echo "Missing required command: $tool" >&2; exit 2; }
done
if [[ -n "${CONDA_EXE:-}" && -x "$CONDA_EXE" ]]; then
    CONDA_BASE_DIR="$("$CONDA_EXE" info --base)"
elif command -v conda >/dev/null; then
    CONDA_BASE_DIR="$(conda info --base)"
else
    echo 'Conda is unavailable; source your installed conda.sh before running this launcher.' >&2
    exit 2
fi
[[ -f "$CONDA_BASE_DIR/etc/profile.d/conda.sh" ]] || { echo 'Cannot find conda.sh.' >&2; exit 2; }
source "$CONDA_BASE_DIR/etc/profile.d/conda.sh"
conda activate "$ACOR_EXPECTED_CONDA_PREFIX"
export PATH="$ACOR_EXPECTED_CONDA_PREFIX/bin:$PATH"
unset -f python python3 pip pip3 2>/dev/null || true
unset PYTHONHOME BASH_ENV
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 PYTHONPATH="$PROJECT/src"
hash -r
[[ "$(command -v python)" == "$PYTHON_BIN" ]] || { echo 'python does not resolve to the required environment.' >&2; exit 2; }
GPU_UUID="$(nvidia-smi --id="$GPU" --query-gpu=uuid --format=csv,noheader,nounits)"
GPU_UUID="${GPU_UUID//[[:space:]]/}"
[[ "$GPU_UUID" =~ ^GPU-[0-9a-fA-F-]+$ ]] || { echo "Invalid GPU UUID for physical GPU $GPU: $GPU_UUID" >&2; exit 2; }
export ACOR_GPU_INDEX="$GPU" ACOR_GPU_UUID="$GPU_UUID" CUDA_VISIBLE_DEVICES="$GPU_UUID"
mkdir -p "$RUN_ROOT/environment"
ENV_LOG="$RUN_ROOT/environment/environment-$STAGE-$stamp.log"
PREFLIGHT="$RUN_ROOT/environment/preflight-$STAGE-$stamp.json"
# A subshell and pipefail make any failed check stop before prepare/train.
(
    set -euo pipefail
    date -u
    hostname
    tmux -V
    conda --version
    conda info --envs
    command -v python
    "$PYTHON_BIN" --version
    "$PYTHON_BIN" -m pip --version
    printf 'SELECTED_PHYSICAL_GPU=%s\nCUDA_VISIBLE_DEVICES=%s\nREFERENCE_PROJECT=%s\nRUN_ROOT=%s\n' "$GPU" "$CUDA_VISIBLE_DEVICES" "$REFERENCE_PROJECT" "$RUN_ROOT"
    nvidia-smi --id="$GPU"
    df -h "$PROJECT" "$DATA_ROOT"
    conda list --prefix "$ACOR_EXPECTED_CONDA_PREFIX"
    "$PYTHON_BIN" -m pip freeze
    "$PYTHON_BIN" -m pip check
    "$PYTHON_BIN" "$HELPER_DIR/acor_preflight.py" --project "$PROJECT" --data-root "$DATA_ROOT" --reference-project "$REFERENCE_PROJECT" --output "$PREFLIGHT"
) 2>&1 | tee "$ENV_LOG"
if [[ "$STAGE" == check ]]; then
    echo 'ACOR_ENV_CHECK_COMPLETE (no training started)'
    exit 0
fi
if [[ "$STAGE" == all || "$STAGE" == train ]]; then
    runner prepare --data-root "$DATA_ROOT" --device cuda 2>&1 | tee -a "$CONSOLE_LOG"
    "$PYTHON_BIN" "$HELPER_DIR/collect_acor_baselines.py" --original-root "$REFERENCE_PROJECT" --output "$RUN_ROOT/baseline_reference" 2>&1 | tee -a "$CONSOLE_LOG"
    runner train 2>&1 | tee -a "$CONSOLE_LOG"
    runner freeze 2>&1 | tee -a "$CONSOLE_LOG"
fi
if [[ "$STAGE" == all || "$STAGE" == evaluate ]]; then
    # Freeze verifies all nine training completions before any test inference.
    if [[ "$STAGE" == evaluate ]]; then
        "$PYTHON_BIN" "$HELPER_DIR/collect_acor_baselines.py" --original-root "$REFERENCE_PROJECT" --output "$RUN_ROOT/baseline_reference" 2>&1 | tee -a "$CONSOLE_LOG"
        runner freeze 2>&1 | tee -a "$CONSOLE_LOG"
    fi
    runner evaluate 2>&1 | tee -a "$CONSOLE_LOG"
fi
if [[ "$STAGE" == all || "$STAGE" == evaluate || "$STAGE" == profile ]]; then
    "$PYTHON_BIN" "$HELPER_DIR/profile_acor.py" --run-root "$RUN_ROOT" --device cuda 2>&1 | tee -a "$CONSOLE_LOG"
    runner report 2>&1 | tee -a "$CONSOLE_LOG"
fi
runner pack 2>&1 | tee -a "$CONSOLE_LOG"
echo "ACOR_STAGE_COMPLETE=$STAGE"
