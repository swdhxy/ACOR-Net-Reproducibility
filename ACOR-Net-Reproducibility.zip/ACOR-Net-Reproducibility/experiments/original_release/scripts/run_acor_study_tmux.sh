#!/usr/bin/env bash
# Search, selected models, and component ablations share one frozen protocol.
set -euo pipefail
echo 'ACOR_STUDY_LAUNCHER_REVISION=20261102-reduced'
STAGE="${1:-check}"
GPU="${2:-5}"
[[ "$STAGE" =~ ^(check|all|prepare|search|select|train|evaluate|sensitivity|profile|report|pack|status)$ ]] || {
    echo 'Usage: bash scripts/run_acor_study_tmux.sh check|all|prepare|search|select|train|evaluate|sensitivity|profile|report|pack|status [GPU_INDEX=5]' >&2
    exit 2
}
[[ "$GPU" =~ ^[0-9]+$ ]] || { echo 'GPU_INDEX must be a physical nvidia-smi integer index.' >&2; exit 2; }
HELPER_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="$(cd -- "$HELPER_DIR/.." && pwd)"
REFERENCE_PROJECT="${ACOR_REFERENCE_PROJECT:-$HOME/wificount}"
DATA_ROOT="${ACOR_DATA_ROOT:-$REFERENCE_PROJECT/data/wimans/wifi_csi/amp}"
RUN_ROOT="${ACOR_RUN_ROOT:-$PROJECT/runs/acor_reduced}"
BASELINE_MODE="${ACOR_BASELINE_MODE:-retrain}"
[[ "$BASELINE_MODE" == retrain ]] || {
    echo 'This protocol retrains all baselines with model seeds 2026 2027 2028.' >&2; exit 2;
}
MODEL_SEEDS=()
ABLATION_SPLITS=()
if [[ "$STAGE" =~ ^(all|prepare|search|train)$ ]]; then
    [[ -n "${ACOR_MODEL_SEEDS:-}" ]] || {
        echo "Explicit ACOR_MODEL_SEEDS='2026 2027 2028' required for every candidate, method and ablation." >&2
        exit 2
    }
    read -r -a MODEL_SEEDS <<< "$ACOR_MODEL_SEEDS"
    [[ "${MODEL_SEEDS[*]}" == '2026 2027 2028' ]] || {
        echo 'ACOR_MODEL_SEEDS must be exactly 2026 2027 2028.' >&2; exit 2;
    }
    read -r -a ABLATION_SPLITS <<< "${ACOR_ABLATION_SPLITS:-2026 2027 2028}"
    [[ "${ABLATION_SPLITS[*]}" == '2026' || "${ABLATION_SPLITS[*]}" == '2026 2027 2028' ]] || {
        echo 'ACOR_ABLATION_SPLITS must be 2026 or 2026 2027 2028.' >&2; exit 2;
    }
fi
export ACOR_EXPECTED_CONDA_PREFIX="$HOME/.conda/envs/wifi-count"
PYTHON_BIN="$ACOR_EXPECTED_CONDA_PREFIX/bin/python"
[[ -x "$PYTHON_BIN" ]] || { echo "Required Python is missing: $PYTHON_BIN" >&2; exit 2; }
for tool in flock tee date; do
    command -v "$tool" >/dev/null || { echo "Missing required command: $tool" >&2; exit 2; }
done
export PATH="$ACOR_EXPECTED_CONDA_PREFIX/bin:$PATH"
unset -f python python3 pip pip3 2>/dev/null || true
unset PYTHONHOME BASH_ENV
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 PYTHONPATH="$PROJECT/src"
hash -r
cd "$PROJECT"
mkdir -p "$PROJECT/runs" "$PROJECT/logs" "$RUN_ROOT"
exec 9>"$RUN_ROOT/.acor_study.lock"
flock -n 9 || { echo "Another launcher holds $RUN_ROOT/.acor_study.lock" >&2; exit 3; }
stamp="$(date -u +%Y%m%d_%H%M%SUTC)-$$"
CONSOLE_LOG="$RUN_ROOT/console-$STAGE-$stamp.log"

runner() {
    "$PYTHON_BIN" "$HELPER_DIR/run_acor_study.py" "$@" --run-root "$RUN_ROOT"
}

finish() {
    local rc=$?
    trap - EXIT
    if [[ "$rc" -ne 0 ]]; then
        echo "ACOR_STUDY_STAGE_FAILED stage=$STAGE exit=$rc; preserve this run directory for resume." >&2
        if [[ "$STAGE" != check && "$STAGE" != pack ]]; then
            echo 'Packing partial evidence; this does not turn failure into success.' >&2
            runner pack >>"$CONSOLE_LOG" 2>&1 || echo 'Partial pack also failed; preserve runs/ and logs/.' >&2
        fi
    fi
    exit "$rc"
}
trap finish EXIT

# CPU-side artifact operations use the pinned interpreter; no CUDA or tmux gate.
if [[ "$STAGE" == pack || "$STAGE" == report || "$STAGE" == status || "$STAGE" == select ]]; then
    "$PYTHON_BIN" -c 'import sys; from pathlib import Path; import os; assert Path(sys.prefix).resolve() == Path(os.environ["ACOR_EXPECTED_CONDA_PREFIX"]).resolve(), sys.prefix'
    runner "$STAGE" 2>&1 | tee "$CONSOLE_LOG"
    echo "ACOR_STUDY_STAGE_COMPLETE=$STAGE"
    exit 0
fi

if [[ "$STAGE" != check && -z "${TMUX:-}" ]]; then
    echo "Enter tmux first: tmux new -s acor-reduced; then bash scripts/run_acor_study_tmux.sh $STAGE $GPU" >&2
    exit 2
fi
for tool in nvidia-smi tmux; do
    command -v "$tool" >/dev/null || { echo "Missing required command: $tool" >&2; exit 2; }
done
if [[ -n "${CONDA_EXE:-}" && -x "$CONDA_EXE" ]]; then
    CONDA_BASE_DIR="$("$CONDA_EXE" info --base)"
elif command -v conda >/dev/null; then
    CONDA_BASE_DIR="$(conda info --base)"
else
    echo 'Conda is unavailable; source your installed conda.sh before this launcher.' >&2; exit 2
fi
[[ -f "$CONDA_BASE_DIR/etc/profile.d/conda.sh" ]] || { echo 'Cannot find conda.sh.' >&2; exit 2; }
source "$CONDA_BASE_DIR/etc/profile.d/conda.sh"
conda activate "$ACOR_EXPECTED_CONDA_PREFIX"
export PATH="$ACOR_EXPECTED_CONDA_PREFIX/bin:$PATH"
unset -f python python3 pip pip3 2>/dev/null || true
unset PYTHONHOME BASH_ENV
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 PYTHONPATH="$PROJECT/src"
hash -r
[[ "$(command -v python)" == "$PYTHON_BIN" ]] || { echo 'python resolves outside the required environment.' >&2; exit 2; }
GPU_UUID="$(nvidia-smi --id="$GPU" --query-gpu=uuid --format=csv,noheader,nounits)"
GPU_UUID="${GPU_UUID//[[:space:]]/}"
[[ "$GPU_UUID" =~ ^GPU-[0-9a-fA-F-]+$ ]] || { echo "Invalid UUID for GPU $GPU: $GPU_UUID" >&2; exit 2; }
export ACOR_GPU_INDEX="$GPU" ACOR_GPU_UUID="$GPU_UUID" CUDA_VISIBLE_DEVICES="$GPU_UUID"
mkdir -p "$RUN_ROOT/environment"
ENV_LOG="$RUN_ROOT/environment/environment-$STAGE-$stamp.log"
PREFLIGHT="$RUN_ROOT/environment/preflight-$STAGE-$stamp.json"
(
    set -euo pipefail
    date -u
    hostname
    tmux -V
    conda --version
    conda info --envs
    command -v python
    "$PYTHON_BIN" --version
    "$PYTHON_BIN" -m pip --version
    printf 'SELECTED_PHYSICAL_GPU=%s\nCUDA_VISIBLE_DEVICES=%s\nREFERENCE_PROJECT=%s\nRUN_ROOT=%s\nBASELINE_MODE=%s\nMODEL_SEEDS=%s\nABLATION_SPLITS=%s\n' "$GPU" "$CUDA_VISIBLE_DEVICES" "$REFERENCE_PROJECT" "$RUN_ROOT" "$BASELINE_MODE" "${MODEL_SEEDS[*]}" "${ABLATION_SPLITS[*]}"
    nvidia-smi --id="$GPU"
    df -h "$PROJECT" "$DATA_ROOT"
    conda list --prefix "$ACOR_EXPECTED_CONDA_PREFIX"
    "$PYTHON_BIN" -m pip freeze
    "$PYTHON_BIN" -m pip check
    "$PYTHON_BIN" "$HELPER_DIR/acor_study_preflight.py" --project "$PROJECT" --data-root "$DATA_ROOT" --reference-project "$REFERENCE_PROJECT" --baseline-mode "$BASELINE_MODE" --output "$PREFLIGHT"
) 2>&1 | tee "$ENV_LOG"
if [[ "$STAGE" == check ]]; then
    echo 'ACOR_STUDY_ENV_CHECK_COMPLETE (no training started)'
    exit 0
fi
if [[ "$STAGE" =~ ^(all|prepare|search|train)$ ]]; then
    runner prepare --data-root "$DATA_ROOT" --device cuda --model-seeds "${MODEL_SEEDS[@]}" --baseline-mode "$BASELINE_MODE" --ablation-splits "${ABLATION_SPLITS[@]}" 2>&1 | tee -a "$CONSOLE_LOG"
fi
if [[ "$STAGE" =~ ^(all|search|train)$ ]]; then
    runner search 2>&1 | tee -a "$CONSOLE_LOG"
    runner select 2>&1 | tee -a "$CONSOLE_LOG"
fi
if [[ "$STAGE" == all || "$STAGE" == train ]]; then
    runner train 2>&1 | tee -a "$CONSOLE_LOG"
    runner freeze 2>&1 | tee -a "$CONSOLE_LOG"
fi
if [[ "$STAGE" == all || "$STAGE" == evaluate ]]; then
    # No held-out prediction until all selected main and ablation fits are frozen.
    if [[ "$STAGE" == evaluate ]]; then
        runner freeze 2>&1 | tee -a "$CONSOLE_LOG"
    fi
    runner evaluate 2>&1 | tee -a "$CONSOLE_LOG"
fi
if [[ "$STAGE" == all || "$STAGE" == evaluate || "$STAGE" == sensitivity ]]; then
    "$PYTHON_BIN" "$HELPER_DIR/sensitivity_acor.py" --run-root "$RUN_ROOT" --device cuda 2>&1 | tee -a "$CONSOLE_LOG"
fi
if [[ "$STAGE" == all || "$STAGE" == evaluate || "$STAGE" == profile ]]; then
    "$PYTHON_BIN" "$HELPER_DIR/profile_acor.py" --run-root "$RUN_ROOT" --device cuda 2>&1 | tee -a "$CONSOLE_LOG"
fi
if [[ "$STAGE" == all || "$STAGE" == evaluate || "$STAGE" == profile || "$STAGE" == sensitivity ]]; then
    runner report 2>&1 | tee -a "$CONSOLE_LOG"
fi
runner pack 2>&1 | tee -a "$CONSOLE_LOG"
echo "ACOR_STUDY_STAGE_COMPLETE=$STAGE"
