#!/usr/bin/env python3
"""Fixed-checkpoint occupancy-decoder sensitivity; never fit or select a model.

The only changed inference setting is v4.lambda_occ=0. All checkpoints, learned
occupancy supervision, preprocessing statistics, records, and seeds stay fixed.
This is an inference sensitivity analysis, not an independently trained ablation.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import torch

from wificount.config import file_hash, write_json
from wificount.data import CSIDataset, read_manifest
from wificount.engine import (build_model, device_for, load_predictions, predictions,
                             prepare_data, provenance, save_predictions, seed_all,
                             verify_run_provenance)
from wificount.metrics import evaluate_counts
from wificount.objectives import enumerate_counts
from wificount.reporting import METRICS, read_json, verify_evaluation

PARTITIONS = ("test_unseen", "test_seen", "test_aux")
SCOPE = ("Fixed learned weights, lambda_occ=0 at decoding only. Not a retrained "
         "ablation or checkpoint selection; no claim of independently trained module benefit.")


def decoder_config(original):
    if (original.get("method") != "ours_v4" or original.get("development_protocol")
            or original.get("v4", {}).get("joint_weight") != 0):
        raise ValueError("Sensitivity requires a formal ACOR-Net joint0 configuration")
    changed = copy.deepcopy(original)
    changed["v4"]["lambda_occ"] = 0.0
    return changed


def main_jobs(plan):
    jobs = [j for j in plan["jobs"] if j.get("role") == "main" and j.get("method") == "ours_v4"]
    expected = {(s, m) for s in (2026, 2027, 2028) for m in plan["model_seeds"]}
    observed = {(j["config"]["split_seed"], j["config"]["model_seed"]) for j in jobs}
    if len(jobs) != 9 or len(expected) != 9 or observed != expected:
        raise ValueError("Sensitivity requires all nine formal main ACOR checkpoints")
    for job in jobs:
        decoder_config(job["config"])
    return sorted(jobs, key=lambda j: (j["config"]["split_seed"], j["config"]["model_seed"]))


def destination_for(run_root, job, partition):
    root = (Path(run_root).resolve() / "sensitivity").resolve()
    destination = (root / job["id"] / partition).resolve()
    if not destination.is_relative_to(root) or destination == root or Path(job["id"]).is_absolute():
        raise ValueError("Unsafe job path in sensitivity plan")
    if partition not in PARTITIONS:
        raise ValueError("Unexpected sensitivity partition")
    return destination


def verify_result(destination, checkpoint, job, partition, freeze_hash, runtime):
    original = job["config"]
    changed = decoder_config(original)
    verify_evaluation(destination, checkpoint, partition=partition, cfg=original, runtime=runtime)
    meta = read_json(Path(destination) / "evaluation_provenance.json")
    if (meta.get("kind") != "fixed_weight_decoder_sensitivity"
            or meta.get("job_id") != job["id"] or meta.get("freeze_sha256") != freeze_hash
            or meta.get("original_config") != original or meta.get("config") != changed
            or meta.get("override") != {"v4.lambda_occ": 0.0}
            or meta.get("script_sha256") != file_hash(__file__)
            or meta.get("training_performed") is not False
            or meta.get("checkpoint_selection_performed") is not False):
        raise ValueError("Sensitivity identity, fixed decoder override, or source changed")
    verify_run_provenance(runtime, meta["training_provenance"], "Sensitivity training provenance")
    verify_run_provenance(runtime, meta["evaluation_provenance"], "Sensitivity evaluation provenance")
    records = read_manifest(original["manifest"], max_occupancy=original["model"]["max_occupancy"])
    cohort = {r["record_id"]: r for r in records if r["partition"] == partition}
    train_records = [r for r in records if r["partition"] == "train"]
    rows = load_predictions(Path(destination) / "predictions.csv")
    rebuilt = evaluate_counts([r["truth"] for r in rows], [r["pred"] for r in rows],
        [cohort[r["record_id"]] for r in rows], max_occupancy=original["model"]["max_occupancy"],
        train_context_records=train_records)
    if rebuilt != read_json(Path(destination) / "metrics.json"):
        raise ValueError("Sensitivity metrics do not reproduce from predictions")
    return rebuilt


def preserve_partial(destination):
    destination = Path(destination)
    if destination.exists() and not (destination / "evaluation_complete.json").exists():
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%fUTC")
        moved = destination.with_name(destination.name + ".incomplete-" + stamp)
        if moved.exists():
            raise FileExistsError(moved)
        destination.rename(moved)
        print(f"SENSITIVITY_PARTIAL_PRESERVED {moved}", flush=True)
        return moved
    return None


def evaluate_one(run_root, job, partition, frozen_job, freeze_hash, device="cuda"):
    original = job["config"]
    changed = decoder_config(original)
    checkpoint = Path(original["output"]) / "best.pt"
    if file_hash(checkpoint) != frozen_job["files"]["best.pt"]:
        raise ValueError("Sensitivity checkpoint differs from frozen best")
    # Verify the paired original evaluation before producing a changed prediction.
    baseline_dir = Path(original["output"]) / f"evaluation_{partition}"
    verify_evaluation(baseline_dir, checkpoint, partition=partition, cfg=original,
                      runtime=frozen_job["runtime"])
    destination = destination_for(run_root, job, partition)
    if (destination / "evaluation_complete.json").exists():
        return verify_result(destination, checkpoint, job, partition, freeze_hash, frozen_job["runtime"])
    preserve_partial(destination)

    ckpt = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if ckpt["config"] != original:
        raise ValueError("Sensitivity checkpoint config differs from the selected main job")
    verify_run_provenance(ckpt["provenance"], frozen_job["runtime"], "Frozen sensitivity checkpoint")
    current = provenance(original)
    verify_run_provenance(ckpt["provenance"], current, "Current sensitivity source/runtime")
    seed_all(original["model_seed"], original["deterministic"], original["threads"])
    dev = device_for(device)
    records, train_records, _, _, store, stats = prepare_data(original, stats=ckpt["stats"])
    chosen = [r for r in records if r["partition"] == partition]
    if not chosen:
        raise ValueError("Empty sensitivity cohort")
    dataset = CSIDataset(chosen, store, stats, expected_train_records=train_records)
    model = build_model(original, initialize_pretrained=False).to(dev)
    model.load_state_dict(ckpt["model"], strict=True)
    candidates = enumerate_counts(K=9, M=original["model"]["max_occupancy"]).to(dev)
    metrics, rows = predictions(model, dataset, changed, dev, candidates, train_records)
    destination.mkdir(parents=True, exist_ok=False)
    write_json(destination / "metrics.json", metrics)
    save_predictions(destination / "predictions.csv", rows)
    meta = {"kind": "fixed_weight_decoder_sensitivity", "job_id": job["id"],
        "checkpoint_sha256": frozen_job["files"]["best.pt"], "epoch": ckpt["epoch"] + 1,
        "partition": partition, "config": changed, "original_config": original,
        "override": {"v4.lambda_occ": 0.0}, "freeze_sha256": freeze_hash,
        "training_provenance": ckpt["provenance"], "evaluation_provenance": current,
        "script_sha256": file_hash(__file__), "scope": SCOPE,
        "training_performed": False, "checkpoint_selection_performed": False,
        "labels_or_identity_used_for_inference": False}
    write_json(destination / "evaluation_provenance.json", meta)
    write_json(destination / "evaluation_complete.json", {
        name: file_hash(destination / name) for name in
        ("metrics.json", "predictions.csv", "evaluation_provenance.json")})
    del model, ckpt, dataset
    return verify_result(destination, checkpoint, job, partition, freeze_hash, frozen_job["runtime"])


def run(run_root, device="cuda"):
    from run_acor_study import verify_freeze
    run_root = Path(run_root).resolve()
    plan, frozen = verify_freeze(run_root, verify_files=True)
    jobs = main_jobs(plan)
    freeze_hash = file_hash(run_root / "freeze.json")
    rows = []
    artifacts = {}
    for job in jobs:
        for partition in PARTITIONS:
            print(f"SENSITIVITY {len(rows)+1}/27 {job['id']} {partition}", flush=True)
            metrics = evaluate_one(run_root, job, partition, frozen["jobs"][job["id"]], freeze_hash, device)
            original_metrics = read_json(Path(job["config"]["output"]) / f"evaluation_{partition}/metrics.json")
            destination = destination_for(run_root, job, partition)
            for name in ("evaluation_complete.json", "evaluation_provenance.json", "metrics.json", "predictions.csv"):
                path = destination / name
                artifacts[path.relative_to(run_root).as_posix()] = file_hash(path)
            rows.append({"job": job["id"], "split_seed": job["config"]["split_seed"],
                "model_seed": job["config"]["model_seed"], "partition": partition,
                "artifact_dir": destination.relative_to(run_root).as_posix(),
                "metrics": {key: metrics[key] for key in METRICS},
                "full_metrics": {key: original_metrics[key] for key in METRICS},
                "changed_minus_full": {key: metrics[key] - original_metrics[key]
                    if metrics[key] is not None and original_metrics[key] is not None else None for key in METRICS}})
    result = {"status": "SENSITIVITY_COMPLETE", "evaluations": len(rows), "jobs": len(jobs),
        "freeze_sha256": freeze_hash, "script_sha256": file_hash(__file__),
        "scope": SCOPE, "training_performed": False, "checkpoint_selection_performed": False,
        "override": {"v4.lambda_occ": 0.0}, "rows": rows, "artifact_sha256": artifacts}
    write_json(run_root / "sensitivity/summary.json", result)
    print("SENSITIVITY_COMPLETE", run_root / "sensitivity/summary.json", flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--device", default="cuda", choices=("cuda", "cpu", "auto"))
    args = parser.parse_args()
    run(args.run_root, args.device)


if __name__ == "__main__":
    main()
