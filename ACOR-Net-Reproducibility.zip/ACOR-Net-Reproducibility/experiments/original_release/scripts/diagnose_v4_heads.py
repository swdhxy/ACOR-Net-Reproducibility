"""Read-only V4 best-checkpoint diagnostic; imports the unchanged V4 project.

Fixed decoder perturbations are explanatory, never a checkpoint/recipe selector.
No formal holdout inference, checkpoint writes, or CSI exports.
"""
import argparse
import copy
import datetime as dt
import hashlib
import json
from pathlib import Path
import sys
import tarfile


def decoder_settings(cfg):
    """Fixed explanatory decoder grid; only the active V4 field is changed."""
    if cfg.get('method') != 'ours_v4':
        raise ValueError('V4 head diagnostic accepts ours_v4 only')
    saved = copy.deepcopy(cfg)
    saved.setdefault('v4', {}).setdefault('lambda_occ', .25)
    settings = [('saved_decoder', saved)]
    for occupancy_weight in (0., .1, .25, .5):
        changed = copy.deepcopy(saved)
        changed['v4']['lambda_occ'] = occupancy_weight
        settings.append((f'occ_{occupancy_weight:g}', changed))
    return settings


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project', required=True, type=Path)
    p.add_argument('--plan', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--device', default='cuda')
    p.add_argument('--train-limit', type=int, default=128)
    p.add_argument('--variants', nargs='+', default=['v4_controlled_erm', 'v4_controlled_within',
        'v4_controlled_cross', 'v4_controlled_any'])
    args = p.parse_args()
    if args.train_limit < 0:
        p.error('train-limit must be nonnegative')
    project, destination = args.project.resolve(), args.output.resolve()
    archive = destination.with_name(destination.name+'.tar.gz')
    if destination.exists() or archive.exists() or archive.with_name(archive.name+'.sha256').exists():
        raise FileExistsError('Use a new diagnostic output/archive name')
    if destination.is_relative_to(project):
        raise ValueError('Write the diagnostic outside the read-only source project')
    # Importing the frozen project must not create/update its bytecode cache.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(project/'src'))
    import numpy as np
    import torch
    from torch.utils.data import DataLoader
    from wificount import engine
    from wificount.config import file_hash, fingerprint, write_json
    from wificount.data import read_manifest, CSIDataset, collate_records, WaveformStore, validate_normalization
    from wificount.development import verify_development_plan
    from wificount.metrics import evaluate_counts
    from wificount.objectives import enumerate_counts
    if not Path(engine.__file__).resolve().is_relative_to(project/'src'):
        raise RuntimeError('Wrong source imported')
    plan = verify_development_plan(args.plan)
    available = {j['variant'] for j in plan['jobs']}
    if set(args.variants) - available:
        raise ValueError('Requested variants missing from original V4 plan')
    jobs = [j for j in plan['jobs'] if j['variant'] in args.variants]
    if not jobs or any(j['config']['method'] != 'ours_v4' for j in jobs):
        raise ValueError('V4 head diagnostic requires nonempty ours_v4 jobs only')
    keys = [(j['variant'], j['config']['model_seed']) for j in jobs]
    if len(keys) != len(set(keys)):
        raise ValueError('Duplicate variant/seed would overwrite diagnostic evidence')
    records = read_manifest(plan['manifest'])
    if any(r.get('source_partition') != 'train' for r in records):
        raise ValueError('Diagnostic requires the original-train-only development split')
    training = [r for r in records if r['partition'] == 'train']
    device = engine.device_for(args.device)
    candidates = enumerate_counts(9, 3).to(device)
    cache, reports = {}, []
    destination.mkdir(parents=True)
    for job in jobs:
        cfg, root = job['config'], Path(job['config']['output'])
        saved_cfg = json.loads((root/'config.json').read_text(encoding='utf-8'))
        if cfg != saved_cfg:
            raise ValueError('Saved config differs from frozen plan')
        complete = json.loads((root/'development_best_complete.json').read_text(encoding='utf-8'))
        for name, digest in complete['sha256'].items():
            if name not in {'best.pt', 'validation_best.json', 'validation_best.csv',
                            'validation_seen_best.json', 'validation_seen_best.csv'}:
                raise ValueError('Unexpected artifact in V4 completion marker')
            if file_hash(root/name) != digest:
                raise ValueError(f'Changed checkpoint/prediction: {job["id"]}/{name}')
        if set(complete['sha256']) != {'best.pt', 'validation_best.json', 'validation_best.csv',
                                      'validation_seen_best.json', 'validation_seen_best.csv'}:
            raise ValueError('Incomplete artifact hashes')
        saved_prov = json.loads((root/'provenance.json').read_text(encoding='utf-8'))
        engine.verify_run_provenance(saved_prov, engine.provenance(cfg), 'V4 head diagnostic')
        ckpt = torch.load(root/'best.pt', map_location='cpu', weights_only=True)
        if ckpt['config'] != cfg or ckpt['provenance'] != saved_prov or ckpt['epoch']+1 != complete['epoch']:
            raise ValueError('Checkpoint metadata mismatch')
        stats = json.loads((root/'normalization.json').read_text(encoding='utf-8'))
        if stats != ckpt['stats']:
            raise ValueError('Checkpoint normalization mismatch')
        store_key = fingerprint([cfg['data_root'], cfg.get('data_index'), cfg['layout'], cfg['max_length'], stats])
        if store_key not in cache:
            store = WaveformStore(cfg['data_root'], index_path=cfg.get('data_index'),
                                 layout=cfg['layout'], max_length=cfg['max_length'])
            validate_normalization(stats, training, store, verify_files=True)
            cache[store_key] = store
        store = cache[store_key]
        engine.seed_all(cfg['model_seed'], cfg['deterministic'], cfg['threads'])
        model = engine.build_model(cfg, initialize_pretrained=False).to(device).eval()
        model.load_state_dict(ckpt['model'], strict=True)
        subsets = {part: [r for r in records if r['partition'] == part]
                   for part in ('val_seen', 'val_unseen')}
        if args.train_limit:
            subsets['train_fixed_subset'] = sorted(training,
                key=lambda r: hashlib.sha256(r['record_id'].encode()).hexdigest())[:args.train_limit]
        settings = decoder_settings(cfg)
        folder = destination/f"{job['variant']}_m{cfg['model_seed']}"
        folder.mkdir()
        report = {'job': job['id'], 'variant': job['variant'], 'seed': cfg['model_seed'],
            'best_epoch': complete['epoch'], 'checkpoint_sha256': complete['sha256']['best.pt'],
            'normalization_files_verified': True, 'normalization_signature': store_key,
            'decoder_lambda_occ': {name: c['v4']['lambda_occ'] for name,c in settings},
            'plan_config_fingerprint': fingerprint(cfg),
            'partitions': {}}
        for partition, chosen in subsets.items():
            ds = CSIDataset(chosen, store, stats, expected_train_records=training)
            loader = DataLoader(ds, batch_size=cfg['evaluation']['batch_size'], shuffle=False,
                                num_workers=cfg['workers'], collate_fn=collate_records)
            raw, truths, metas, predictions = {}, [], [], {name: [] for name,_ in settings}
            with torch.inference_mode():
                for batch in loader:
                    out = model.predict_potentials(batch['X'].to(device), batch['valid'].to(device))
                    for key in ('regression', 'b'):
                        if key in out:
                            raw.setdefault(key, []).append(out[key].float().cpu().numpy())
                    for name, settings_cfg in settings:
                        predictions[name].extend(engine.decode_outputs(out, settings_cfg, candidates).cpu().tolist())
                    truths.extend(batch['counts'].tolist())
                    metas.extend(batch['meta'])
            if partition in ('val_seen', 'val_unseen'):
                stem = 'validation_seen_best.csv' if partition=='val_seen' else 'validation_best.csv'
                saved = {r['record_id']: r for r in engine.load_predictions(root/stem)}
                if len(saved) != len(metas) or set(saved) != {r['record_id'] for r in metas}:
                    raise ValueError('Saved prediction coverage mismatch')
                for meta, y, pred in zip(metas, truths, predictions['saved_decoder']):
                    old = saved[meta['record_id']]
                    if y != old['truth'] or pred != old['pred']:
                        raise ValueError(f'Baseline inference does not reproduce V4 CSV: {job["id"]}/{meta["record_id"]}')
            payload = {k: np.concatenate(v) for k,v in raw.items()}
            payload.update(truth=np.asarray(truths), record_ids=np.asarray([m['record_id'] for m in metas]))
            payload.update({'pred_'+k: np.asarray(v) for k,v in predictions.items()})
            if set(raw) != {'regression', 'b'} or not all(np.isfinite(v).all() for v in payload.values() if v.dtype.kind in 'fci'):
                raise ValueError('Missing/nonfinite V4 raw heads or predictions')
            np.savez_compressed(folder/f'{partition}_heads.npz', **payload)
            write_json(folder/f'{partition}_metadata.json', metas)
            report['partitions'][partition] = {'records': len(metas),
                'baseline_predictions_reproduced': partition != 'train_fixed_subset',
                'metrics': {name: evaluate_counts(truths, values, metas, max_occupancy=3,
                             train_context_records=training) for name,values in predictions.items()}}
        write_json(folder/'diagnostic.json', report)
        reports.append(report)
        print(f'HEAD_DIAGNOSTIC_OK={job["id"]}', flush=True)
        del ckpt, model
        if device.type=='cuda':
            torch.cuda.empty_cache()
    manifest = {str(f.relative_to(destination)): file_hash(f) for f in destination.rglob('*') if f.is_file()}
    write_json(destination/'diagnostic_complete.json', {'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'scope': 'Read-only V4 checkpoint explanation; no selection or formal test',
        'project': str(project), 'plan_fingerprint': plan['development_fingerprint'],
        'jobs_completed': len(reports), 'source_sha256': plan['source_sha256'],
        'train_limit': args.train_limit, 'shared_normalization_audits': len(cache),
        'script_sha256': file_hash(__file__), 'test_evaluated': False,
        'decoder_grid': [0., .1, .25, .5], 'selection_performed': False, 'files': manifest})
    archive = destination.with_name(destination.name+'.tar.gz')
    with archive.open('xb') as stream, tarfile.open(fileobj=stream, mode='w:gz') as tar:
        for f in sorted(destination.rglob('*')):
            if f.is_file():
                tar.add(f, arcname=destination.name+'/'+f.relative_to(destination).as_posix(), recursive=False)
    archive.with_name(archive.name+'.sha256').write_text(file_hash(archive)+'  '+archive.name+'\n', encoding='ascii')
    print(f'DIAGNOSTIC_ARCHIVE={archive}')


if __name__=='__main__':
    main()
