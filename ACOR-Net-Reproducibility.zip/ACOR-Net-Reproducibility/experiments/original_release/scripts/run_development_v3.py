"""Prepare/run/report a bounded original-train-only study; no formal test command."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from wificount.config import load_config
from wificount.development import (make_development_manifest, make_development_plan,
    run_development_plan, summarize_development)


def variants():
    # Controls and ablations are frozen before training; no test-based selection.
    entries = [
        {"name": "b4", "overrides": {"method": "b4", "training": {"sampler": "uniform", "weight_decay": .0001}}},
    ]
    for name, sampler in [("activity_counting", "uniform"), ("activity_counting_balanced", "support_balanced")]:
        entries.append({"name": name, "overrides": {"method": "activity_counting",
            "training": {"sampler": sampler}, "baseline": {"pretrained": True,
                "warp_probability": .5, "backbone_lr_multiplier": .1, "head_lr_multiplier": .1}}})
    for name, pooling, view, weight in [
        ("v2_global", "global", "amplitude", 0.),
        ("v2_dynamic", "query", "multiview", .5),
        ("v2_global_factor", "global", "amplitude", .5),
    ]:
        entries.append({"name": name, "overrides": {"method": "ours_v2",
            "training": {"sampler": "uniform"}, "v2": {"pooling": pooling,
                "input_view": view, "action_ce_weight": weight}}})
    for name, support, sampler in [
        ("v3_hurdle", False, "uniform"),
        ("v3_support", True, "uniform"),
        ("v3_balanced", True, "support_balanced"),
    ]:
        entries.append({"name": name, "overrides": {"method": "ours_v3",
            "training": {"sampler": sampler}, "v3": {"use_support": support}}})
    return entries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--manifest", default=str(ROOT/"data/manifests/sample_manifest_seed2026.csv"))
    p.add_argument("--data-root", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--stage", choices=("pilot", "full"), default="pilot")
    p.add_argument("--device", default="cuda")
    p.add_argument("--epochs", type=int)
    p = sub.add_parser("run")
    p.add_argument("--plan", required=True)
    p.add_argument("--execute", action="store_true")
    p.add_argument("--max-jobs", type=int)
    p = sub.add_parser("report")
    p.add_argument("--plan", required=True)
    p.add_argument("--output", required=True)
    p = sub.add_parser("pack")
    p.add_argument("--run-root", required=True)
    p.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        output = Path(args.output).resolve()
        if output.exists() and any(output.iterdir()):
            raise FileExistsError("Choose a new empty experiment output; resume with the run command")
        data_root = Path(args.data_root).resolve()
        if not data_root.is_dir():
            raise FileNotFoundError(data_root)
        epochs = args.epochs if args.epochs is not None else (3 if args.stage == "pilot" else 60)
        if epochs < 1:
            raise ValueError("epochs must be positive")
        cfg = load_config(ROOT/"configs/development_v3.yaml", {
            "data_root": str(data_root), "device": args.device,
            "training": {"epochs": epochs}})
        split = make_development_manifest(args.manifest, output/"development_manifest.csv")
        plan = make_development_plan(cfg, split["manifest"], output, variants(),
                                     seeds=(11,) if args.stage == "pilot" else (11,22,33))
        with (output/"plan.json").open("x", encoding="utf-8") as f:
            json.dump(plan, f, ensure_ascii=False, indent=2)
        result = {"plan": str(output/"plan.json"), "job_count": plan["job_count"],
                  "epochs_max": epochs, "stage": args.stage, **split,
                  "note": "Pilot checks execution only. Original formal holdouts are excluded."}
    elif args.command == "run":
        result = run_development_plan(args.plan, args.execute, args.max_jobs)
    elif args.command == "report":
        result = summarize_development(args.plan, args.output)
        from wificount.development_diagnostics import summarize_diagnostics
        result["diagnostics"] = summarize_diagnostics(args.plan, args.output)
    else:
        import hashlib
        import tarfile
        run_root, output = Path(args.run_root).resolve(), Path(args.output).resolve()
        if not (run_root/"plan.json").is_file():
            raise ValueError("run-root must contain a development plan")
        from wificount.development import verify_development_plan
        verify_development_plan(run_root/"plan.json")
        # Share metadata, metrics, logs and predictions; keep all weights locally.
        selected = [p for p in run_root.rglob("*") if p.is_file()
                    and "cache" not in p.relative_to(run_root).parts
                    and p.suffix in {".json", ".jsonl", ".csv", ".log"}]
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("xb") as stream:
            with tarfile.open(fileobj=stream, mode="w:gz") as archive:
                for p in sorted(selected):
                    archive.add(p, arcname="development/"+p.relative_to(run_root).as_posix(), recursive=False)
                for p in sorted((ROOT/"src/wificount").glob("*.py")):
                    archive.add(p, arcname="source/wificount/"+p.name, recursive=False)
                for folder in ("configs", "scripts", "docs"):
                    for p in sorted((ROOT/folder).rglob("*")):
                        if p.is_file() and "__pycache__" not in p.parts and p.suffix in {".py", ".sh", ".yaml", ".md", ".bib"}:
                            archive.add(p, arcname="source/"+p.relative_to(ROOT).as_posix(), recursive=False)
                for name in ("release_files.json", "VALIDATION.json", "requirements-tested.txt", "README.md"):
                    p = ROOT/name
                    if p.is_file():
                        archive.add(p, arcname="source/"+name, recursive=False)
                plan = json.loads((run_root/"plan.json").read_text(encoding="utf-8"))
                protocol = json.loads(Path(plan["protocol_path"]).read_text(encoding="utf-8"))
                archive.add(protocol["source_manifest"], arcname="source/original_manifest.csv", recursive=False)
        digest = hashlib.sha256(output.read_bytes()).hexdigest()
        output.with_name(output.name+".sha256").write_bytes(f"{digest}  {output.name}\n".encode("ascii"))
        result = {"archive": str(output), "sha256": digest, "checkpoint_files_included": False}
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
