"""Extract and verify required amplitudes from the official Kaggle ZIP.

Existing files are reused only when both their length and CRC match the archive.
The frozen manifest is never replaced by the downloaded annotation.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
from zipfile import ZipFile
import zlib


def matches_archive(path: Path, info) -> bool:
    """Compare file contents, not merely NPY container length."""
    if not path.is_file() or path.stat().st_size != info.file_size:
        return False
    crc = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            crc = zlib.crc32(chunk, crc)
    return (crc & 0xFFFFFFFF) == info.CRC


def extract_dataset(zip_path: str | Path, output: str | Path,
                    manifest: str | Path) -> dict:
    out = Path(output)
    target = out / "wifi_csi" / "amp"
    target.mkdir(parents=True, exist_ok=True)
    with Path(manifest).open(encoding="utf-8-sig", newline="") as stream:
        wanted = {row["record_id"] for row in csv.DictReader(stream)
                  if row["partition"] != "excluded_4_5"}
    if not wanted:
        raise ValueError("Manifest contains no required records")
    extracted = reused = 0
    with ZipFile(zip_path) as archive:
        members = {}
        # Complete the ambiguity check before modifying any extracted files.
        for info in archive.infolist():
            path = PurePosixPath(info.filename)
            if path.suffix == ".npy" and path.stem in wanted and "amp" in path.parts:
                dest = target / path.name
            elif path.name == "annotation.csv":
                dest = out / "downloaded_annotation.csv"
            else:
                continue
            if dest in members:
                raise ValueError(f"Ambiguous archive members for {dest.name}: "
                                 f"{members[dest].filename!r} and {info.filename!r}")
            members[dest] = info
        absent_from_archive = sorted(rid for rid in wanted
                                     if target / f"{rid}.npy" not in members)
        for dest, info in members.items():
            if matches_archive(dest, info):
                reused += 1
                continue
            temp = dest.with_name(dest.name + ".part")
            # ZipExtFile checks CRC when its payload is completely consumed.
            with archive.open(info) as src, temp.open("wb") as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)
            if not matches_archive(temp, info):
                raise ValueError(f"Extracted contents failed archive CRC: {info.filename}")
            temp.replace(dest)
            extracted += 1
            if extracted % 500 == 0:
                print(f"extracted={extracted}", flush=True)
    missing = sorted(rid for rid in wanted if not (target / f"{rid}.npy").is_file())
    report = {"needed_records": len(wanted), "present_records": len(wanted) - len(missing),
              "missing": missing, "absent_from_archive": absent_from_archive,
              "verified_records": len(wanted) - len(absent_from_archive),
              "extracted_this_run": extracted, "reused_verified_files": reused,
              "existing_file_verification": "archive_length_and_crc32",
              "annotation_replaces_frozen_manifest": False,
              "ok": not missing and not absent_from_archive}
    annotation = out / "downloaded_annotation.csv"
    if annotation.exists():
        report["downloaded_annotation_sha256"] = hashlib.sha256(annotation.read_bytes()).hexdigest()
    (out / "extraction_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zip", required=True)
    parser.add_argument("--output", default="data/wimans")
    parser.add_argument("--manifest", default="data/manifests/sample_manifest_seed2026.csv")
    args = parser.parse_args()
    report = extract_dataset(args.zip, args.output, args.manifest)
    print(json.dumps({key: value for key, value in report.items()
                      if key not in {"missing", "absent_from_archive"}}, indent=2))
    if not report["ok"]:
        raise SystemExit("Required amplitude files are missing or absent from this archive; "
                         "inspect extraction_report.json")


if __name__ == "__main__":
    main()
