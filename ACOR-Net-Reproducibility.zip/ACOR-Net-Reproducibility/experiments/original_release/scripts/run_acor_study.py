#!/usr/bin/env python3
"""Bounded validation search, original formal splits, and component ablations.

This protocol evaluates an already inspected benchmark. It does not promise
contrast superiority or change settings in response to test results.
"""
from __future__ import annotations

import argparse
import copy
import csv
import json
from pathlib import Path
import statistics
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
import run_final_acor as archived
from wificount.config import file_hash, fingerprint, validate_config, write_json
from wificount.reporting import METRICS, read_json

SPLITS = (2026, 2027, 2028)
BASELINES = ("amar", "mushot_source", "activity_counting", "mldg")
METHODS = (*BASELINES, "ours_v4")
PRIMARY_BASELINE = "activity_counting"
STUDY_ID = "acor_reduced_20261102"
PARTITIONS = ("test_unseen", "test_seen", "test_aux")
ABLATIONS = ("shared_features", "no_occupancy", "no_contrast")
SELECTION = ("Each run: val_unseen macro exact, then lower positive-count MAE, then earlier epoch. "
             "Across configurations: three-seed mean best-validation macro, lower mean MAE, earlier mean best epoch, lower gamma, lower learning rate")
SCOPE = "Frozen evaluation on previously inspected benchmark partitions; not a new blind test. No predeclared superiority of contrast over matched no-contrast training."
now = archived.now
immutable_json = archived.immutable_json
verify_completed_run = archived.verify_completed_run
write_csv = archived.write_csv


def seal(value):
    value = copy.deepcopy(value)
    value["contract_sha256"] = fingerprint(value)
    return value


def checked(path):
    value = read_json(path)
    if value.get("contract_sha256") != fingerprint({k: v for k, v in value.items() if k != "contract_sha256"}):
        raise ValueError(f"Frozen artifact changed: {path}")
    return value


def source_identity():
    paths = []
    for folder, pattern in (("src", "*.py"), ("scripts", "*.py"), ("configs", "*.json")):
        paths.extend((ROOT / folder).rglob(pattern))
    return {p.relative_to(ROOT).as_posix(): file_hash(p) for p in sorted(paths)}


def build_protocol(run_root, data_root, model_seeds, baseline_mode="retrain", ablation_splits=SPLITS,
                   device="cuda", workers=4, threads=4):
    seeds, abl = tuple(model_seeds), tuple(ablation_splits)
    if seeds != SPLITS:
        raise ValueError("All tasks require model seeds 2026 2027 2028, in that order")
    if baseline_mode != "retrain":
        raise ValueError("This study requires retraining all baselines with all three specified seeds")
    if abl not in ((2026,), SPLITS):
        raise ValueError("Ablation splits must be 2026 or all original three splits")
    if workers < 0 or threads < 1:
        raise ValueError("Require nonnegative workers and positive threads")
    return seal({"schema": 2, "study_id": STUDY_ID, "name": "ACOR-Net", "scope": SCOPE,
        "methods": list(METHODS), "primary_comparison": PRIMARY_BASELINE,
        "run_root": str(Path(run_root).resolve()), "data_root": str(Path(data_root).resolve()),
        "split_seeds": list(SPLITS), "model_seeds": list(seeds), "search_model_seeds": list(seeds),
        "baseline_mode": baseline_mode, "ablation_splits": list(abl),
        "learning_rates": [.0003, .001], "acor_gamma_grid": [0., .025, .05, .1],
        "selection_rule": SELECTION,
        "device": device, "workers": workers, "threads": threads,
        "historical_test_exposure": True, "test_used_for_this_selection": False,
        "source_sha256": source_identity(),
        "manifest_sha256": {str(s): file_hash(ROOT / f"data/manifests/sample_manifest_seed{s}.csv") for s in SPLITS}})


def load_protocol(run_root):
    protocol = checked(Path(run_root) / "protocol.json")
    if (protocol.get("study_id") != STUDY_ID or protocol.get("methods") != list(METHODS)
            or protocol.get("primary_comparison") != PRIMARY_BASELINE):
        raise ValueError("Protocol is not the reduced five-method study")
    if protocol["run_root"] != str(Path(run_root).resolve()):
        raise ValueError("Resume in the original run directory")
    if protocol["source_sha256"] != source_identity():
        raise ValueError("Release source/config files changed after protocol freeze")
    for split, digest in protocol["manifest_sha256"].items():
        if file_hash(ROOT / f"data/manifests/sample_manifest_seed{split}.csv") != digest:
            raise ValueError("Original formal manifest changed")
    return protocol


def template(method):
    if method not in METHODS:
        raise ValueError(f"Method is outside the reduced study: {method}")
    path = ROOT / ("configs/final_acor.json" if method == "ours_v4" else f"configs/baseline_templates/{method}.json")
    cfg = read_json(path)
    cfg.pop("development_protocol", None)
    if method == "ours_v4":
        if cfg["method"] != method or cfg["v4"]["joint_weight"] != 0:
            raise ValueError("ACOR template must preserve ours_v4 joint0")
        if cfg["training"]["epochs"] != 60 or cfg["training"]["batch_size"] != 16:
            raise ValueError("ACOR training budget changed")
    if cfg["method"] != method or cfg["no_aux"]:
        raise ValueError("Baseline template changed method or train cohort")
    return cfg


def configured(protocol, method, split, seed, job_id):
    cfg = template(method)
    cfg.update(name=job_id, split_seed=split, model_seed=seed,
        manifest=str((ROOT / f"data/manifests/sample_manifest_seed{split}.csv").resolve()),
        output=str(Path(protocol["run_root"]) / "runs" / job_id),
        cache_dir=str(Path(protocol["run_root"]) / "cache"), data_root=protocol["data_root"],
        data_index=None, device=protocol["device"], workers=protocol["workers"], threads=protocol["threads"])
    return cfg


def search_plan(protocol):
    methods = METHODS
    jobs = []
    for split in SPLITS:
        for method in methods:
            gammas = protocol["acor_gamma_grid"] if method == "ours_v4" else [0.]
            for lr in protocol["learning_rates"]:
                for gamma in gammas:
                    candidate_id = f"{method}_s{split}_lr{lr:g}_g{gamma:g}"
                    for seed in protocol["model_seeds"]:
                        job_id = f"search/{candidate_id}_m{seed}"
                        cfg = configured(protocol, method, split, seed, job_id)
                        cfg["training"].update(learning_rate=lr, gamma=gamma)
                        validate_config(cfg)
                        jobs.append({"id": job_id, "candidate_id": candidate_id,
                                     "role": "search", "method": method, "config": cfg})
    return seal({"schema": 1, "stage": "search", "protocol_sha256": protocol["contract_sha256"],
                 "manifest_sha256": protocol["manifest_sha256"], "jobs": jobs, "job_count": len(jobs)})


def load_search(run_root):
    protocol = load_protocol(run_root)
    plan = checked(Path(run_root) / "search_plan.json")
    if plan != search_plan(protocol):
        raise ValueError("Search grid differs from the frozen protocol")
    return protocol, plan


def verify_baselines(run_root, protocol):
    if protocol["baseline_mode"] != "reuse-original":
        return []
    rows, status = archived.baseline_rows(run_root, protocol)
    if status != "BASELINES_VERIFIED":
        raise ValueError("Original baseline snapshot must pass the strict collector before training")
    return rows


def prepare(run_root, data_root, model_seeds, baseline_mode="retrain", ablation_splits=SPLITS,
            device="cuda", workers=4, threads=4):
    root = Path(run_root)
    protocol = build_protocol(root, data_root, model_seeds, baseline_mode, ablation_splits, device, workers, threads)
    immutable_json(root / "protocol.json", protocol)
    plan = search_plan(protocol)
    immutable_json(root / "search_plan.json", plan)
    archived.audit_data(root, plan)
    immutable_json(root / "prepare_complete.json", {"protocol_sha256": file_hash(root / "protocol.json"),
        "audit_index_sha256": file_hash(root / "audit_index.json"), "search_jobs": len(plan["jobs"])})
    return {"status": "PREPARED", "search_jobs": len(plan["jobs"]), "model_seeds": model_seeds}


def train_one(job):
    from wificount.engine import train
    folder = Path(job["config"]["output"])
    if not (folder / "training_summary.json").exists():
        last = folder / "last.pt"
        train(job["config"], resume=str(last) if last.exists() else None)
    return verify_completed_run(job)


def search(run_root):
    protocol, plan = load_search(run_root)
    verify_baselines(run_root, protocol)
    archived.verify_audits(run_root, plan, verify_files=True)
    if (Path(run_root) / "freeze.json").exists():
        verify_freeze(run_root, verify_files=False)
        return {"status": "FROZEN_SEARCH_REUSED", "search_jobs": len(plan["jobs"])}
    for index, job in enumerate(plan["jobs"], 1):
        print(f"SEARCH {index}/{len(plan['jobs'])} {job['id']}", flush=True)
        train_one(job)
    immutable_json(Path(run_root) / "search_complete.json", {
        "search_plan_sha256": file_hash(Path(run_root) / "search_plan.json"), "jobs": len(plan["jobs"])})
    return {"status": "SEARCH_COMPLETE", "jobs": len(plan["jobs"])}


def ranking(metrics, summary, cfg):
    return (metrics["macro_exact_match_by_complete_composition"], -metrics["positive_count_mae"],
            -summary["best_epoch"], -cfg["training"]["gamma"], -cfg["training"]["learning_rate"])


def candidate_ranking(runs):
    """Choose a configuration using all three validation runs, never a best seed."""
    if len(runs) != 3 or {r["config"]["model_seed"] for r in runs} != set(SPLITS):
        raise ValueError("Each hyperparameter candidate requires exactly seeds 2026/2027/2028")
    signatures = {(r["config"]["method"], r["config"]["split_seed"],
                   r["config"]["training"]["gamma"], r["config"]["training"]["learning_rate"])
                  for r in runs}
    if len(signatures) != 1:
        raise ValueError("Cannot pool different hyperparameter candidates")
    cfg = runs[0]["config"]
    return (statistics.mean(r["validation"]["macro_exact_match_by_complete_composition"] for r in runs),
            -statistics.mean(r["validation"]["positive_count_mae"] for r in runs),
            -statistics.mean(r["best_epoch"] for r in runs),
            -cfg["training"]["gamma"], -cfg["training"]["learning_rate"])


def build_selected_plan(protocol, selection):
    root = Path(protocol["run_root"])
    if set(selection["selected"]) != {f"{method}:{split}" for method in METHODS for split in SPLITS}:
        raise ValueError("Selected methods/splits differ from the reduced study")
    jobs, main = [], {}
    for key, winner in sorted(selection["selected"].items()):
        method, split = key.split(":")
        split = int(split)
        for seed in protocol["model_seeds"]:
            job_id = f"main/{method}_s{split}_m{seed}"
            cfg = copy.deepcopy(winner["seed_configs"][str(seed)])
            if (cfg["method"], cfg["split_seed"], cfg["model_seed"]) != (method, split, seed):
                raise ValueError("Selected configuration has a different method/split/model seed")
            job = {"id": job_id, "role": "main", "method": method, "config": cfg,
                   "reuse": "selected_search", "selected_candidate": winner["candidate_id"]}
            jobs.append(job)
            main[(method, split, seed)] = job
    for split in protocol["ablation_splits"]:
        for seed in protocol["model_seeds"]:
            parent = main[("ours_v4", split, seed)]
            for variant in ABLATIONS:
                job_id = f"ablation/{variant}_s{split}_m{seed}"
                cfg = copy.deepcopy(parent["config"])
                equivalent = variant == "no_contrast" and cfg["training"]["gamma"] == 0
                if not equivalent:
                    cfg.update(name=job_id, output=str(root / "runs" / job_id))
                    if variant == "shared_features":
                        cfg["v4"]["action_feature_mode"] = "shared"
                    elif variant == "no_occupancy":
                        cfg["v4"].update(occupancy_weight=0., lambda_occ=0.)
                    else:
                        cfg["training"]["gamma"] = 0.
                validate_config(cfg)
                jobs.append({"id": job_id, "role": "ablation", "method": "ours_v4", "variant": variant,
                             "parent": parent["id"], "config": cfg,
                             "reuse": "identical_zero_contrast_parent" if equivalent else None})
    return seal({"schema": 2, "study_id": STUDY_ID, "stage": "selected_formal", "scope": SCOPE, "jobs": jobs,
        "methods": list(METHODS), "primary_comparison": PRIMARY_BASELINE,
        "model_seeds": protocol["model_seeds"], "manifest_sha256": protocol["manifest_sha256"],
        "ablation_splits": protocol["ablation_splits"], "baseline_mode": protocol["baseline_mode"],
        "protocol_sha256": protocol["contract_sha256"], "selection_sha256": selection["contract_sha256"],
        "job_count": len(jobs), "expected_evaluations": 3 * len(jobs), "checkpoint_policy": "best_only"})


def select(run_root):
    protocol, search_jobs = load_search(run_root)
    winners, candidates, grouped = {}, [], {}
    for job in search_jobs["jobs"]:
        summary = verify_completed_run(job)
        cfg = job["config"]
        metrics = read_json(Path(cfg["output"]) / "validation_best.json")
        item = {"job": job["id"], "config": cfg, "validation": metrics,
                "best_epoch": summary["best_epoch"], "best_sha256": file_hash(Path(cfg["output"]) / "best.pt")}
        grouped.setdefault(job["candidate_id"], []).append(item)
    for candidate_id, runs in sorted(grouped.items()):
        rank = candidate_ranking(runs)
        cfg = runs[0]["config"]
        item = {"candidate_id": candidate_id, "ranking": list(rank), "runs": runs,
                "seed_configs": {str(r["config"]["model_seed"]): r["config"] for r in runs},
                "seed_checkpoint_sha256": {str(r["config"]["model_seed"]): r["best_sha256"] for r in runs}}
        candidates.append(item)
        key = f"{cfg['method']}:{cfg['split_seed']}"
        if key not in winners or rank > tuple(winners[key]["ranking"]):
            winners[key] = item
    selection = seal({"selected": winners, "candidates": candidates, "selection_rule": SELECTION,
        "configuration_selection": "mean of three best-validation Macro Exact values, then lower mean MAE, earlier mean best epoch, lower gamma, lower learning rate; no best-seed selection",
        "search_plan_sha256": file_hash(Path(run_root) / "search_plan.json"), "test_used_for_selection": False})
    immutable_json(Path(run_root) / "selection.json", selection)
    plan = build_selected_plan(protocol, selection)
    immutable_json(Path(run_root) / "plan.json", plan)
    return {"status": "VALIDATION_SELECTION_FROZEN", "selected_configs": len(winners),
            "main_and_ablation_jobs": len(plan["jobs"]), "evaluation_rows": plan["expected_evaluations"]}


def load_plan(run_root):
    protocol = load_protocol(run_root)
    selection = checked(Path(run_root) / "selection.json")
    if selection["search_plan_sha256"] != file_hash(Path(run_root) / "search_plan.json"):
        raise ValueError("Selection does not bind the frozen search plan")
    plan = checked(Path(run_root) / "plan.json")
    if plan != build_selected_plan(protocol, selection):
        raise ValueError("Selected plan differs from validation selection")
    for winner in selection["selected"].values():
        for seed, cfg in winner["seed_configs"].items():
            if file_hash(Path(cfg["output"]) / "best.pt") != winner["seed_checkpoint_sha256"][seed]:
                raise ValueError("Selected search checkpoint changed")
    return plan


def train_runs(run_root):
    protocol = load_protocol(run_root)
    plan = load_plan(run_root)
    verify_baselines(run_root, protocol)
    archived.verify_audits(run_root, plan, verify_files=True)
    if (Path(run_root) / "freeze.json").exists():
        verify_freeze(run_root, verify_files=False)
        return {"status": "FROZEN_TRAINING_REUSED", "jobs": len(plan["jobs"])}
    for index, job in enumerate(plan["jobs"], 1):
        print(f"TRAIN {index}/{len(plan['jobs'])} {job['id']} reuse={job['reuse']}", flush=True)
        if job["reuse"]:
            verify_completed_run(job)
        else:
            train_one(job)
    immutable_json(Path(run_root) / "train_complete.json", {"plan_sha256": file_hash(Path(run_root) / "plan.json"),
                   "jobs": len(plan["jobs"])})
    return {"status": "ALL_SELECTED_JOBS_TRAINED", "jobs": len(plan["jobs"])}


def freeze(run_root):
    root = Path(run_root)
    if (root / "freeze.json").exists():
        plan, frozen = verify_freeze(root)
        return {"status": "FREEZE_VERIFIED", "jobs": len(plan["jobs"])}
    protocol = load_protocol(root)
    plan = load_plan(root)
    verify_baselines(root, protocol)
    archived.verify_audits(root, plan, verify_files=True)
    frozen_jobs = {}
    for job in plan["jobs"]:
        folder = Path(job["config"]["output"])
        if list(folder.glob("evaluation_test*")):
            raise ValueError("Test artifacts exist before whole-study freeze; preserve them for review")
        verify_completed_run(job)
        frozen_jobs[job["id"]] = {"files": {p.relative_to(folder).as_posix(): file_hash(p)
            for p in sorted(folder.rglob("*")) if p.is_file()}, "runtime": read_json(folder / "provenance.json")}
    frozen = seal({"schema": 1, "status": "ALL_SELECTED_MODELS_FROZEN_BEFORE_THIS_TEST_INFERENCE",
        "created_utc": now(), "jobs": frozen_jobs, "checkpoint_policy": "best_only", "scope": SCOPE,
        "plan_sha256": file_hash(root / "plan.json"), "audit_index_sha256": file_hash(root / "audit_index.json"),
        "baseline_summary_sha256": file_hash(root / "baseline_reference/summary.json") if protocol["baseline_mode"] == "reuse-original" else None})
    immutable_json(root / "freeze.json", frozen)
    return {"status": frozen["status"], "jobs": len(plan["jobs"])}


def verify_freeze(run_root, verify_files=True):
    from wificount.engine import provenance, verify_run_provenance
    root = Path(run_root)
    plan = load_plan(root)
    frozen = checked(root / "freeze.json")
    if (frozen["plan_sha256"] != file_hash(root / "plan.json")
            or frozen["audit_index_sha256"] != file_hash(root / "audit_index.json")
            or set(frozen["jobs"]) != {j["id"] for j in plan["jobs"]}):
        raise ValueError("Freeze does not bind the complete selected matrix")
    archived.verify_audits(root, plan, verify_files=verify_files)
    if plan["baseline_mode"] == "reuse-original":
        if frozen["baseline_summary_sha256"] != file_hash(root / "baseline_reference/summary.json"):
            raise ValueError("Historical baseline snapshot changed after freeze")
        verify_baselines(root, load_protocol(root))
    required = {"best.pt", "last.pt", "config.json", "provenance.json", "normalization.json",
                "training_summary.json", "history.jsonl", "validation_best.json", "validation_best.csv"}
    verified = {}
    for job in plan["jobs"]:
        item = frozen["jobs"][job["id"]]
        if not required <= item["files"].keys():
            raise ValueError("Frozen run lacks required evidence")
        verify_run_provenance(item["runtime"], provenance(job["config"]), job["id"])
        for name, digest in item["files"].items():
            path = Path(job["config"]["output"]) / name
            if Path(name).is_absolute() or ".." in Path(name).parts:
                raise ValueError("Unsafe frozen artifact path")
            if path not in verified:
                verified[path] = file_hash(path)
            if verified[path] != digest:
                raise ValueError(f"Frozen artifact changed: {path}")
    return plan, frozen


def evaluate_runs(run_root):
    from wificount.engine import evaluate
    from wificount.reporting import verify_evaluation
    root = Path(run_root)
    plan, frozen = verify_freeze(root, verify_files=True)
    rows = []
    for job in plan["jobs"]:
        cfg = job["config"]
        folder = Path(cfg["output"])
        for partition in PARTITIONS:
            destination = folder / f"evaluation_{partition}"
            if destination.exists() and not (destination / "evaluation_complete.json").exists():
                quarantined = root / "incomplete_evaluations" / f"{job['id'].replace('/', '_')}_{partition}_{now()}"
                quarantined.parent.mkdir(parents=True, exist_ok=True)
                destination.rename(quarantined)
            if not destination.exists():
                print(f"EVALUATE {job['id']} {partition}", flush=True)
                evaluate(folder / "best.pt", partition, destination, device=cfg["device"])
            verify_evaluation(destination, folder / "best.pt", partition=partition, cfg=cfg,
                              runtime=frozen["jobs"][job["id"]]["runtime"])
            rows.append({"job": job["id"], "role": job["role"], "partition": partition,
                         "completion_sha256": file_hash(destination / "evaluation_complete.json")})
    value = {"status": "ALL_SELECTED_EVALUATIONS_VERIFIED", "rows": rows,
             "freeze_sha256": file_hash(root / "freeze.json"), "evaluation_rows": len(rows)}
    write_json(root / "evaluation_index.json", value)
    return {"status": value["status"], "evaluation_rows": len(rows)}


def balance_rows(rows):
    grouped = {}
    for row in rows:
        if row["partition"] in ("test_seen", "test_unseen"):
            key = (row["method"], row["split_seed"], row["model_seed"])
            if row["partition"] in grouped.setdefault(key, {}):
                raise ValueError("Duplicate seen/unseen row")
            grouped[key][row["partition"]] = row["macro_exact_match_by_complete_composition"]
    result = []
    for key, values in sorted(grouped.items()):
        if set(values) != {"test_seen", "test_unseen"}:
            raise ValueError("H requires paired seen/unseen from the same selected model")
        s, u = values["test_seen"], values["test_unseen"]
        result.append(dict(zip(("method", "split_seed", "model_seed"), key), seen_macro=s,
                           unseen_macro=u, H=2 * s * u / (s + u) if s + u else 0.))
    return result


def balance_summary(rows):
    grouped = {}
    for row in rows:
        grouped.setdefault((row["method"], row["split_seed"]), []).append(row["H"])
    return [{"method": m, "split_seed": s, "runs": len(v), "H_mean": statistics.mean(v),
             "H_sd": statistics.stdev(v) if len(v) > 1 else None} for (m, s), v in sorted(grouped.items())]


def validate_main_rows(rows):
    labels = (*BASELINES, "ACOR-Net")
    expected = {(m, s, seed, p) for m in labels for s in SPLITS for seed in SPLITS for p in PARTITIONS}
    actual = {(r["method"], r["split_seed"], r["model_seed"], r["partition"]) for r in rows}
    if len(rows) != len(expected) or actual != expected:
        raise ValueError("Main table must contain exactly the five reduced methods x three splits x three seeds x three partitions")


def report(run_root):
    from wificount.engine import load_predictions
    from wificount.metrics import paired_bootstrap
    from wificount.reporting import verify_evaluation
    root = Path(run_root)
    plan, frozen = verify_freeze(root, verify_files=False)
    main, ablations = [], []
    primary_predictions = {method: [] for method in ("ours_v4", PRIMARY_BASELINE)}
    for job in plan["jobs"]:
        cfg = job["config"]
        folder = Path(cfg["output"])
        for partition in PARTITIONS:
            destination = folder / f"evaluation_{partition}"
            verify_evaluation(destination, folder / "best.pt", partition=partition, cfg=cfg,
                              runtime=frozen["jobs"][job["id"]]["runtime"])
            metrics = read_json(destination / "metrics.json")
            if job["role"] == "main" and cfg["method"] in primary_predictions and partition == "test_unseen":
                primary_predictions[cfg["method"]].extend(load_predictions(destination / "predictions.csv"))
            row = {"method": ("ACOR-Net" if cfg["method"] == "ours_v4" else cfg["method"])
                   if job["role"] == "main" else job["variant"],
                   "split_seed": cfg["split_seed"], "model_seed": cfg["model_seed"], "partition": partition,
                   "checkpoint": "best", "epoch": read_json(folder / "training_summary.json")["best_epoch"],
                   "records": metrics["denominators_and_numerators"]["samples"],
                   "source": "fixed_selected_model", **{k: metrics[k] for k in METRICS}}
            (main if job["role"] == "main" else ablations).append(row)
    validate_main_rows(main)
    parent = [dict(r, method="Full") for r in main if r["method"] == "ACOR-Net" and r["split_seed"] in plan["ablation_splits"]]
    ablations = parent + ablations
    folder = root / "reports"
    for name, rows in (("main", main), ("ablation", ablations)):
        write_csv(folder / f"{name}_all_runs.csv", rows)
        write_csv(folder / f"{name}_per_split.csv", archived.aggregate_rows(rows))
        balances = balance_rows(rows)
        write_csv(folder / f"{name}_balance_per_run.csv", balances)
        write_csv(folder / f"{name}_balance_per_split.csv", balance_summary(balances))
    parents = {(r["split_seed"], r["model_seed"], r["partition"]): r for r in parent}
    differences = []
    for row in ablations:
        if row["method"] == "Full":
            continue
        full = parents[(row["split_seed"], row["model_seed"], row["partition"])]
        differences.append({"variant": row["method"], "split_seed": row["split_seed"],
            "model_seed": row["model_seed"], "partition": row["partition"],
            "difference_direction": "full_minus_variant",
            **{k: full[k] - row[k] if full[k] is not None and row[k] is not None else None for k in METRICS}})
    write_csv(folder / "ablation_paired_differences.csv", differences)
    for baseline in (PRIMARY_BASELINE,):
        interval = paired_bootstrap(primary_predictions["ours_v4"], primary_predictions[baseline], replicates=2000)
        write_json(folder / f"paired_bootstrap_acor_vs_{baseline}.json", interval)
    summary = {"status": "STUDY_REPORT_COMPLETE", "main_rows": len(main), "ablation_rows_including_full": len(ablations),
        "study_id": STUDY_ID, "methods": list(METHODS), "primary_comparison": PRIMARY_BASELINE,
        "model_seeds": plan["model_seeds"], "baseline_mode": plan["baseline_mode"], "scope": SCOPE,
        "selected_main_jobs": sum(j["role"] == "main" for j in plan["jobs"]),
        "ablation_jobs": sum(j["role"] == "ablation" for j in plan["jobs"]),
        "selected_unique_output_directories": len({j["config"]["output"] for j in plan["jobs"]}),
        "selected_search_reuses": sum(j.get("reuse") == "selected_search" for j in plan["jobs"]),
        "equivalent_ablation_reuses": sum(j.get("reuse") == "identical_zero_contrast_parent" for j in plan["jobs"]),
        "freeze_sha256": file_hash(root / "freeze.json"), "selection_rule": SELECTION,
        "ablation_interpretation": "Module differences, not assumed gains. Shared feature width changes count/projector parameters; no_occupancy removes CE and decoder jointly.",
        "uncertainty": "Per-split SD over initializations; splits overlap and are not independent subjects"}
    for label, relative in (("sensitivity", "sensitivity/summary.json"), ("latency", "profile/inference_latency.json")):
        path = root / relative
        if path.exists():
            value = read_json(path)
            if value.get("freeze_sha256") != summary["freeze_sha256"]:
                raise ValueError(f"{label} report belongs to another freeze")
            if label == "sensitivity":
                if value.get("status") != "SENSITIVITY_COMPLETE" or value.get("evaluations") != 27:
                    raise ValueError("Decoder sensitivity is incomplete")
                for relative_artifact, digest in value.get("artifact_sha256", {}).items():
                    artifact_path = (root / relative_artifact).resolve()
                    if not artifact_path.is_relative_to(root.resolve()) or Path(relative_artifact).is_absolute():
                        raise ValueError("Unsafe sensitivity artifact path")
                    if file_hash(artifact_path) != digest:
                        raise ValueError("Decoder sensitivity artifact changed")
                sensitivity_rows = [{"variant": "fixed_weight_lambda0", "split_seed": r["split_seed"],
                    "model_seed": r["model_seed"], "partition": r["partition"],
                    **r["metrics"], **{f"changed_minus_full_{k}": v for k, v in r["changed_minus_full"].items()}}
                    for r in value["rows"]]
                if len(sensitivity_rows) != 27:
                    raise ValueError("Decoder sensitivity rows are incomplete")
                write_csv(folder / "fixed_weight_decoder_sensitivity.csv", sensitivity_rows)
            elif value.get("status") != "complete":
                raise ValueError("Latency profile is incomplete")
            summary[label] = {"path": relative, "sha256": file_hash(path), "status": value.get("status")}
        else:
            summary[label] = "PENDING"
    write_json(folder / "summary.json", summary)
    (folder / "README.md").write_text("# ACOR-Net formal tables\n\n" + SCOPE + "\n\n"
        "Primary tables report initialization mean/SD separately for each original split. H is computed per selected model before averaging. "
        "Main results, retrained component ablations, and fixed-weight decoder sensitivity are separate. "
        "The no-contrast parent-equivalent case is retained and explicitly recorded in plan.json. "
        "Do not claim that every component improves all metrics before inspecting the complete tables.\n", encoding="utf-8")
    return summary


def status(run_root):
    root = Path(run_root)
    return {"status": "INVENTORY_ONLY_NOT_VERIFIED", "run_root": str(root.resolve()),
        "protocol_present": (root / "protocol.json").is_file(), "plan_present": (root / "plan.json").is_file(),
        "freeze_present": (root / "freeze.json").is_file(),
        "training_markers": len(list((root / "runs").rglob("training_summary.json"))),
        "evaluation_markers": len(list((root / "runs").rglob("evaluation_complete.json"))),
        "report": read_json(root / "reports/summary.json") if (root / "reports/summary.json").exists() else None}


def pack(run_root, output=None):
    root = Path(run_root).resolve()
    if not root.is_dir():
        raise ValueError("No study directory to package")
    out = Path(output).resolve() if output else root.parent / f"acor-reduced-results-{now()}.tar.gz"
    if out.exists():
        raise FileExistsError("Refusing to overwrite a result archive")
    write_json(root / "package_inventory.json", {**status(root), "packaged_utc": now(),
        "checkpoints_retained_on_server": True, "excluded": "weights/cache/raw CSI/bytecode", "scope": SCOPE})
    allowed = {".json", ".jsonl", ".csv", ".md", ".txt", ".log", ".yaml", ".yml", ".sha256", ".py"}
    selected = []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if (path.is_file() and not path.is_symlink() and "cache" not in rel.parts and "__pycache__" not in rel.parts
                and path.suffix.lower() in allowed and path.name != "package_files.sha256.json"
                and path not in (out, out.with_name(out.name + ".sha256"))):
            selected.append((path, "acor_reduced/" + rel.as_posix()))
    for relative in ("src", "configs", "data/manifests", "scripts", "docs"):
        for path in sorted((ROOT / relative).rglob("*")):
            if path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts:
                selected.append((path, "release/" + path.relative_to(ROOT).as_posix()))
    for name in ("release_files.json", "README_SERVER_CN.md", "environment.yml", "requirements-tested.txt", "pyproject.toml"):
        path = ROOT / name
        if path.is_file():
            selected.append((path, "release/" + name))
    manifest = root / "package_files.sha256.json"
    write_json(manifest, {arc: file_hash(path) for path, arc in selected})
    selected.append((manifest, "acor_reduced/package_files.sha256.json"))
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, "w:gz") as archive:
        for path, arc in selected:
            archive.add(path, arcname=arc, recursive=False)
    digest = file_hash(out)
    out.with_name(out.name + ".sha256").write_text(f"{digest}  {out.name}\n", encoding="utf-8")
    return {"status": "PACKAGED", "archive": str(out), "sha256": digest, "files": len(selected)}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("prepare", "search", "select", "train", "freeze", "evaluate", "report", "pack", "status"))
    parser.add_argument("--run-root", type=Path, default=ROOT / "runs/acor_reduced")
    parser.add_argument("--data-root", type=Path, default=Path.home() / "wificount/data/wimans/wifi_csi/amp")
    parser.add_argument("--model-seeds", nargs=3, type=int)
    parser.add_argument("--baseline-mode", choices=("retrain",), default="retrain")
    parser.add_argument("--ablation-splits", nargs="+", type=int, default=list(SPLITS))
    parser.add_argument("--device", choices=("cuda", "cpu", "auto"), default="cuda")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    if args.stage == "prepare" and args.model_seeds is None:
        parser.error("prepare requires --model-seeds (split seeds are independently fixed)")
    commands = {"prepare": lambda: prepare(args.run_root, args.data_root, args.model_seeds, args.baseline_mode,
                    args.ablation_splits, args.device, args.workers, args.threads),
        "search": lambda: search(args.run_root), "select": lambda: select(args.run_root),
        "train": lambda: train_runs(args.run_root), "freeze": lambda: freeze(args.run_root),
        "evaluate": lambda: evaluate_runs(args.run_root), "report": lambda: report(args.run_root),
        "pack": lambda: pack(args.run_root, args.output), "status": lambda: status(args.run_root)}
    print(json.dumps({"stage": args.stage, **commands[args.stage]()}, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
