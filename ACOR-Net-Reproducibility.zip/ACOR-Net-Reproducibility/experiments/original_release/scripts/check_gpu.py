"""Fail-fast CUDA runtime check; run on the allocated server GPU before training."""
from __future__ import annotations

import argparse
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path


def check_gpu(device_name="cuda:0"):
    report = {
        "passed": False,
        "python": platform.python_version(),
        "requested_device": device_name,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "scope": "Allocated GPU forward/backward runtime check; not a WiMANS experiment.",
    }
    try:
        import torch

        report.update(torch=str(torch.__version__), cuda_runtime=torch.version.cuda,
                      cuda_available=torch.cuda.is_available(), visible_gpu_count=torch.cuda.device_count())
        if not str(device_name).startswith("cuda"):
            raise ValueError("This check requires --device cuda or cuda:<visible index>; CPU cannot pass it.")
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA unavailable. Check GPU allocation, NVIDIA driver, and the CUDA PyTorch wheel.")
        device = torch.device(device_name)
        prop = torch.cuda.get_device_properties(device)
        report.update(gpu_name=prop.name, gpu_total_memory_bytes=prop.total_memory,
                      compute_capability=f"{prop.major}.{prop.minor}",
                      is_l20="L20" in prop.name.upper())
        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"],
                capture_output=True, text=True, timeout=15, check=False,
            )
            report["nvidia_smi_inventory"] = result.stdout.strip()
        except (OSError, subprocess.TimeoutExpired) as error:
            report["nvidia_smi_note"] = str(error)
        torch.manual_seed(11)
        torch.cuda.reset_peak_memory_stats(device)
        model = torch.nn.Sequential(torch.nn.Conv1d(270, 32, 9, stride=5, padding=4),
                                    torch.nn.GELU(), torch.nn.AdaptiveAvgPool1d(1),
                                    torch.nn.Flatten(), torch.nn.Linear(32, 9)).to(device)
        x = torch.randn(4, 270, 3000, device=device)
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        torch.cuda.synchronize(device)
        start = time.perf_counter()
        loss = model(x).square().mean()
        if not bool(torch.isfinite(loss)):
            raise FloatingPointError("Nonfinite CUDA forward result")
        loss.backward()
        gradients = [p.grad for p in model.parameters() if p.grad is not None]
        if not gradients or not all(bool(torch.isfinite(g).all()) for g in gradients):
            raise FloatingPointError("CUDA backward returned missing or nonfinite gradients")
        if not any(bool(g.ne(0).any()) for g in gradients):
            raise FloatingPointError("All CUDA gradients are zero")
        optimizer.step()
        torch.cuda.synchronize(device)
        report.update(passed=True, forward_loss=float(loss.detach()),
                      backward_gradients_finite=True, optimizer_step_completed=True,
                      elapsed_seconds=time.perf_counter() - start,
                      peak_cuda_memory_bytes=torch.cuda.max_memory_allocated(device))
    except Exception as error:
        report.update(error_type=type(error).__name__, error=str(error))
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output", type=Path, help="Optional JSON report path")
    args = parser.parse_args(argv)
    report = check_gpu(args.device)
    text = json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if report["passed"] else 2


if __name__ == "__main__":
    sys.exit(main())
