#!/usr/bin/env python3
"""Read-only release/environment checks; synthetic forward only, no CSI inference."""
from __future__ import annotations

import argparse
from collections import Counter
import datetime as dt
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import platform
import shutil
import sys

ORIGINAL_PARTITIONS = frozenset({"train", "val_unseen", "val_aux",
                                 "test_seen", "test_unseen", "test_aux"})


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def verify_release(project: Path) -> dict:
    entries = json.loads((project / "release_files.json").read_text(encoding="utf-8"))
    require(isinstance(entries, list) and bool(entries), "Invalid release manifest")
    bad, seen = [], set()
    for item in entries:
        relative = item["path"]
        path = (project / relative).resolve()
        require(path.is_relative_to(project) and path != project,
                f"Unsafe release manifest path: {relative}")
        require(relative not in seen, f"Duplicate release manifest entry: {relative}")
        seen.add(relative)
        if (not path.is_file() or path.stat().st_size != item["bytes"]
                or sha256(path) != item["sha256"]):
            bad.append(relative)
    require(not bad, f"Release files changed or missing: {bad}")
    return {"verified_files": len(entries), "manifest_sha256": sha256(project / "release_files.json"),
            "free_GiB": round(shutil.disk_usage(project).free / 2**30, 2)}


def audit(project: Path, data_root: Path, reference: Path, baseline_mode="retrain") -> dict:
    require(baseline_mode in {"retrain", "reuse-original"}, "Unknown baseline mode")
    report = {
        "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "project": str(project), "data_root": str(data_root),
        "reference_project": str(reference), "baseline_mode": baseline_mode, "python": sys.version,
        "executable": sys.executable, "prefix": sys.prefix,
        "platform": platform.platform(), "conda_prefix": os.environ.get("CONDA_PREFIX"),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "selected_physical_gpu": os.environ.get("ACOR_GPU_INDEX"),
        "selected_gpu_uuid": os.environ.get("ACOR_GPU_UUID"), "checks": [],
        "training_started": False, "formal_holdout_inference": False,
    }

    def check(name, action):
        try:
            item = {"name": name, "ok": True, "detail": action()}
        except Exception as exc:
            item = {"name": name, "ok": False, "error": f"{type(exc).__name__}: {exc}"}
        report["checks"].append(item)
        print(f"[{'PASS' if item['ok'] else 'FAIL'}] {name}: "
              f"{item.get('detail', item.get('error'))}", flush=True)
        return item["ok"]

    def conda():
        expected = Path(os.environ.get("ACOR_EXPECTED_CONDA_PREFIX",
                        str(Path.home() / ".conda/envs/wifi-count"))).resolve()
        prefix = os.environ.get("CONDA_PREFIX", "")
        require(bool(prefix) and Path(prefix).resolve() == expected,
                f"Expected active Conda prefix {expected}, got {prefix!r}")
        require(Path(sys.prefix).resolve() == expected, "Python prefix differs from required environment")
        require(Path(sys.executable).resolve().is_relative_to(expected),
                "Python executable is outside the required environment")
        require(sys.version_info[:2] == (3, 11), "Expected Python 3.11.x")
        require(os.environ.get("PYTHONNOUSERSITE") == "1", "PYTHONNOUSERSITE must be 1")
        return {"python": platform.python_version(), "executable": sys.executable,
                "conda_prefix": prefix, "pythonpath": os.environ.get("PYTHONPATH")}

    def packages():
        expected = {"torch": "2.6.0+cu124", "torchvision": "0.21.0+cu124",
                    "numpy": "2.2.6", "PyYAML": "6.0.2", "pytest": "8.3.5"}
        actual = {name: metadata.version(name) for name in expected}
        report["package_versions"] = actual
        bad = {name: {"expected": version, "actual": actual[name]}
               for name, version in expected.items() if actual[name] != version}
        require(not bad, f"Version mismatch: {bad}; use the preserved wifi-count environment")
        return actual

    def gpu():
        import torch
        import torchvision
        selected_uuid = os.environ.get("ACOR_GPU_UUID")
        require(bool(selected_uuid) and os.environ.get("CUDA_VISIBLE_DEVICES") == selected_uuid,
                "GPU UUID missing or CUDA_VISIBLE_DEVICES does not match the selected GPU")
        require(torch.version.cuda == "12.4", f"Expected CUDA runtime 12.4, got {torch.version.cuda}")
        require(torch.cuda.is_available(), "CUDA is unavailable")
        require(torch.cuda.device_count() == 1, "Exactly one GPU must be exposed")
        value = torch.randn(64, 64, device="cuda")
        require(bool(torch.isfinite(value @ value.T).all()), "CUDA smoke check returned nonfinite values")
        torch.cuda.synchronize()
        props = torch.cuda.get_device_properties(0)
        return {"torch": torch.__version__, "torchvision": torchvision.__version__,
                "cuda_runtime": torch.version.cuda, "gpu": props.name,
                "total_GiB": round(props.total_memory / 2**30, 2),
                "capability": list(torch.cuda.get_device_capability(0)),
                "physical_index": os.environ.get("ACOR_GPU_INDEX"), "uuid": selected_uuid,
                "process_device": "cuda:0"}

    def data():
        sys.path.insert(0, str(project / "src"))
        import wificount
        from wificount.data import WaveformStore, read_manifest
        require(Path(wificount.__file__).resolve().is_relative_to(project / "src"),
                "Imported another wificount installation")
        require(data_root.is_dir(), f"Data directory missing: {data_root}")
        store = WaveformStore(data_root, layout="auto", max_length=3000)
        verified, manifests = set(), []
        for seed in (2026, 2027, 2028):
            relative = Path(f"data/manifests/sample_manifest_seed{seed}.csv")
            manifest, old_manifest = project / relative, reference / relative
            require(old_manifest.is_file(), f"Original manifest missing: {old_manifest}")
            require(sha256(manifest) == sha256(old_manifest), f"Manifest differs from original: seed {seed}")
            rows = read_manifest(manifest)
            counts = Counter(row["partition"] for row in rows)
            require(set(counts) == ORIGINAL_PARTITIONS, f"Missing or unexpected partitions: seed {seed}: {counts}")
            failures = []
            for row in rows:
                if row["record_id"] in verified:
                    continue
                try:
                    store.resolve_path(row)
                    verified.add(row["record_id"])
                except Exception as exc:
                    failures.append(f"{row['record_id']}: {exc}")
            require(not failures, f"{len(failures)} missing waveform paths; first 10: {failures[:10]}")
            manifests.append({"split_seed": seed, "sha256": sha256(manifest),
                              "partition_counts": dict(sorted(counts.items()))})
        return {"source": wificount.__file__, "manifests": manifests,
                "unique_waveform_paths_verified": len(verified), "waveform_contents_checked": False,
                "formal_holdout_inference": False}

    def reference_ready():
        require(reference != project, "Original manifest reference must be a separate preserved project")
        if baseline_mode == "retrain":
            return {"project": str(reference), "baseline_mode": baseline_mode,
                    "original_manifests": "Compared byte-for-byte in data check",
                    "historical_baseline_artifacts_required": False,
                    "reference_modified": False}
        names = ("freeze", "core", "amar_core", "mushot_source_core", "activity_counting_core",
                 "mldg_core", "evaluation_index")
        required = [reference / "runs/plans" / f"{name}.json" for name in names]
        required.append(reference / "src/wificount/engine.py")
        missing = [str(path) for path in required if not path.is_file()]
        require(not missing, f"Original baseline reference files missing: {missing}")
        return {"project": str(reference), "required_plans_found": len(names),
                "full_baseline_verification": "collect_acor_baselines.py runs before training",
                "reference_modified": False}

    def pretrained_model():
        import torch
        from torchvision.models import ConvNeXt_Tiny_Weights
        from wificount.domain_adapters import CONVNEXT_WEIGHTS_URL
        from wificount.v4_model import build_v4_model
        require(ConvNeXt_Tiny_Weights.IMAGENET1K_V1.url == CONVNEXT_WEIGHTS_URL,
                "Unexpected official ConvNeXt weights URL")
        cache = Path(torch.hub.get_dir()) / "checkpoints" / Path(CONVNEXT_WEIGHTS_URL).name
        require(cache.is_file(), f"Pre-cache required official weights before training: {cache}; URL: {CONVNEXT_WEIGHTS_URL}")
        digest = sha256(cache)
        require(digest.startswith("983f1562"), "Cached ConvNeXt weights fail the official SHA256 prefix")
        cfg = json.loads((project / "configs/final_acor.json").read_text(encoding="utf-8"))
        require(cfg["method"] == "ours_v4" and cfg["v4"].get("joint_weight") == 0,
                "Final config must be the frozen ours_v4 joint0 method")
        torch.set_num_threads(4)
        model = build_v4_model(cfg, initialize_pretrained=True).eval().to("cuda")
        with torch.inference_mode():
            output = model(torch.zeros(1, 270, 64, device="cuda"),
                           torch.ones(1, 64, dtype=torch.bool, device="cuda"))
        require(output["regression"].shape == (1, 9) and output["b"].shape == (1, 4),
                "Unexpected synthetic model output dimensions")
        require(all(bool(torch.isfinite(value).all()) for value in output.values()),
                "Synthetic model forward returned nonfinite values")
        torch.cuda.synchronize()
        del model, output
        torch.cuda.empty_cache()
        return {"weights_path": str(cache), "weights_sha256": digest,
                "official_sha256_prefix": "983f1562", "method": "ours_v4", "joint_weight": 0,
                "synthetic_forward": True, "real_data_loaded": False, "training_started": False}

    check("Conda and Python", conda)
    release_ok = check("Release file integrity", lambda: verify_release(project))
    packages_ok = check("Dependency versions", packages)
    gpu_ok = check("PyTorch / torchvision / GPU smoke check", gpu)
    if release_ok:
        data_ok = check("Final source and all three original manifest waveform paths", data)
        check("Preserved original baseline reference availability", reference_ready)
        if data_ok and packages_ok and gpu_ok:
            check("Official pretrained cache and synthetic ACOR forward", pretrained_model)
    report["ok"] = all(item["ok"] for item in report["checks"])
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--data-root", type=Path, default=Path.home() / "wificount/data/wimans/wifi_csi/amp")
    parser.add_argument("--reference-project", type=Path, default=Path.home() / "wificount")
    parser.add_argument("--baseline-mode", choices=("retrain", "reuse-original"), default="retrain")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    report = audit(args.project.resolve(), args.data_root.resolve(), args.reference_project.resolve(), args.baseline_mode)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
    print(f"PREFLIGHT_REPORT={args.output.resolve()}")
    print("ACOR_PREFLIGHT_PASSED" if report["ok"] else "ACOR_PREFLIGHT_FAILED")
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
