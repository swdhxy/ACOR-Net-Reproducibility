"""Memorize 16 deterministic training records to check the data/loss/model chain.

This diagnostic reads training waveforms only. It does not estimate performance
on unseen combinations and its weights must never be used for paper results.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

from wificount.config import load_config, deep_update, write_json
from wificount.data import collate_records
from wificount.engine import build_model, device_for, prepare_data, seed_all
from wificount.objectives import decode, enumerate_counts, supervised_loss


def run_overfit(config, output, steps=300, records=16, threshold=0.9):
    if steps < 1 or records < 1 or not 0 <= threshold <= 1:
        raise ValueError("Need steps>=1, records>=1, and 0<=threshold<=1")
    destination = Path(output).resolve()
    if destination.exists() and any(destination.iterdir()):
        raise FileExistsError(f"Refusing to overwrite diagnostic: {destination}")
    destination.mkdir(parents=True, exist_ok=True)
    cfg = deep_update(config, {"method": "b4", "output": str(destination)})
    write_json(destination / "config.json", cfg)
    seed_all(cfg["model_seed"], cfg["deterministic"], cfg["threads"])
    device = device_for(cfg["device"])
    _, training_records, dataset, _, _, stats = prepare_data(cfg)
    indices = sorted(np.random.default_rng(cfg["model_seed"]).choice(
        len(training_records), size=min(records, len(training_records)), replace=False).tolist())
    batch = collate_records([dataset[i] for i in indices])
    assert all(meta["partition"] == "train" for meta in batch["meta"])
    x, valid, truth = batch["X"].to(device), batch["valid"].to(device), batch["counts"].to(device)
    model = build_model(cfg).to(device)
    candidates = enumerate_counts(9, cfg["model"]["max_occupancy"]).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    history = []
    elapsed_start = time.perf_counter()

    def measure(step):
        model.eval()
        with torch.inference_mode():
            outputs = model.predict_potentials(x, valid)
            loss, _ = supervised_loss(outputs, truth, method="b4", candidates=candidates,
                                      eta=cfg["training"]["eta"], lambda_occ=cfg["training"]["lambda_occ"])
            prediction = decode(outputs, method="b4", candidates=candidates,
                                lambda_occ=cfg["training"]["lambda_occ"])
            exact = float(prediction.eq(truth).all(dim=1).float().mean())
        item = {"step": step, "training_exact_match": exact, "evaluation_mode_loss": float(loss)}
        history.append(item)
        print(json.dumps(item), flush=True)
        return item

    initial = measure(0)
    for step in range(1, steps + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        outputs = model(x, valid)
        loss, _ = supervised_loss(outputs, truth, method="b4", candidates=candidates,
                                  eta=cfg["training"]["eta"], lambda_occ=cfg["training"]["lambda_occ"])
        if not bool(torch.isfinite(loss)):
            raise FloatingPointError(f"Nonfinite loss in overfit diagnostic at step {step}")
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["training"]["gradient_clip"],
                                       error_if_nonfinite=True)
        optimizer.step()
        if step % 25 == 0 or step == steps:
            measure(step)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    final = history[-1]
    report = {
        "passed": final["training_exact_match"] >= threshold,
        "method": "b4", "steps": steps, "learning_rate": 0.001, "optimizer": "Adam",
        "records": len(indices), "record_ids": [training_records[i]["record_id"] for i in indices],
        "selection_seed": cfg["model_seed"], "threshold": threshold,
        "initial_loss": initial["evaluation_mode_loss"], "final_loss": final["evaluation_mode_loss"],
        "loss_ratio": final["evaluation_mode_loss"] / max(initial["evaluation_mode_loss"], 1e-12),
        "training_exact_match": final["training_exact_match"], "all_losses_and_gradients_finite": True,
        "normalization_sha256": stats["normalization_sha256"],
        "normalization_fitted_on": "full training partition, valid points only",
        "test_evaluated": False, "test_waveforms_loaded": False,
        "elapsed_seconds": time.perf_counter() - elapsed_start, "history": history,
        "scope": "Training-only memorization diagnostic. Not held-out performance or paper evidence.",
    }
    write_json(destination / "overfit_report.json", report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/server_l20.yaml")
    parser.add_argument("--output", default="runs/overfit_check")
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--records", type=int, default=16)
    parser.add_argument("--threshold", type=float, default=0.9)
    parser.add_argument("--device", help="Override config device, e.g. cpu for a synthetic software check")
    args = parser.parse_args(argv)
    cfg = load_config(args.config, {"device": args.device} if args.device else None)
    report = run_overfit(cfg, args.output, args.steps, args.records, args.threshold)
    print(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False))
    return 0 if report["passed"] else 2


if __name__ == "__main__":
    sys.exit(main())
