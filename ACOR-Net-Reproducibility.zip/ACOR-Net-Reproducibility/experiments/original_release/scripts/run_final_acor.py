#!/usr/bin/env python3
"""Frozen ACOR-Net formal evaluation: nine fits, then 27 best-checkpoint evaluations.

This driver does not modify the archived V5 model/engine. The test sets are a
previously inspected benchmark, not newly blind holdouts. No architecture or
hyperparameter selection, additional ERM runs, or true-occupancy decoding occurs.
"""
from __future__ import annotations

import argparse
import copy
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import statistics
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from wificount.config import file_hash, fingerprint, validate_config, write_json
from wificount.reporting import METRICS, read_json

SPLITS = (2026, 2027, 2028)
SEEDS = (11, 22, 33)
PARTITIONS = ("test_unseen", "test_seen", "test_aux")
NAME = "ACOR-Net"
SELECTION = "original val_unseen macro exact, then lower positive-count MAE, then earlier epoch"
SCOPE = ("Frozen formal evaluation on previously inspected benchmark partitions; not a new blind test. "
         "No claim that cross-composition contrast improves over same-architecture ERM. "
         "SD across initialization seeds is not independent subject/session uncertainty.")


def now():
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%fUTC")


def immutable_json(path, value):
    path = Path(path)
    if path.exists():
        if read_json(path) != value:
            raise ValueError(f"Refusing to change frozen artifact: {path}")
    else:
        write_json(path, value)


def source_identity():
    paths = [*sorted((ROOT / "src").rglob("*.py")), ROOT / "configs/final_acor.json",
             Path(__file__).resolve()]
    return {str(p.relative_to(ROOT)).replace("\\", "/"): file_hash(p) for p in paths}


def build_plan(run_root, data_root, device="cuda", workers=4, threads=4):
    run_root = Path(run_root).resolve()
    template = read_json(ROOT / "configs/final_acor.json")
    template.pop("development_protocol", None)
    if (template["method"] != "ours_v4" or template["training"]["diagnostic"] != "cross"
            or template["training"]["sampler"] != "controlled"
            or template["training"]["gamma"] != .05 or template["training"]["epochs"] != 60
            or template["training"]["batch_size"] != 16 or template["v4"]["joint_weight"] != 0):
        raise ValueError("The frozen v4_controlled_cross_joint0 template was changed")
    jobs = []
    for split in SPLITS:
        for seed in SEEDS:
            label = f"acor_s{split}_m{seed}"
            cfg = copy.deepcopy(template)
            cfg.update(name=label, split_seed=split, model_seed=seed,
                       manifest=str((ROOT / f"data/manifests/sample_manifest_seed{split}.csv").resolve()),
                       output=str(run_root / "runs" / label), cache_dir=str(run_root / "cache"),
                       data_root=str(Path(data_root).resolve()), data_index=None,
                       device=device, workers=workers, threads=threads)
            validate_config(cfg)
            jobs.append({"id": label, "config": cfg})
    result = {"schema": 1, "method_name": NAME, "variant": "v4_controlled_cross_joint0",
              "stage": "final_formal", "selection_rule": SELECTION,
              "test_used_for_this_confirmation_selection": False, "historical_test_exposure": True,
              "scope": SCOPE, "jobs": jobs, "job_count": 9,
              "expected_evaluations": 27, "checkpoint_policy": "best_only",
              "source_sha256": source_identity(),
              "manifest_sha256": {str(s): file_hash(ROOT / f"data/manifests/sample_manifest_seed{s}.csv")
                                  for s in SPLITS}, "plan_fingerprint": fingerprint(jobs)}
    result["contract_sha256"] = fingerprint(result)
    return result


def load_plan(run_root):
    plan = read_json(Path(run_root) / "plan.json")
    contract = {k: v for k, v in plan.items() if k != "contract_sha256"}
    if plan.get("contract_sha256") != fingerprint(contract):
        raise ValueError("Plan contract changed")
    if (plan.get("plan_fingerprint") != fingerprint(plan["jobs"])
            or len(plan["jobs"]) != 9 or plan.get("checkpoint_policy") != "best_only"):
        raise ValueError("Plan jobs changed")
    expected = {(s, m) for s in SPLITS for m in SEEDS}
    actual = {(j["config"]["split_seed"], j["config"]["model_seed"]) for j in plan["jobs"]}
    if actual != expected or plan["source_sha256"] != source_identity():
        raise ValueError("Source or fixed nine-run design changed; use the original release")
    for job in plan["jobs"]:
        cfg = job["config"]
        if file_hash(cfg["manifest"]) != plan["manifest_sha256"][str(cfg["split_seed"])]:
            raise ValueError("Formal manifest changed")
        if Path(cfg["output"]).resolve() != Path(run_root).resolve() / "runs" / job["id"]:
            raise ValueError("Plan belongs to a different run root; resume in its original location")
    return plan


def audit_data(run_root, plan):
    from wificount.audit import audit_dataset
    from wificount.data import WaveformStore
    from wificount.reporting import _bind_audit
    run_root = Path(run_root)
    index_path = run_root / "audit_index.json"
    if index_path.exists():
        verify_audits(run_root, plan, verify_files=True)
        return
    index = {}
    for split in SPLITS:
        cfg = next(j["config"] for j in plan["jobs"] if j["config"]["split_seed"] == split)
        folder = run_root / "audits" / f"split{split}"
        report_path = folder / "audit.json"
        csv_path = folder / "waveform_audit.csv"
        # A completed audit can survive a later interrupted split audit.
        if not report_path.exists():
            print(f"AUDIT split={split}: full waveform/metadata integrity (no model inference)", flush=True)
            store = WaveformStore(cfg["data_root"], cfg.get("data_index"),
                                  layout=cfg["layout"], max_length=cfg["max_length"])
            audit_dataset(cfg["manifest"], store, folder, no_aux=cfg["no_aux"],
                          max_occupancy=cfg["model"]["max_occupancy"])
        report = read_json(report_path)
        if (not report.get("ok") or not report.get("waveforms_verified")
                or report.get("metadata_only") or report.get("explicit_subset")
                or report.get("manifest_sha256") != plan["manifest_sha256"][str(split)]):
            raise ValueError(f"Full formal data audit failed: {report_path}; inspect it, never auto-exclude records")
        item = {"path": str(report_path.resolve()), "sha256": file_hash(report_path),
                "waveform_csv": str(csv_path.resolve()), "waveform_sha256": file_hash(csv_path)}
        _bind_audit(cfg, item)
        index[str(split)] = item
    immutable_json(index_path, index)
    verify_audits(run_root, plan, verify_files=True)


def verify_audits(run_root, plan, verify_files=True):
    from wificount.reporting import _bind_audit
    index = read_json(Path(run_root) / "audit_index.json")
    if set(index) != {str(s) for s in SPLITS}:
        raise ValueError("Need all three full data audits")
    checked = {}
    for split, item in index.items():
        if (file_hash(item["path"]) != item["sha256"]
                or file_hash(item["waveform_csv"]) != item["waveform_sha256"]):
            raise ValueError("Frozen data audit changed")
        cfg = next(j["config"] for j in plan["jobs"] if str(j["config"]["split_seed"]) == split)
        report = read_json(item["path"])
        if not report.get("ok") or not report.get("waveforms_verified") or report.get("metadata_only"):
            raise ValueError("Data audit is not a full PASS")
        if report["manifest_sha256"] != plan["manifest_sha256"][split]:
            raise ValueError("Audit manifest differs from plan")
        _bind_audit(cfg, item)
        if verify_files:
            with Path(item["waveform_csv"]).open(encoding="utf-8-sig", newline="") as stream:
                for row in csv.DictReader(stream):
                    path = row["path"]
                    if path not in checked:
                        checked[path] = file_hash(path)
                    if checked[path] != row["file_sha256"]:
                        raise ValueError(f"Waveform changed since audit: {path}")
    return index


def prepare(run_root, data_root, device="cuda", workers=4, threads=4):
    plan = build_plan(run_root, data_root, device, workers, threads)
    immutable_json(Path(run_root) / "plan.json", plan)
    for job in plan["jobs"]:
        immutable_json(Path(run_root) / "configs" / f"{job['id']}.json", job["config"])
    audit_data(run_root, plan)
    write_json(Path(run_root) / "prepare_complete.json",
               {"status": "PREPARED", "plan_sha256": file_hash(Path(run_root) / "plan.json"),
                "audit_index_sha256": file_hash(Path(run_root) / "audit_index.json"), "jobs": 9})
    return {"status": "PREPARED", "jobs": 9, "evaluations": 27}


def verify_completed_run(job):
    """Validate committed stopping state and the actual original-val selector."""
    import torch
    from wificount.data import read_manifest, validate_normalization, WaveformStore
    from wificount.engine import early_stopped, metric_key, provenance, verify_run_provenance
    cfg = job["config"]
    folder = Path(cfg["output"])
    saved_cfg = read_json(folder / "config.json")
    summary = read_json(folder / "training_summary.json")
    prov = read_json(folder / "provenance.json")
    stats = read_json(folder / "normalization.json")
    if saved_cfg != cfg:
        raise ValueError(f"Completed config differs from plan: {job['id']}")
    verify_run_provenance(prov, provenance(cfg), job["id"])
    history = [json.loads(line) for line in (folder / "history.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    count = summary["completed_epochs"]
    if count < 1 or [r["epoch"] for r in history] != list(range(1, count + 1)):
        raise ValueError("Completion marker/history epoch sequence disagrees")
    best_key = max(metric_key(row["validation"], row["epoch"] - 1) for row in history)
    if summary["best_epoch"] != -best_key[2] + 1 or summary["best_validation_macro_exact"] != best_key[0]:
        raise ValueError("Summary does not select the original val_unseen best checkpoint")
    selected_metrics = history[summary["best_epoch"] - 1]["validation"]
    if read_json(folder / "validation_best.json") != selected_metrics:
        raise ValueError("Best validation metrics differ from selected history epoch")
    if not (folder / "validation_best.csv").is_file():
        raise ValueError("Missing best validation predictions")
    train_records = [r for r in read_manifest(cfg["manifest"]) if r["partition"] == "train"]
    if summary["training_records"] != len(train_records) or summary.get("test_evaluated") is not False:
        raise ValueError("Training cohort or test-selection marker differs from the formal plan")
    store = WaveformStore(cfg["data_root"], cfg.get("data_index"), layout=cfg["layout"], max_length=cfg["max_length"])
    validate_normalization(stats, train_records, store, verify_files=False)
    for name in ("last", "best"):
        ckpt = torch.load(folder / f"{name}.pt", map_location="cpu", weights_only=True)
        if ckpt["config"] != cfg or ckpt["provenance"] != prov or ckpt["stats"] != stats:
            raise ValueError(f"{name} checkpoint config/provenance/normalization differs")
        if tuple(ckpt["best_key"]) != tuple(best_key):
            raise ValueError(f"{name} checkpoint does not contain the selected validation key")
        if name == "best" and ckpt["epoch"] + 1 != summary["best_epoch"]:
            raise ValueError("Best checkpoint epoch differs from selector")
        if name == "last":
            stopped = early_stopped(count, ckpt["stale"], cfg["training"])
            if ckpt["epoch"] + 1 != count or (count != cfg["training"]["epochs"] and not stopped):
                raise ValueError("Training is not at a committed stopping point")
            if summary["stop_reason"] != ("early_stopping" if stopped else "max_epochs"):
                raise ValueError("Summary stopping reason disagrees with checkpoint")
        del ckpt
    for epoch in range(1, count + 1):
        if not (folder / "pair_logs" / f"epoch_{epoch:03d}.json").is_file():
            raise ValueError(f"Missing training log epoch {epoch}")
        if cfg["training"].get("save_batch_plan") and not (folder / "batch_plans" / f"epoch_{epoch:03d}.json").is_file():
            raise ValueError(f"Missing batch plan epoch {epoch}")
    return summary


def train_runs(run_root):
    from wificount.engine import train
    plan = load_plan(run_root)
    verify_audits(run_root, plan, verify_files=True)
    if (Path(run_root) / "freeze.json").exists():
        verify_freeze(run_root, verify_files=False)
        return {"status": "FROZEN_TRAINING_REUSED", "jobs": 9}
    for i, job in enumerate(plan["jobs"], 1):
        folder = Path(job["config"]["output"])
        print(f"TRAIN {i}/9 {job['id']}", flush=True)
        if not (folder / "training_summary.json").exists():
            last = folder / "last.pt"
            train(job["config"], resume=str(last) if last.exists() else None)
        verify_completed_run(job)
    result = {"status": "ALL_NINE_TRAINED", "jobs": 9,
              "plan_sha256": file_hash(Path(run_root) / "plan.json")}
    write_json(Path(run_root) / "train_complete.json", result)
    return result


def freeze_runs(run_root):
    run_root = Path(run_root)
    if (run_root / "freeze.json").exists():
        verify_freeze(run_root)
        return {"status": "FREEZE_VERIFIED", "jobs": 9}
    plan = load_plan(run_root)
    verify_audits(run_root, plan, verify_files=True)
    frozen_jobs = {}
    for job in plan["jobs"]:
        folder = Path(job["config"]["output"])
        if list(folder.glob("evaluation_test*")):
            raise ValueError("Test artifacts exist before this freeze; preserve them and use a new confirmation root")
        verify_completed_run(job)
        frozen_jobs[job["id"]] = {
            "files": {str(p.relative_to(folder)).replace("\\", "/"): file_hash(p)
                      for p in sorted(folder.rglob("*")) if p.is_file()},
            "runtime": read_json(folder / "provenance.json")}
    frozen = {"schema": 1, "status": "ALL_NINE_FROZEN_BEFORE_THIS_TEST_INFERENCE",
              "created_utc": now(), "plan_sha256": file_hash(run_root / "plan.json"),
              "audit_index_sha256": file_hash(run_root / "audit_index.json"),
              "checkpoint_policy": "best_only", "jobs": frozen_jobs, "scope": SCOPE}
    frozen["contract_sha256"] = fingerprint(frozen)
    immutable_json(run_root / "freeze.json", frozen)
    return {"status": frozen["status"], "jobs": 9}


def verify_freeze(run_root, verify_files=True):
    from wificount.engine import provenance, verify_run_provenance
    run_root = Path(run_root)
    plan = load_plan(run_root)
    frozen = read_json(run_root / "freeze.json")
    if (frozen.get("contract_sha256") != fingerprint({k: v for k, v in frozen.items() if k != "contract_sha256"})
            or frozen.get("schema") != 1 or frozen.get("checkpoint_policy") != "best_only"
            or frozen["plan_sha256"] != file_hash(run_root / "plan.json")
            or frozen["audit_index_sha256"] != file_hash(run_root / "audit_index.json")
            or set(frozen["jobs"]) != {j["id"] for j in plan["jobs"]}):
        raise ValueError("Freeze does not match the complete nine-run plan")
    verify_audits(run_root, plan, verify_files=verify_files)
    for job in plan["jobs"]:
        item = frozen["jobs"][job["id"]]
        required = {"best.pt", "last.pt", "config.json", "provenance.json", "normalization.json",
                    "training_summary.json", "history.jsonl", "validation_best.json", "validation_best.csv"}
        if not required <= set(item["files"]):
            raise ValueError("Frozen run does not bind every required training artifact")
        verify_run_provenance(item["runtime"], provenance(job["config"]), job["id"])
        for name, digest in item["files"].items():
            if Path(name).is_absolute() or ".." in Path(name).parts:
                raise ValueError("Unsafe relative path in freeze")
            if file_hash(Path(job["config"]["output"]) / name) != digest:
                raise ValueError(f"Frozen training artifact changed: {job['id']}/{name}")
    return plan, frozen


def evaluate_runs(run_root):
    from wificount.engine import evaluate
    from wificount.reporting import verify_evaluation
    plan, frozen = verify_freeze(run_root, verify_files=True)
    rows = []
    for job in plan["jobs"]:
        cfg = job["config"]
        folder = Path(cfg["output"])
        for partition in PARTITIONS:
            destination = folder / f"evaluation_{partition}"
            print(f"EVALUATE {len(rows)+1}/27 {job['id']} {partition}", flush=True)
            if not destination.exists():
                evaluate(folder / "best.pt", partition, destination, device=cfg["device"])
            verify_evaluation(destination, folder / "best.pt", partition=partition, cfg=cfg,
                              runtime=frozen["jobs"][job["id"]]["runtime"])
            rows.append({"job": job["id"], "partition": partition, "checkpoint": "best",
                         "completion_sha256": file_hash(destination / "evaluation_complete.json")})
    result = {"status": "ALL_27_EVALUATIONS_VERIFIED", "evaluations": rows,
              "freeze_sha256": file_hash(Path(run_root) / "freeze.json"), "scope": SCOPE}
    write_json(Path(run_root) / "evaluation_index.json", result)
    return {"status": result["status"], "evaluations": len(rows)}


def write_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError("Refusing to write an empty final table")
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def aggregate_rows(rows, across_splits=False):
    groups = {}
    keys = ("method", "partition") if across_splits else ("method", "split_seed", "partition")
    for row in rows:
        groups.setdefault(tuple(row[k] for k in keys), []).append(row)
    result = []
    for key, group in sorted(groups.items()):
        out = dict(zip(keys, key))
        out["runs"] = len(group)
        out["aggregation"] = "descriptive_equal_run_mean" if across_splits else "initialization_mean_sd"
        for metric in METRICS:
            values = [r[metric] for r in group if r[metric] is not None]
            out[f"{metric}_mean"] = statistics.mean(values) if values else None
            out[f"{metric}_sd"] = statistics.stdev(values) if len(values) > 1 else None
        result.append(out)
    return result


def baseline_rows(run_root, plan):
    path = Path(run_root) / "baseline_reference/summary.json"
    if not path.exists():
        return [], "PENDING_BASELINE_COLLECTION"
    result = read_json(path)
    if (result.get("status") != "BASELINES_VERIFIED" or result.get("jobs") != 81
            or result.get("evaluation_rows") != 243 or len(result.get("rows", [])) != 243
            or result.get("manifest_sha256") != plan["manifest_sha256"]
            or result.get("original_freeze_sha256") != "7840aa464718d287872206881d0c1f0e594e739afce416500fd780867dada0e6"):
        raise ValueError("Baseline snapshot is incomplete or uses different formal manifests")
    baseline_root = path.parent.resolve()
    def evidence(relative):
        candidate = (baseline_root / relative).resolve()
        if not candidate.is_relative_to(baseline_root) or Path(relative).is_absolute():
            raise ValueError("Unsafe baseline evidence path")
        return candidate
    artifacts = result.get("artifact_sha256")
    if not artifacts:
        raise ValueError("Baseline snapshot lacks artifact hashes")
    for relative, digest in artifacts.items():
        if file_hash(evidence(relative)) != digest:
            raise ValueError(f"Baseline snapshot artifact changed: {relative}")
    methods = ("b1", "b2", "b3", "b4", "b5", "amar", "mushot_source", "activity_counting", "mldg")
    expected = {(m, s, seed, p) for m in methods for s in SPLITS for seed in SEEDS for p in PARTITIONS}
    actual = {(r["method"], r["split_seed"], r["model_seed"], r["partition"]) for r in result["rows"]}
    if actual != expected:
        raise ValueError("Baseline rows do not cover the fixed nine-method/three-split/three-seed protocol")
    rows = []
    for row in result["rows"]:
        relative = row["artifact_dir"].rstrip("/")
        metric_path = relative + "/metrics.json"
        prov_path = relative + "/evaluation_provenance.json"
        if metric_path not in artifacts or prov_path not in artifacts:
            raise ValueError("Baseline row is not covered by the evidence hashes")
        m = read_json(evidence(metric_path))
        prov = read_json(evidence(prov_path))
        if (m != row["metrics"] or prov["partition"] != row["partition"]
                or prov["epoch"] != row["epoch"] or prov["checkpoint_sha256"] != row["checkpoint_sha256"]
                or any(prov["config"][key] != row[key] for key in ("method", "split_seed", "model_seed"))):
            raise ValueError("Baseline summary row differs from frozen evaluation evidence")
        rows.append({"method": row["method"], "split_seed": row["split_seed"],
                     "model_seed": row["model_seed"], "partition": row["partition"],
                     "checkpoint": "best", "epoch": row["epoch"],
                     "records": m["denominators_and_numerators"]["samples"],
                     "source": "verified_historical_baseline", **{k: m[k] for k in METRICS}})
    return rows, "BASELINES_VERIFIED"


def report(run_root):
    from wificount.reporting import verify_evaluation
    plan, frozen = verify_freeze(run_root, verify_files=False)
    rows = []
    for job in plan["jobs"]:
        cfg = job["config"]
        folder = Path(cfg["output"])
        epoch = read_json(folder / "training_summary.json")["best_epoch"]
        for partition in PARTITIONS:
            destination = folder / f"evaluation_{partition}"
            verify_evaluation(destination, folder / "best.pt", partition=partition, cfg=cfg,
                              runtime=frozen["jobs"][job["id"]]["runtime"])
            m = read_json(destination / "metrics.json")
            rows.append({"method": NAME, "split_seed": cfg["split_seed"], "model_seed": cfg["model_seed"],
                         "partition": partition, "checkpoint": "best", "epoch": epoch,
                         "records": m["denominators_and_numerators"]["samples"],
                         "source": "fixed_final_formal_evaluation", **{k: m[k] for k in METRICS}})
    baselines, baseline_status = baseline_rows(run_root, plan)
    folder = Path(run_root) / "reports"
    combined = rows + baselines
    write_csv(folder / "acor_all_runs.csv", rows)
    write_csv(folder / "acor_per_split.csv", aggregate_rows(rows))
    write_csv(folder / "main_table_all_runs.csv", combined)
    write_csv(folder / "main_table_per_split.csv", aggregate_rows(combined))
    write_csv(folder / "main_table_descriptive_across_splits.csv", aggregate_rows(combined, True))
    profile_path = Path(run_root) / "profile/inference_latency.json"
    latency = "NOT_RUN; do not claim deployment latency advantage"
    if profile_path.exists():
        profile = read_json(profile_path)
        if profile.get("status") != "complete" or profile.get("freeze_sha256") != file_hash(Path(run_root) / "freeze.json"):
            raise ValueError("Latency profile is incomplete or belongs to another frozen study")
        latency = {"path": "profile/inference_latency.json", "sha256": file_hash(profile_path),
                   "measurements": profile.get("measurements"),
                   "scope": "One frozen model; preloaded input forward/decode only, excluding IO and normalization. No baseline speed claim."}
    result = {"status": "FINAL_TABLES_COMPLETE" if baselines else "ACOR_COMPLETE_BASELINES_PENDING",
              "acor_jobs": 9, "acor_evaluation_rows": 27, "baseline_status": baseline_status,
              "baseline_evaluation_rows": len(baselines), "selection_rule": SELECTION,
              "freeze_sha256": file_hash(Path(run_root) / "freeze.json"), "scope": SCOPE,
              "latency_benchmark": latency,
              "ablation_scope": "Existing development ablations remain separate; no new ERM/within fits"}
    write_json(folder / "summary.json", result)
    (folder / "README.md").write_text(
        "# ACOR-Net frozen formal evaluation\n\n" + SCOPE + "\n\n"
        "Selection: " + SELECTION + ".\n\n"
        "`main_table_per_split.csv` is the primary comparison table (3 initializations per split). "
        "The across-split table is descriptive; overlapping benchmark splits are not independent subjects. "
        "Do not choose a new model or hyperparameter using these test results. Baselines are historical "
        "task-adapted implementations; they are not author-reported WiMANS results.\n\n"
        "No additional same-architecture ERM/within experiments are scheduled. Earlier internal "
        "development ablations must not be merged into the formal test table. Optional model latency "
        "is recorded separately in summary.json and cannot establish speed superiority over baselines.\n", encoding="utf-8")
    return result


def status(run_root):
    """A filesystem inventory only, explicitly not a completion verification."""
    root = Path(run_root)
    return {"status": "INVENTORY_ONLY_NOT_VERIFIED", "run_root": str(root.resolve()),
            "plan_present": (root / "plan.json").is_file(), "freeze_present": (root / "freeze.json").is_file(),
            "training_markers": len(list((root / "runs").glob("*/training_summary.json"))),
            "evaluation_markers": len(list((root / "runs").glob("*/evaluation_test*/evaluation_complete.json"))),
            "report": read_json(root / "reports/summary.json") if (root / "reports/summary.json").exists() else None}


def pack(run_root, output=None):
    root = Path(run_root).resolve()
    if not root.is_dir():
        raise ValueError(f"No result directory to package: {root}")
    out = Path(output).resolve() if output else root.parent / f"acor-results-{now()}.tar.gz"
    if out.exists():
        raise FileExistsError(f"Refusing to overwrite result archive: {out}")
    inventory = status(root)
    inventory.update(packaged_utc=now(), excluded="checkpoints, cache, raw CSI, Python bytecode",
                     scope=SCOPE, server_checkpoints_retained=True)
    write_json(root / "package_inventory.json", inventory)
    allowed = {".json", ".jsonl", ".csv", ".npz", ".npy", ".md", ".txt", ".log", ".yaml", ".yml", ".sha256"}
    selected = []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if (path.is_file() and not path.is_symlink() and "cache" not in rel.parts
                and "__pycache__" not in rel.parts and path.suffix.lower() in allowed
                and path not in (out, out.with_name(out.name + ".sha256"))
                and path.name != "package_files.sha256.json"):
            # .npz/.npy are allowed only in explicit result folders, never raw waveform trees.
            if path.suffix.lower() in {".npz", ".npy"} and not any("evaluation" in p or "prediction" in p for p in rel.parts):
                continue
            selected.append((path, "final_acor/" + rel.as_posix()))
    for relative in ("src", "configs", "data/manifests", "scripts"):
        for path in sorted((ROOT / relative).rglob("*")):
            if path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts:
                selected.append((path, "release/" + path.relative_to(ROOT).as_posix()))
    hash_path = root / "package_files.sha256.json"
    write_json(hash_path, {arc: file_hash(path) for path, arc in selected})
    selected.append((hash_path, "final_acor/package_files.sha256.json"))
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, "w:gz") as archive:
        for path, arc in selected:
            archive.add(path, arcname=arc, recursive=False)
    digest = file_hash(out)
    out.with_name(out.name + ".sha256").write_text(f"{digest}  {out.name}\n", encoding="utf-8")
    return {"status": "PACKAGED", "archive": str(out), "sha256": digest,
            "files": len(selected), "run_status": inventory["status"]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("prepare", "train", "freeze", "evaluate", "report", "pack", "status", "all"))
    parser.add_argument("--run-root", type=Path, default=ROOT / "runs/final_acor")
    parser.add_argument("--data-root", type=Path, default=Path("${CSI_ROOT}"))
    parser.add_argument("--device", default="cuda", choices=("cuda", "cpu", "auto"))
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--output", type=Path, help="pack destination .tar.gz (default: timestamped sibling of run root)")
    args = parser.parse_args(argv)
    root = args.run_root.resolve()
    commands = {"prepare": lambda: prepare(root, args.data_root, args.device, args.workers, args.threads),
                "train": lambda: train_runs(root), "freeze": lambda: freeze_runs(root),
                "evaluate": lambda: evaluate_runs(root), "report": lambda: report(root),
                "pack": lambda: pack(root, args.output), "status": lambda: status(root)}
    stages = ("prepare", "train", "freeze", "evaluate", "report", "pack") if args.stage == "all" else (args.stage,)
    for stage in stages:
        print(json.dumps({"stage": stage, **commands[stage]()}, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
