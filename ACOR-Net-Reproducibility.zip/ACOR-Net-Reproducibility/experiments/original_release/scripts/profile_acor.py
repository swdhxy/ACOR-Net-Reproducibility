"""Bounded CUDA latency measurement for the fixed ACOR-Net architecture.

Uses the first frozen formal checkpoint and preloaded training inputs. No fitting,
checkpoint selection, test-data access, or baseline speed comparison is performed.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import platform
import sys
import time

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

import numpy as np
import torch

from wificount.config import file_hash, write_json
from wificount.data import collate_records
from wificount.engine import build_model, decode_outputs, prepare_data, seed_all
from wificount.objectives import enumerate_counts


def summarize_times(values):
    data = np.asarray(values, dtype=float)
    if data.ndim != 1 or len(data) < 2 or not np.all(np.isfinite(data)) or np.any(data <= 0):
        raise ValueError("Need at least two finite positive timing samples")
    return {"mean": float(data.mean()), "median": float(np.median(data)),
            "p95": float(np.percentile(data, 95)), "minimum": float(data.min()),
            "std": float(data.std(ddof=1)), "n": len(data)}


def validate_options(warmup, iterations, batches):
    if warmup < 1 or iterations < 2 or not batches or any(b < 1 for b in batches):
        raise ValueError("Require warmup>=1, iterations>=2 and positive batch sizes")
    if len(set(batches)) != len(batches):
        raise ValueError("Batch sizes must be unique")


def profile(run_root, device="cuda", warmup=20, iterations=100, batches=(1, 16)):
    from run_acor_study import verify_freeze
    validate_options(warmup, iterations, batches)
    run_root = Path(run_root).resolve()
    plan, frozen = verify_freeze(run_root, verify_files=False)
    if not device.startswith("cuda") or not torch.cuda.is_available():
        raise RuntimeError("This resource measurement requires CUDA; no CPU substitution")
    if torch.cuda.device_count() != 1:
        raise RuntimeError("Expose exactly one physical GPU through CUDA_VISIBLE_DEVICES")
    dev = torch.device(device)
    if dev.index not in (None, 0):
        raise ValueError("The selected physical GPU is process-local cuda:0")
    job = next(j for j in plan["jobs"] if j["role"] == "main"
               and j["method"] == "ours_v4" and j["config"]["split_seed"] == 2026
               and j["config"]["model_seed"] == plan["model_seeds"][0])
    checkpoint_path = Path(job["config"]["output"]) / "best.pt"
    checkpoint_hash = file_hash(checkpoint_path)
    protocol = {"freeze_sha256": file_hash(run_root / "freeze.json"),
                "checkpoint_sha256": checkpoint_hash, "job_id": job["id"],
                "script_sha256": file_hash(__file__), "warmup": warmup,
                "iterations": iterations, "batches": list(batches),
                "gpu_name": torch.cuda.get_device_name(0),
                "visible_device": os.environ.get("CUDA_VISIBLE_DEVICES"),
                "torch": str(torch.__version__), "cuda": torch.version.cuda,
                "python": platform.python_version(), "device": "cuda:0"}
    destination = run_root / "profile/inference_latency.json"
    if destination.exists():
        previous = json.loads(destination.read_text(encoding="utf-8"))
        if previous.get("status") != "complete" or previous.get("protocol") != protocol:
            raise ValueError("Existing profile has a different protocol; preserve it and use a new output path")
        print("PROFILE_REUSED", destination)
        return previous
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
    cfg = checkpoint["config"]
    if cfg["method"] != "ours_v4" or cfg.get("development_protocol") or cfg["v4"]["joint_weight"] != 0:
        raise ValueError("Expected the frozen formal ACOR-Net joint0 checkpoint")
    seed_all(cfg["model_seed"], cfg["deterministic"], cfg["threads"])
    _, _, train_ds, _, _, _ = prepare_data(cfg, stats=checkpoint["stats"])
    if len(train_ds) < max(batches):
        raise ValueError("Not enough training inputs for the requested batch sizes")
    # Read and normalize once, outside both timers. The inference call gets no labels.
    examples = [train_ds[i] for i in range(max(batches))]
    model = build_model(cfg, initialize_pretrained=False).to(dev)
    model.load_state_dict(checkpoint["model"], strict=True)
    model.eval()
    candidates = enumerate_counts(K=9, M=cfg["model"]["max_occupancy"]).to(dev)
    total_parameters = sum(p.numel() for p in model.parameters())
    projector_parameters = sum(p.numel() for p in model.contrast_projector.parameters())
    measurements = []
    with torch.inference_mode():
        for batch_size in batches:
            batch = collate_records(examples[:batch_size])
            x, valid = batch["X"].to(dev), batch["valid"].to(dev)

            def forward():
                return decode_outputs(model.predict_potentials(x, valid), cfg, candidates)

            for _ in range(warmup):
                forward()
            torch.cuda.synchronize(dev)
            torch.cuda.reset_peak_memory_stats(dev)
            gpu_ms, wall_ms = [], []
            first, last = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            for _ in range(iterations):
                torch.cuda.synchronize(dev)
                start = time.perf_counter()
                first.record()
                prediction = forward()
                last.record()
                torch.cuda.synchronize(dev)
                wall_ms.append((time.perf_counter() - start) * 1000)
                gpu_ms.append(first.elapsed_time(last))
            if prediction.shape != (batch_size, 9) or not torch.isfinite(prediction).all():
                raise ValueError("Unexpected prediction shape or values during profiling")
            summary = summarize_times(wall_ms)
            measurements.append({"batch_size": batch_size, "input_shape": list(x.shape),
                "gpu_event_ms_per_batch": summarize_times(gpu_ms),
                "synchronized_wall_ms_per_batch": summary,
                "mean_wall_ms_per_record_amortized": summary["mean"] / batch_size,
                "records_per_second_from_mean_wall": batch_size * 1000 / summary["mean"],
                "peak_allocated_bytes": torch.cuda.max_memory_allocated(dev),
                "peak_reserved_bytes": torch.cuda.max_memory_reserved(dev),
                "raw_gpu_event_ms": gpu_ms, "raw_synchronized_wall_ms": wall_ms})
            del x, valid, prediction
    result = {"status": "complete", "protocol": protocol,
        "freeze_sha256": protocol["freeze_sha256"], "parameters_total": total_parameters,
        "training_only_projector_parameters": projector_parameters,
        "parameters_used_for_inference": total_parameters - projector_parameters,
        "input_record_ids": [item["meta"]["record_id"] for item in examples],
        "input_partition": "train", "labels_used_in_timing": False,
        "includes": ["CSI spatial projection", "ConvNeXt", "action count and occupancy heads", "220-candidate decoder"],
        "excludes": ["disk IO", "log1p and normalization", "host-to-device transfer", "model loading", "contrast projector"],
        "scope": "One fixed checkpoint, preloaded real training inputs; resource description only, no baseline speed claim",
        "measurements": measurements}
    write_json(destination, result)
    print("PROFILE_COMPLETE", destination)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--warmup", type=int, default=20)
    parser.add_argument("--iterations", type=int, default=100)
    parser.add_argument("--batches", nargs="+", type=int, default=[1, 16])
    args = parser.parse_args()
    profile(args.run_root, args.device, args.warmup, args.iterations, args.batches)


if __name__ == "__main__":
    main()
