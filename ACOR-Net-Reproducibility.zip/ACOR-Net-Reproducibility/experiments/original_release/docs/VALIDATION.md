# Reduced release validation

Validated locally on 2026-11-02. This is software validation, not completion of server experiments.

- **67 focused regression checks passed**: reduced controller/reporting, checkpoint-completion helpers, fixed-weight sensitivity, profiling helpers, and launcher/preflight checks. Evidence: output/analysis/acor_reduced_20261102/final_tests.log in the author workspace.
- The active matrix contains only ACOR-Net, AMAR, MU-SHOT-Fi source-only, ActivityCounting and MLDG. B1–B5 cannot enter through the method template or selected-plan builder. Their obsolete baseline template JSON files are removed from this new release. Historical source helpers and software tests remain for compatibility; the launcher does not schedule those methods.
- All original split manifests are unchanged. Every search candidate and trained variant uses model seeds 2026/2027/2028. The published command schedules all three component ablations across all three original splits.
- Matrix: 48 candidate configurations x 3 initializations = **144 search fits**. All **45 main best checkpoints** reuse selected search runs. At most **27 additional component fits**, for **171 independent fits** maximum. Main evaluation rows: 135; new component evaluation rows: 81; total regular evaluation rows: 216. The ablation table displays 108 rows because it also repeats the 27 Full reference rows. Fixed-weight sensitivity has 27 separate rows.
- The report validates the complete five-method/split/seed/partition set, not only row count. Tests reject removed methods, duplicates and malformed selections. The single predeclared primary paired-bootstrap comparison is ACOR-Net versus ActivityCounting, with 2000 replicates within each split. No baseline is chosen using test performance.
- Tests cover three-seed mean selection rather than best-seed selection, component changes, zero-gamma equivalent-run reuse, source/configuration drift, resume, whole-study freeze before test, interrupted evaluation preservation, corrupt-completion rejection, metric reconstruction and packaging.
- Neural model and training-engine source files are byte-identical to the preceding full-study release. Architecture and ablation implementation are unchanged. The package builder checks this identity, original-manifest hashes, Python syntax, per-file release hashes and round-trip archive hashes.
- No real CSI inference, GPU training or formal test was executed locally. This Windows host has no usable Bash/WSL, so Bash syntax and shell execution are not claimed as locally tested. Server instructions run bash -n, then strict environment and GPU preflight before training.

Pinned server runtime: Python 3.11.x, torch 2.6.0+cu124, torchvision 0.21.0+cu124, NumPy 2.2.6, PyYAML 6.0.2, pytest 8.3.5. Physical GPU5 is resolved to its UUID and exposed as process-local cuda:0.

Use the independent wificount_acor_reduced_20261102 project and runs/acor_reduced result directory. Do not overwrite an existing full-study protocol or describe excluded methods as part of this study. All gains and component conclusions remain pending actual results.
