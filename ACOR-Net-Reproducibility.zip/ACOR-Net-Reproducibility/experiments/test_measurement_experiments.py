import sys
from pathlib import Path
import torch
import measurement_experiments as m

PROJECT=Path(__file__).resolve().parent/'original_release'
sys.path.insert(0,str(PROJECT/'src'))
from wificount.objectives import enumerate_counts
from wificount.v4_objectives import decode_v4

def test_soft_decoder_matches_original():
    torch.manual_seed(9)
    out={'regression':torch.rand(11,9)*2,'b':torch.randn(11,4)}
    candidates=enumerate_counts(9,3)
    expected=decode_v4(out,{'v4':{'joint_weight':0,'temperature':1,'lambda_occ':.25}},candidates)
    assert torch.equal(expected,m.decode(out,candidates,'soft'))
    assert torch.equal(m.decode(out,candidates,'hard').sum(-1),out['b'].argmax(-1))
    for mode in ['legal','soft']:
        p=m.decode(out,candidates,mode)
        assert bool((p>=0).all()) and bool((p.sum(-1)<=3).all())

def test_missing_observations_are_paired_and_ordered():
    x=torch.arange(60).reshape(3,20).float();v=torch.zeros(20,dtype=torch.bool);v[-15:]=True
    a,av=m.thin(x,v,'record',.1,20261);b,bv=m.thin(x,v,'record',.3,20261)
    aa,aav=m.thin(x,v,'record',.1,20261)
    assert torch.equal(a,aa) and torch.equal(av,aav)
    assert int(av.sum())==13 and int(bv.sum())==11
    assert bool((a[0,av][1:]>a[0,av][:-1]).all())
    assert set(b[0,bv].tolist())<=set(a[0,av].tolist())
    assert not bool(a[:,~av].any())

def test_matched_head_can_train_without_pretrained_download():
    from torch import nn
    from wificount import domain_adapters
    original=domain_adapters.ActivityCountingAdapter
    class SmallBackbone(nn.Module):
        def __init__(self):super().__init__();self.linear=nn.Linear(3,40)
        def forward(self,x):return self.linear(x.mean((-2,-1)))
    domain_adapters.ActivityCountingAdapter=lambda initialize_pretrained:original(backbone=SmallBackbone(),feature_dim=40,warp_probability=0)
    try:
        _,engine=m.activate(PROJECT)
        cfg={'method':'ours_v4','measurement_extension':{'script_sha256':m.SHA},
             'v4':{'joint_weight':0,'occupancy_weight':.25,'lambda_occ':.25},'training':{'learning_rate':.001,'weight_decay':.01}}
        model=engine.build_model(cfg,initialize_pretrained=False)
        x=torch.randn(2,270,30);valid=torch.ones(2,30,dtype=torch.bool)
        out=model(x,valid)
        from wificount.v4_objectives import v4_supervised_loss
        counts=torch.tensor([[1,1,0,0,0,0,0,0,0],[0,0,1,1,1,0,0,0,0]])
        loss,_=v4_supervised_loss(out,counts,cfg)
        loss.backward()
        assert model.occupancy_head.weight.grad.abs().sum()>0
        assert model.head.weight.grad.abs().sum()>0
        assert model.backbone.linear.weight.grad.abs().sum()>0
        engine.make_optimizer(model,cfg).step()
    finally:domain_adapters.ActivityCountingAdapter=original
