"""Reproduce frozen-result tables without CSI, checkpoints, GPU, or third-party packages."""
from pathlib import Path
import subprocess,sys,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def main():
    for name in ['analyze_existing.py','scripts/score_archived_models.py','experiments/verify_results.py','experiments/paired_intervals.py','followup/verify_followup.py']:
        print('Running',name,flush=True)
        subprocess.run([sys.executable,str(ROOT/name)],cwd=ROOT,check=True)
    print('Frozen prediction metrics, original post hoc tables, paired intervals, and follow-up diagnostics verified.')
if __name__=='__main__':main()
