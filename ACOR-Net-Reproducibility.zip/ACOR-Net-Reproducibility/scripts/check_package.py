from pathlib import Path
import argparse,csv,json,hashlib,re
ROOT=Path(__file__).resolve().parents[1]
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
    p=argparse.ArgumentParser();p.add_argument('--rebuilt-splits',type=Path);a=p.parse_args()
    sums=ROOT/'SHA256SUMS.json';checked=0
    if sums.exists():
        for rel,digest in json.loads(sums.read_text()).items():
            assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest,rel;checked+=1
    else:raise FileNotFoundError('SHA256SUMS.json is required')
    if a.rebuilt_splits:
        for seed in [2026,2027,2028]:
            for kind in ['sample','combo']:
                name=f'{kind}_manifest_seed{seed}.csv'
                assert rows(a.rebuilt_splits/name)==rows(ROOT/'reproducibility/manifests'/name),name
        print('All six regenerated manifests match the frozen CSV rows.')
    print('Verified',checked,'distributed file digests.')
if __name__=='__main__':main()
