from pathlib import Path
import argparse,sys,importlib.util
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument('--checkpoint',required=True);p.add_argument('--data-root',required=True);p.add_argument('--output',required=True);p.add_argument('--device',default='auto');p.add_argument('--partition',default='test_unseen');a=p.parse_args()
    sys.path.insert(0,str(ROOT/'experiments/original_release/src'))
    import torch
    checkpoint=torch.load(a.checkpoint,map_location='cpu',weights_only=True)
    if checkpoint['config'].get('measurement_extension'):
        path=ROOT/'experiments/measurement_experiments.py'
        spec=importlib.util.spec_from_file_location('measurement_extension',path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        _,engine=mod.activate(ROOT/'experiments/original_release')
    else:from wificount import engine
    result=engine.evaluate(a.checkpoint,partition=a.partition,output=a.output,data_root=a.data_root,device=a.device)
    print(result)
if __name__=='__main__':main()
