"""Build metadata-only candidate composition splits; no CSI or outcomes are read.

Python 3.10+, standard library only. All design choices are frozen below.
Use --input path --output path to reproduce against the same annotation SHA-256.
"""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import math
import pathlib
import random

SEEDS = (2026, 2027, 2028)
TARGETS = {2: (22, 7, 7), 3: (32, 11, 11)}
COMBO_SPLITS = ("train_combo", "val_unseen", "test_unseen")
SEARCH_DRAWS = 10000
SEEN_FRACTION = 0.20
ACTIVITIES = tuple(sorted(("nothing", "walk", "rotation", "jump", "wave", "lie_down", "pick_up", "sit_down", "stand_up")))


def combo(row):
    return tuple(sorted(row[f"user_{i}_activity"] for i in range(1, 7) if row[f"user_{i}_activity"]))


def combo_id(c):
    counts = collections.Counter(c)
    return ";".join(f"{a}:{counts[a]}" for a in ACTIVITIES if counts[a]) or "EMPTY"


def stable_rng(seed, text):
    digest = hashlib.sha256(f"{seed}|{text}".encode()).digest()
    return random.Random(int.from_bytes(digest[:8], "big"))


def count_support(combos):
    return {(a, count) for c in combos for a, count in collections.Counter(c).items()}


def assign_combos(groups, n, seed):
    """Fixed random search with hard count support and frozen metadata objective."""
    rng = stable_rng(seed, f"combo-search-{n}")
    all_c = sorted(groups)
    anchors = [c for c in all_c if len(set(c)) == 1]
    mixed = [c for c in all_c if len(set(c)) > 1]
    target = TARGETS[n]
    assert len(anchors) == 9 and len(all_c) == sum(target)
    required = count_support(all_c)
    total_records = sum(len(groups[c]) for c in all_c)
    overall_action = collections.Counter(a for c in all_c for _ in groups[c] for a in c)
    total_persons = sum(overall_action.values())
    global_dist = [overall_action[a] / total_persons for a in ACTIVITIES]
    features = {c: (len(groups[c]), [len(groups[c]) * c.count(a) for a in ACTIVITIES]) for c in all_c}
    best = None
    feasible = 0
    for iteration in range(SEARCH_DRAWS):
        rng.shuffle(mixed)
        cut = target[0] - len(anchors)
        proposal = (anchors + mixed[:cut], mixed[cut:cut + target[1]], mixed[cut + target[1]:])
        if not required <= count_support(proposal[0]):
            continue
        feasible += 1
        # Record imbalance plus person-weighted action marginal total variation.
        # These are annotation statistics, never predictive/model outcomes.
        score = 0.0
        for j, cs in enumerate(proposal):
            size = sum(features[c][0] for c in cs)
            expected = target[j] / sum(target)
            score += abs(size / total_records - expected)
            dist = [sum(features[c][1][k] for c in cs) / (size * n) for k in range(len(ACTIVITIES))]
            score += 0.5 * sum(abs(p - q) for p, q in zip(dist, global_dist))
        key = (round(score, 14), tuple(tuple(sorted(cs)) for cs in proposal))
        if best is None or key < best[0]:
            best = (key, tuple(tuple(sorted(cs)) for cs in proposal), iteration)
    if best is None:
        raise RuntimeError(f"No feasible assignment for n={n}; do not relax the count-support constraint silently")
    mapping = {c: split for split, cs in zip(COMBO_SPLITS, best[1]) for c in cs}
    return mapping, {"objective": best[0][0], "selected_iteration": best[2], "feasible_candidates": feasible, "draws": SEARCH_DRAWS}


def partition_records(rows, mapping, seed):
    """Never divide an annotation record; downstream windows inherit its split."""
    assigned = {}
    pools = collections.defaultdict(list)
    for row in rows:
        n = int(row["number_of_users"])
        c = combo(row)
        if n >= 4:
            assigned[row["label"]] = "excluded_4_5"
        elif n <= 1:
            pools[("aux", n, c, row["environment"], row["wifi_band"])].append(row)
        elif mapping[n][c] == "train_combo":
            pools[("seen", n, c, row["environment"], row["wifi_band"])].append(row)
        else:
            assigned[row["label"]] = mapping[n][c]
    for key, pool in sorted(pools.items()):
        pool.sort(key=lambda r: r["label"])
        stable_rng(seed, repr(key)).shuffle(pool)
        if key[0] == "aux":
            # Largest-remainder rounding, ties train -> validation -> test.
            ratios = (0.6, 0.2, 0.2)
            sizes = [math.floor(len(pool) * r) for r in ratios]
            order = sorted(range(3), key=lambda j: (-(len(pool) * ratios[j] - sizes[j]), j))
            for j in order[:len(pool) - sum(sizes)]:
                sizes[j] += 1
            names = ("train", "val_aux", "test_aux")
            start = 0
            for name, size in zip(names, sizes):
                for row in pool[start:start + size]:
                    assigned[row["label"]] = name
                start += size
        else:
            # At least one record must remain in training and in seen testing.
            assert len(pool) >= 2
            seen_size = min(len(pool) - 1, max(1, int(math.floor(len(pool) * SEEN_FRACTION + 0.5))))
            for j, row in enumerate(pool):
                assigned[row["label"]] = "test_seen" if j < seen_size else "train"
    assert len(assigned) == len(rows)
    return assigned


def support_features(row):
    people = [(i, row[f"user_{i}_location"], row[f"user_{i}_activity"]) for i in range(1, 7) if row[f"user_{i}_activity"]]
    return {
        "identity_set": tuple(i for i, _, _ in people),
        "identity_location_profile": tuple((i, loc) for i, loc, _ in people),
        "location_multiset": tuple(sorted(loc for _, loc, _ in people)),
        "identity_action_pairs": tuple((i, act) for i, _, act in people),
    }


def summarize(rows):
    action_counts = {a: collections.Counter(combo(r).count(a) for r in rows) for a in ACTIVITIES}
    return {
        "records": len(rows),
        "by_occupancy": dict(sorted(collections.Counter(int(r["number_of_users"]) for r in rows).items())),
        "by_environment_band": dict(sorted(collections.Counter(r["environment"] + "|" + r["wifi_band"] for r in rows).items())),
        "person_instances_by_action": dict(sorted(collections.Counter(a for r in rows for a in combo(r)).items())),
        "records_by_action_count": {a: dict(sorted(c.items())) for a, c in action_counts.items()},
    }


def support_audit(train, held):
    out = {}
    for n in (2, 3):
        tr = [r for r in train if int(r["number_of_users"]) == n]
        te = [r for r in held if int(r["number_of_users"]) == n]
        tf = [support_features(r) for r in tr]
        ef = [support_features(r) for r in te]
        stats = {"records": len(te)}
        for name in ("identity_set", "identity_location_profile", "location_multiset"):
            support = {x[name] for x in tf}
            supported = sum(x[name] in support for x in ef)
            stats[name] = {"train_unique": len(support), "heldout_unique": len({x[name] for x in ef}), "supported_records": supported, "supported_fraction": supported / len(ef) if ef else None}
        pair_support = {pair for f in tf for pair in f["identity_action_pairs"]}
        stats["all_identity_action_pairs_supported"] = sum(all(p in pair_support for p in f["identity_action_pairs"]) for f in ef)
        tr_cs = {combo(r) for r in tr}
        te_cs = {combo(r) for r in te}
        missing = sorted(count_support(te_cs) - count_support(tr_cs))
        stats["missing_positive_action_count_support"] = [[a, count] for a, count in missing]
        stats["train_positive_counts_by_action"] = {a: sorted({c.count(a) for c in tr_cs if c.count(a)}) for a in ACTIVITIES}
        out[str(n)] = stats
    return out


def context_audit(train, all_rows):
    """Count genuine composition contexts for each (occupancy, action, count).

    A context is a different complete action-count vector, not a different
    recording, subject, room, or band. Positive count equal to occupancy has
    exactly one possible context and is intrinsically unpairable.
    """
    result = {}
    table = []
    for n in (2, 3):
        tr = [r for r in train if int(r["number_of_users"]) == n]
        all_n = [r for r in all_rows if int(r["number_of_users"]) == n]
        train_combos = {combo(r) for r in tr}
        all_combos = {combo(r) for r in all_n}
        groups = []
        for action in ACTIVITIES:
            for count in range(1, n + 1):
                observed = sorted(c for c in all_combos if c.count(action) == count)
                if not observed:
                    continue
                contexts = sorted(c for c in train_combos if c.count(action) == count)
                matching_rows = [r for r in tr if combo(r).count(action) == count]
                by_domain = {}
                for env, band in sorted({(r["environment"], r["wifi_band"]) for r in all_n}):
                    by_domain[env + "|" + band] = len({combo(r) for r in matching_rows if r["environment"] == env and r["wifi_band"] == band})
                item = {
                    "number_of_users": n, "action": action, "positive_count": count,
                    "observed_contexts_full_dataset": len(observed),
                    "train_contexts": len(contexts), "train_records": len(matching_rows),
                    "pairable_in_train": len(contexts) >= 2,
                    "intrinsically_single_context": count == n,
                    "min_contexts_within_environment_band": min(by_domain.values()),
                    "contexts_by_environment_band": by_domain,
                    "train_combo_ids": [combo_id(c) for c in contexts],
                }
                groups.append(item)
                table.append({k: v for k, v in item.items() if k not in ("contexts_by_environment_band", "train_combo_ids")})
        counts = [g["train_contexts"] for g in groups]
        eligible = [g for g in groups if not g["intrinsically_single_context"]]
        result[str(n)] = {
            "positive_groups_observed": len(groups),
            "pairable_groups": sum(g["pairable_in_train"] for g in groups),
            "nonpure_eligible_groups": len(eligible),
            "nonpure_pairable_groups": sum(g["pairable_in_train"] for g in eligible),
            "full_data_pairable_groups": sum(g["observed_contexts_full_dataset"] >= 2 for g in groups),
            "full_data_pairable_groups_retained_in_train": sum(g["observed_contexts_full_dataset"] >= 2 and g["pairable_in_train"] for g in groups),
            "pairable_group_coverage_of_full_data": sum(g["observed_contexts_full_dataset"] >= 2 and g["pairable_in_train"] for g in groups) / sum(g["observed_contexts_full_dataset"] >= 2 for g in groups),
            "train_context_count_histogram": dict(sorted(collections.Counter(counts).items())),
            "unpairable_groups": [{"action": g["action"], "positive_count": g["positive_count"], "train_contexts": g["train_contexts"], "observed_contexts_full_dataset": g["observed_contexts_full_dataset"], "intrinsically_single_context": g["intrinsically_single_context"]} for g in groups if not g["pairable_in_train"]],
            "groups": groups,
        }
    return result, table


def held_context_coverage(held, contexts):
    train_support = {(int(n), g["action"], g["positive_count"]): g for n, cs in contexts.items() for g in cs["groups"]}
    out = {}
    for occupancy in (2, 3, "all"):
        rr = [r for r in held if int(r["number_of_users"]) in (2, 3) and (occupancy == "all" or int(r["number_of_users"]) == occupancy)]
        by_weight = {}
        for weighting, units in (("record", [combo(r) for r in rr]), ("complete_combo", sorted({combo(r) for r in rr}))):
            total = pairable = structural = all_supported_units = any_supported_units = 0
            for c in units:
                checks = []
                for action, count in collections.Counter(c).items():
                    g = train_support[(len(c), action, count)]
                    total += 1
                    pairable += int(g["pairable_in_train"])
                    structural += int(g["intrinsically_single_context"])
                    checks.append(g["pairable_in_train"])
                all_supported_units += int(all(checks))
                any_supported_units += int(any(checks))
            by_weight[weighting] = {
                "units": len(units), "positive_action_count_entries": total,
                "entries_with_pairable_train_context": pairable,
                "entries_without_pairable_train_context": total - pairable,
                "structurally_unpairable_entries": structural,
                "pairable_positive_entry_fraction": pairable / total if total else None,
                "units_with_all_positive_entries_pairable": all_supported_units,
                "units_with_any_positive_entry_pairable": any_supported_units,
            }
        out[str(occupancy)] = by_weight
    return out


def write_csv(path, fields, data):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(data)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=pathlib.Path, default=pathlib.Path(__file__).parents[1] / "sources" / "wimans_annotation.csv")
    parser.add_argument("--output", type=pathlib.Path, default=pathlib.Path(__file__).parent)
    args = parser.parse_args()
    raw = args.input.read_bytes()
    with args.input.open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    assert len({r["label"] for r in rows}) == len(rows)
    assert all(len(combo(r)) == int(r["number_of_users"]) for r in rows)
    args.output.mkdir(parents=True, exist_ok=True)
    groups = {n: collections.defaultdict(list) for n in (2, 3)}
    for row in rows:
        n = int(row["number_of_users"])
        if n in groups:
            groups[n][combo(row)].append(row)
    audit = {
        "status": "metadata_candidate_requires_raw_signal_and_acquisition_group_audit_before_training",
        "input_sha256": hashlib.sha256(raw).hexdigest(),
        "source": "https://github.com/huangshk/WiMANS/blob/main/dataset/annotation.csv",
        "activities": ACTIVITIES,
        "rules": {"seeds": SEEDS, "combo_targets": TARGETS, "search_draws": SEARCH_DRAWS, "seen_fraction_requested": SEEN_FRACTION, "aux_ratios": [0.6, 0.2, 0.2], "pure_same_action_combos_train_anchors": True, "positive_count_support_same_occupancy_required": True},
        "input": summarize(rows),
        "seeds": {},
    }
    for seed in SEEDS:
        maps, search = {}, {}
        for n in (2, 3):
            maps[n], search[n] = assign_combos(groups[n], n, seed)
        assigned = partition_records(rows, maps, seed)
        output_rows = []
        for row in rows:
            n = int(row["number_of_users"])
            c = combo(row)
            output_rows.append({
                "record_id": row["label"], "annotation_row": row["#"], "partition": assigned[row["label"]],
                "combo_partition": maps[n][c] if n in maps else ("auxiliary" if n <= 1 else "excluded"),
                "combo_id": combo_id(c), "number_of_users": n,
                "environment": row["environment"], "wifi_band": row["wifi_band"],
                **{f"count_{a}": c.count(a) for a in ACTIVITIES},
                "raw_capture_group": "UNVERIFIED", "all_derived_windows_inherit_record_partition": "true",
            })
        write_csv(args.output / f"sample_manifest_seed{seed}.csv", list(output_rows[0]), output_rows)
        combo_rows = []
        for n in (2, 3):
            for c in sorted(groups[n]):
                gr = groups[n][c]
                counts = collections.Counter(assigned[r["label"]] for r in gr)
                combo_rows.append({"number_of_users": n, "combo_id": combo_id(c), "combo_partition": maps[n][c], "pure_anchor": len(set(c)) == 1, "records_total": len(gr), "train_records": counts["train"], "test_seen_records": counts["test_seen"], "val_unseen_records": counts["val_unseen"], "test_unseen_records": counts["test_unseen"]})
        write_csv(args.output / f"combo_manifest_seed{seed}.csv", list(combo_rows[0]), combo_rows)
        partitioned = {p: [r for r in rows if assigned[r["label"]] == p] for p in sorted(set(assigned.values()))}
        seed_audit = {
            "search": search,
            "combo_counts": {str(n): dict(collections.Counter(maps[n].values())) for n in (2, 3)},
            "partitions": {p: summarize(rr) for p, rr in partitioned.items()},
            "support": {p: support_audit(partitioned["train"], partitioned[p]) for p in ("val_unseen", "test_unseen", "test_seen")},
            "record_ids_disjoint": True,
            "unseen_combo_sets_disjoint": all(len({c for c, p in maps[n].items() if p == s1} & {c for c, p in maps[n].items() if p == s2}) == 0 for n in (2, 3) for s1, s2 in (("train_combo", "val_unseen"), ("train_combo", "test_unseen"), ("val_unseen", "test_unseen"))),
        }
        seed_audit["context_support"], context_rows = context_audit(partitioned["train"], rows)
        seed_audit["heldout_context_coverage"] = {p: held_context_coverage(partitioned[p], seed_audit["context_support"]) for p in ("val_unseen", "test_unseen", "test_seen")}
        write_csv(args.output / f"context_support_seed{seed}.csv", list(context_rows[0]), context_rows)
        assert all(not n_stats["missing_positive_action_count_support"] for p_stats in seed_audit["support"].values() for n_stats in p_stats.values())
        audit["seeds"][str(seed)] = seed_audit
        print(seed, {p: len(rr) for p, rr in partitioned.items()})
    (args.output / "compact_audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    md = [
        "# WiMANS composition split metadata audit",
        "", "These are reproducible metadata-only candidate splits, not trained results. Raw signal existence, corruption and acquisition-session grouping still require audit before training.",
        "", f"Input SHA-256: `{audit['input_sha256']}`",
        "", "Source: https://github.com/huangshk/WiMANS/blob/main/dataset/annotation.csv",
        "", "## Frozen split rules", "",
        "- Use all nine action labels, including `nothing` (a present inactive person); empty-room records have occupancy zero and all action counts zero.",
        "- At occupancy 2, partition 36 observed complete combinations into 22 training, 7 unseen validation and 7 unseen test combinations. At occupancy 3, partition 54 into 32/11/11. The nine pure same-action combinations at each occupancy are included within the training totals; only mixed combinations are held out.",
        "- Keep each record intact; every derived window inherits its record partition. Retain approximately 20% of training-combination records as test_seen within each combination/environment/band stratum.",
        "- Occupancy 0/1 uses independent 60/20/20 auxiliary partitions within occupancy/combination/environment/band strata. Occupancy 4/5 is excluded from the main experiment.",
        "- Search 10,000 seeded metadata assignments with hard positive action-count coverage at the same occupancy. Select using record balance and person-weighted action marginals only; no CSI, performance, or outcomes are read.",
        "- No sample IDs overlap; train, validation-unseen, and test-unseen complete-combination sets are disjoint. All held-out positive (occupancy, action, count) groups are supported in training.",
        "", "## Record counts", "",
        "| Seed | train 2/3 | train aux 0/1 | val_unseen | test_unseen | test_seen | val_aux | test_aux | excluded 4/5 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for seed, item in audit["seeds"].items():
        p = item["partitions"]
        train_occ = p["train"]["by_occupancy"]
        core = sum(v for k, v in train_occ.items() if int(k) in (2, 3))
        aux = sum(v for k, v in train_occ.items() if int(k) in (0, 1))
        md.append("| " + " | ".join([seed, str(core), str(aux)] + [str(p[k]["records"]) for k in ("val_unseen", "test_unseen", "test_seen", "val_aux", "test_aux", "excluded_4_5")]) + " |")
    md += ["", "## Positive-count context support", "",
        "A distinct context means a different complete activity-count vector at the SAME occupancy and SAME target-action count. Another person, room, band, recording or crop does not by itself create a new composition context. Count equal to total occupancy is structurally restricted to one pure combination and cannot form a cross-context positive pair.", "",
        "| Seed | Occupancy | All positive groups | >=2 training contexts | Nonpure groups | Nonpure >=2 contexts |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for seed, item in audit["seeds"].items():
        for n, cs in item["context_support"].items():
            md.append(f"| {seed} | {n} | {cs['positive_groups_observed']} | {cs['pairable_groups']} | {cs['nonpure_eligible_groups']} | {cs['nonpure_pairable_groups']} |")
    md += ["", "Unpairable nonpure groups (these MUST be skipped or assigned zero cross-context consistency weight; repeating samples does not create a missing context):", ""]
    for seed, item in audit["seeds"].items():
        missing = [f"n={n}, {g['action']} count={g['positive_count']} (train {g['train_contexts']}, full data {g['observed_contexts_full_dataset']})" for n, cs in item["context_support"].items() for g in cs["unpairable_groups"] if not g["intrinsically_single_context"]]
        md.append(f"- Seed {seed}: " + ("; ".join(missing) if missing else "none") + ".")
    md += ["", "Every seed additionally has 18 intrinsically unpairable pure groups: all nine actions with count 2 at occupancy 2 and count 3 at occupancy 3. Use them for supervised counting, not cross-context matching.",
        "", "## Coverage of theoretically pairable groups and test targets", "",
        "Full annotations contain 27 positive (occupancy, action, count) groups with at least two observed complete-combination contexts: 9 at occupancy 2 and 18 at occupancy 3. The frozen split is NOT re-optimized to maximize pairability for the proposed loss.", "",
        "| Seed | Retained pairable groups / full-data pairable groups | Test positive entries pairable / all (record weighted) | Test positive entries pairable / all (combo weighted) | Test records with every positive entry pairable / all |",
        "|---|---:|---:|---:|---:|",
    ]
    for seed, item in audit["seeds"].items():
        retained = sum(cs["full_data_pairable_groups_retained_in_train"] for cs in item["context_support"].values())
        possible = sum(cs["full_data_pairable_groups"] for cs in item["context_support"].values())
        cv = item["heldout_context_coverage"]["test_unseen"]["all"]
        r, c = cv["record"], cv["complete_combo"]
        md.append(f"| {seed} | {retained}/{possible} ({retained / possible:.1%}) | {r['entries_with_pairable_train_context']}/{r['positive_action_count_entries']} ({r['pairable_positive_entry_fraction']:.1%}) | {c['entries_with_pairable_train_context']}/{c['positive_action_count_entries']} ({c['pairable_positive_entry_fraction']:.1%}) | {r['units_with_all_positive_entries_pairable']}/{r['units']} |")
    md += ["", "Positive-entry weighting counts each present activity once per record or complete combination, regardless of whether its count is 1 or 2. Thus it measures coverage of supervised count targets rather than the number of people. Full per-occupancy validation/test/seen-test statistics and unsupported-entry counts are preserved in JSON under `heldout_context_coverage`.",
        "", "## Confounding and residual checks", "",
        "The JSON `support` section reports identity-set, identity-location-profile and location-multiset coverage separately; disjoint compositions do not guarantee nuisance-balanced or session-independent data. `raw_capture_group` remains UNVERIFIED. Match or stratify nuisance factors when reporting composition generalization; do not call this a clean cross-person or cross-room test.",
        "", "The context CSV reports the number of distinct contexts in each positive group and the minimum available within one environment/band. For any method that samples cross-context pairs, filter using this table and record the actual eligible-pair rate per minibatch. Do not silently broaden positive pairing across occupancy or target count.",
        "", "## Reproduction", "", "Run `build_wimans_splits.py --input <annotation.csv> --output <splits-directory>` with Python 3.10+. It uses only the standard library. Each seed produces a sample manifest, a combination manifest and a context-support table; `compact_audit.json` preserves full metadata checks.",
    ]
    (args.output / "split_audit.md").write_text("\n".join(md) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
