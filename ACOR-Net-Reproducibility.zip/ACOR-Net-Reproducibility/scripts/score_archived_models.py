"""Re-score selected original roles on unseen, seen and auxiliary partitions."""
from pathlib import Path
import csv,json,statistics as st,collections
ROOT=Path(__file__).resolve().parents[1]
def score(rows):
    exact=[];occ=[];ae=[];pe=[];zero=[];comb=collections.defaultdict(list);tp=fp=fn=0
    for r in rows:
        y=json.loads(r['truth']);q=json.loads(r['pred']);e=y==q
        exact.append(e);comb[tuple(y)].append(e);occ.append(sum(y)==sum(q))
        for a,b in zip(y,q):
            ae.append(abs(a-b));tp+=min(a,b);fp+=max(b-a,0);fn+=max(a-b,0)
            if a:pe.append(abs(a-b))
            else:zero.append(b>0)
    return dict(macro_exact=st.mean(st.mean(v) for v in comb.values()),sample_exact=st.mean(exact),
                mae_all=st.mean(ae),mae_positive=st.mean(pe) if pe else None,zfp=st.mean(zero),
                occupancy_accuracy=st.mean(occ),f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 1.)
def main():
    index=json.loads((ROOT/'protocol/original_evaluation_index.json').read_text());out=[]
    for item in index:
        with (ROOT/item['predictions']).open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
        out.append(dict(**item,records=len(rows),**score(rows)))
    dest=ROOT/'_reproduced';dest.mkdir(exist_ok=True)
    (dest/'original_role_metrics.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('Re-scored',len(out),'original role/partition results; role reuse is retained explicitly.')
if __name__=='__main__':main()
