"""Relocate an archived final config and train it without changing scientific settings."""
from pathlib import Path
import argparse,json,sys,importlib.util

ROOT=Path(__file__).resolve().parents[1]
def prepare(job,data_root,output_root):
    index=json.loads((ROOT/'configs/index.json').read_text())
    item=next((r for r in index if r['job']==job),None)
    if item is None:raise ValueError('Unknown job; use --list')
    cfg=json.loads((ROOT/item['config']).read_text())
    cfg['manifest']=str(ROOT/'reproducibility/manifests'/f"sample_manifest_seed{cfg['split_seed']}.csv")
    cfg['data_root']=str(Path(data_root).resolve())
    cfg['output']=str(Path(output_root).resolve()/job.replace('/','__'))
    cfg['cache_dir']=str(Path(output_root).resolve()/'cache')
    if cfg.get('data_index'):raise ValueError('External data index must be provided explicitly')
    if cfg.get('development_protocol'):raise ValueError('This runner accepts final paper configs only')
    return item,cfg
def main():
    p=argparse.ArgumentParser();p.add_argument('--list',action='store_true');p.add_argument('--job');p.add_argument('--data-root');p.add_argument('--output-root',default='runs/reproduction');p.add_argument('--execute',action='store_true');a=p.parse_args()
    if a.list:
        for r in json.loads((ROOT/'configs/index.json').read_text()):print(r['job'])
        return
    if not a.job or not a.data_root:p.error('--job and --data-root are required')
    item,cfg=prepare(a.job,a.data_root,a.output_root)
    out=Path(cfg['output']);out.mkdir(parents=True,exist_ok=True)
    dest=out/'relocated_config.json';dest.write_text(json.dumps(cfg,indent=2),encoding='utf-8')
    print('Prepared',dest)
    if not a.execute:return
    sys.path.insert(0,str(ROOT/'experiments/original_release/src'))
    if item['kind']=='direct_occupancy':
        path=ROOT/'experiments/measurement_experiments.py'
        spec=importlib.util.spec_from_file_location('measurement_extension',path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        _,engine=mod.activate(ROOT/'experiments/original_release')
    else:from wificount import engine
    engine.train(cfg)
if __name__=='__main__':main()
