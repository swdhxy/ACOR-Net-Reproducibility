"""Post hoc diagnostics of frozen outputs; no fitting or test-based selection."""
from pathlib import Path
import argparse, json, csv, hashlib, collections, math
import numpy as np
import torch

ACT=['Jumping','Lying down','Stationary','Picking up','Turning around','Sitting down','Standing up','Walking','Waving']
LAM=[0,.05,.1,.25,.5,1,2]
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def dump(p,x): p.write_text(json.dumps(x,indent=2,allow_nan=False),encoding='utf-8')
def save(p,rows):
    if not rows:return
    with p.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def candidates():
    rows=[]
    def visit(pre,rem):
        if len(pre)==9:rows.append(pre);return
        for n in range(rem+1):visit(pre+[n],rem-n)
    visit([],3);return np.array(rows,dtype=np.int64)
def metrics(y,q):
    eq=(y==q).all(1); n=y.sum(1); pn=q.sum(1); d=q-y
    groups=collections.defaultdict(list)
    for z,e in zip(y,eq):groups[tuple(z)].append(e)
    tp=np.minimum(y,q).sum(); fp=np.maximum(d,0).sum(); fn=np.maximum(-d,0).sum()
    u=np.maximum(-d,0).sum(1);o=np.maximum(d,0).sum(1)
    r=dict(macro_exact=float(np.mean([np.mean(v) for v in groups.values()])),sample_exact=float(eq.mean()),
        mae_all=float(np.abs(d).mean()),mae_positive=float(np.abs(d)[y>0].mean()),
        zfp=float((q[y==0]>0).mean()),f1=float(2*tp/(2*tp+fp+fn)),
        occupancy_accuracy=float((n==pn).mean()),occupancy_mae=float(np.abs(n-pn).mean()),
        bias=float(d.mean()),fp_people_per_record=float(o.mean()),fn_people_per_record=float(u.mean()),
        reassigned_people_per_record=float(np.minimum(u,o).mean()),
        exact=float(eq.mean()),correct_total_wrong_allocation=float(((n==pn)&~eq).mean()),
        underestimated_total=float((pn<n).mean()),overestimated_total=float((pn>n).mean()))
    assert abs(r['exact']+r['correct_total_wrong_allocation']+r['underestimated_total']+r['overestimated_total']-1)<1e-12
    assert abs((fp+fn)-(2*np.minimum(u,o).sum()+np.abs(n-pn).sum()))<1e-9
    return r
def summarize(rows,keys,metricnames=None):
    groups=collections.defaultdict(list)
    for r in rows:groups[tuple(r[k] for k in keys)].append(r)
    out=[]
    for key,rr in sorted(groups.items()):
        names=metricnames or [k for k,v in rr[0].items() if k not in keys+['split','model_seed'] and isinstance(v,(int,float))]
        out.append(dict(zip(keys,key),models=len(rr),**{k:float(np.mean([r[k] for r in rr])) for k in names}))
    return out
def calibration(p,n):
    pred=p.argmax(1); conf=p.max(1); correct=pred==n
    bins=[];ece=0
    for k in range(10):
        ix=(conf>=k/10)&((conf<(k+1)/10) if k<9 else (conf<=1))
        num=int(ix.sum());acc=float(correct[ix].mean()) if num else None;cf=float(conf[ix].mean()) if num else None
        contribution=num/len(n)*abs(acc-cf) if num else 0;ece+=contribution
        bins.append(dict(bin_left=k/10,bin_right=(k+1)/10,records=num,
                         correct=int(correct[ix].sum()),confidence_sum=float(conf[ix].sum()),ece_contribution=contribution))
    oh=np.eye(4)[n]
    return dict(nll=float(-np.log(p[np.arange(len(n)),n].clip(1e-300)).mean()),
        brier=float(((p-oh)**2).sum(1).mean()),ece=ece,head_accuracy=float(correct.mean()),
        mean_confidence=float(conf.mean())),bins
def sufficient(y,q,combos):
    rows=[]
    for c in combos:
        ix=(y==np.array(c)).all(1);a=y[ix];b=q[ix];d=b-a
        tp=np.minimum(a,b).sum();fp=np.maximum(d,0).sum();fn=np.maximum(-d,0).sum()
        rows.append([len(a),int((a==b).all(1).sum()),np.abs(d).sum(),d.sum(),
                     ((b>0)&(a==0)).sum(),(a==0).sum(),2*tp,2*tp+fp+fn])
    return np.array(rows,dtype=float)
def stat(s,idx):
    z=s[:,idx,:].sum(1)
    return np.stack([(s[:,idx,1]/s[:,idx,0]).mean(1),z[:,2]/(9*z[:,0]),z[:,3]/(9*z[:,0]),z[:,4]/z[:,5],z[:,6]/z[:,7]],axis=1).mean(0)
def bootstrap(data):
    result=[];rng=np.random.default_rng(20261113)
    for split in [2026,2027,2028]:
        combos=sorted({tuple(z) for z in data[('Full',split,2026)]['y']});assert len(combos)==18
        strata=[[i for i,c in enumerate(combos) if sum(c)==n] for n in [2,3]]
        assert list(map(len,strata))==[7,11]
        arrays={f:np.stack([sufficient(data[(f,split,seed)]['y'],data[(f,split,seed)]['q'],combos) for seed in [2026,2027,2028]]) for f in ['Full','Native']}
        point=stat(arrays['Full'],list(range(18)))-stat(arrays['Native'],list(range(18)))
        draws=[]
        for _ in range(2000):
            ix=np.concatenate([rng.choice(g,len(g),replace=True) for g in strata])
            draws.append(stat(arrays['Full'],ix)-stat(arrays['Native'],ix))
        lo,hi=np.quantile(draws,[.025,.975],axis=0)
        for j,k in enumerate(['macro_exact','mae_all','bias','zfp','f1']):
            result.append(dict(split=split,contrast='Full minus Native',metric=k,difference=float(point[j]),low=float(lo[j]),high=float(hi[j]),draws=2000))
    return result
def main():
    parent=Path(__file__).resolve().parents[1]
    default_source=parent/'experiments/server_results'
    if not default_source.exists():default_source=parent/'measurement_revision_20261112_v2/experiments/server_results'
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=default_source);p.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'results');args=p.parse_args()
    root=args.source;out=args.output;out.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(2);cs=candidates();ct=torch.tensor(cs,dtype=torch.float32);cn=ct.sum(1).long();assert len(cs)==220
    per=[];sens=[];cal=[];bins=[];occ=[];activity=[];confusion=[];combrows=[];sparse=[];trans=[];data={};hashes={}
    for dest in sorted((root/'evaluation').glob('*/drop0_mask0')):
        meta=read(dest/'complete.json');job=meta['job']
        family='Full' if job.startswith('main/ours_v4') else 'Native' if job.startswith('main/activity_counting') else 'No contrast' if job.startswith('ablation/') else 'Direct + occupancy'
        context=dict(family=family,split=meta['split'],model_seed=meta['model_seed'])
        rr=read(dest/'predictions.json');cc=read(dest/'continuous_outputs.json')
        for name in ['predictions.json','continuous_outputs.json','complete.json']:
            z=dest/name;hashes[z.relative_to(root).as_posix()]=hashlib.sha256(z.read_bytes()).hexdigest()
        assert [r['record_id'] for r in rr]==[r['record_id'] for r in cc]
        y=np.array([r['truth'] for r in rr]);native='round' if family=='Native' else 'soft';q=np.array([r[native] for r in rr]);m=metrics(y,q)
        per.append(dict(**context,records=len(y),**m));data[(family,meta['split'],meta['model_seed'])]=dict(y=y,q=q)
        if family in ['Full','Native']:
            for n in [2,3]:
                ix=y.sum(1)==n;per.append(dict(**{**context,'family':family+f' / {n} people'},records=int(ix.sum()),**metrics(y[ix],q[ix])))
            for k,label in enumerate(ACT):
                d=q[:,k]-y[:,k];activity.append(dict(**context,activity=label,mae=float(np.abs(d).mean()),bias=float(d.mean()),zfp=float((q[y[:,k]==0,k]>0).mean())))
                for a in range(4):
                    den=int((y[:,k]==a).sum())
                    for b in range(5):
                        cnt=int(((y[:,k]==a)&((q[:,k]==b) if b<4 else (q[:,k]>=4))).sum())
                        confusion.append(dict(**context,activity=label,reference=a,predicted=str(b) if b<4 else '4+',count=cnt,reference_records=den,row_fraction=cnt/den if den else ''))
            for c in sorted({tuple(z) for z in y}):
                ix=(y==np.array(c)).all(1);ym=y[ix];qm=q[ix]
                combrows.append(dict(**context,reference_vector=' '.join(map(str,c)),occupancy=sum(c),records=int(ix.sum()),**metrics(ym,qm)))
                counts=collections.Counter(tuple(z) for z in qm)
                for pred,cnt in sorted(counts.items()):sparse.append(dict(**context,reference_vector=' '.join(map(str,c)),predicted_vector=' '.join(map(str,pred)),count=cnt,reference_records=int(ix.sum()),row_fraction=cnt/int(ix.sum())))
        mu=torch.tensor([r['regression'] for r in cc],dtype=torch.float32);base=2*mu@ct.T-ct.square().sum(1)
        assert np.array_equal(cs[base.argmax(1)],np.array([r['legal'] for r in rr]))
        if family=='Native':continue
        logits=torch.tensor([r['occupancy_logits'] for r in cc],dtype=torch.float32);lp=torch.log_softmax(logits,1)
        probs=np.exp(torch.log_softmax(logits.double(),1).numpy());n=y.sum(1);hp=probs.argmax(1)
        cm,bb=calibration(probs,n);cal.append(dict(**context,records=len(y),**cm))
        bins.extend(dict(**context,**b) for b in bb)
        cardinality=np.array([1,9,45,165]);expected=(hp==n)/cardinality[hp]
        gc=collections.defaultdict(list)
        for c,v in zip(y,expected):gc[tuple(c)].append(v)
        occ.append(dict(**context,head_accuracy=float((hp==n).mean()),expected_macro_exact=float(np.mean([np.mean(v) for v in gc.values()])),expected_sample_exact=float(expected.mean()),mean_candidate_ambiguity=float(cardinality[hp].mean())))
        for lam in LAM:
            z=cs[(base+lam*lp[:,cn]).argmax(1).numpy()]
            if lam==.25:assert np.array_equal(z,q)
            if lam==0:assert np.array_equal(z,np.array([r['legal'] for r in rr]))
            sens.append(dict(**context,lambda_occ=lam,**metrics(y,z)))
        legal=np.array([r['legal'] for r in rr]);soft=q;hard=np.array([r['hard'] for r in rr]);ln=legal.sum(1);sn=soft.sum(1)
        changed=(legal!=soft).any(1);same_total=(ln==sn)
        assert not bool((changed&same_total).any())
        trans.append(dict(**context,changed_fraction=float(changed.mean()),same_total_changed=0,
            hard_soft_disagreement=float((hard!=soft).any(1).mean()),
            corrected_fraction=float((~(legal==y).all(1)&(soft==y).all(1)).mean()),
            damaged_fraction=float(((legal==y).all(1)&~(soft==y).all(1)).mean())))
    assert len(data)==36 and len(cal)==27 and len(sens)==189
    datasets={'error_per_run':per,'activity_per_run':activity,'activity_count_confusion':confusion,'complete_combination_per_run':combrows,'complete_combination_confusion_sparse':sparse,'sensitivity_per_run':sens,'calibration_per_run':cal,'reliability_bins_per_run':bins,'occupancy_only_per_run':occ,'decoder_transitions_per_run':trans}
    for name,rows in datasets.items():save(out/(name+'.csv'),rows)
    summary=dict(errors=summarize(per,['family']),errors_by_split=summarize(per,['family','split']),
        sensitivity=summarize(sens,['family','lambda_occ']),sensitivity_by_split=summarize(sens,['family','split','lambda_occ']),
        calibration=summarize(cal,['family']),calibration_by_split=summarize(cal,['family','split']),
        occupancy_only=summarize(occ,['family']),transitions=summarize(trans,['family']),activity=summarize(activity,['family','activity']))
    for name,rows in summary.items():save(out/(name+'.csv'),rows)
    # SD is initialization variability within a fixed split, not dataset replication.
    stab=[]
    for family in ['Full','Native','No contrast','Direct + occupancy']:
        for split in [2026,2027,2028]:
            rows=[r for r in per if r['family']==family and r['split']==split]
            for key in ['macro_exact','mae_all','zfp','f1','occupancy_accuracy']:
                v=[r[key] for r in rows];stab.append(dict(family=family,split=split,metric=key,mean=float(np.mean(v)),initialization_sd=float(np.std(v,ddof=1)),minimum=min(v),maximum=max(v),initializations=3))
    save(out/'initialization_stability.csv',stab)
    ci=bootstrap(data);save(out/'paired_intervals.csv',ci);summary['paired_intervals']=ci
    dump(out/'summary.json',summary);dump(out/'input_hashes.json',hashes)
    dump(out/'verification.json',dict(frozen_clean_models=36,occupancy_models=27,sensitivity_conditions=189,original_soft_and_legal_decoders_reproduced=True,same_total_ranking_changes=0,error_partition_and_f1_accounting_verified=True,training_fits=0,bootstrap_draws_per_split=2000,calibration_fitting=False,lambda_grid=LAM,source=str(root.resolve())))
    print('DONE',out)
if __name__=='__main__':main()
