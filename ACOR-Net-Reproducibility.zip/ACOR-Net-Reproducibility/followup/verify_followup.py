"""Independent standard-library checks of the post hoc summaries."""
from pathlib import Path
import json,csv,math,statistics as st,collections,hashlib
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'experiments/server_results'
if not ROOT.exists():ROOT=HERE.parent/'measurement_revision_20261112_v2/experiments/server_results'
OUT=HERE/'results'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def csvread(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def close(a,b):assert abs(float(a)-float(b))<1e-10,(a,b)
for p,h in read(OUT/'input_hashes.json').items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h
rows=csvread(OUT/'error_per_run.csv');cal=csvread(OUT/'calibration_per_run.csv');checks=0
for dest in sorted((ROOT/'evaluation').glob('*/drop0_mask0')):
    meta=read(dest/'complete.json');job=meta['job'];split=meta['split'];seed=meta['model_seed']
    family='Full' if job.startswith('main/ours_v4') else 'Native' if job.startswith('main/activity_counting') else 'No contrast' if job.startswith('ablation/') else 'Direct + occupancy'
    stored=next(r for r in rows if r['family']==family and int(r['split'])==split and int(r['model_seed'])==seed)
    rr=read(dest/'predictions.json');decoder='round' if family=='Native' else 'soft';tp=fp=fn=0;types=collections.Counter();combo=collections.defaultdict(list);ma=[];bias=[];zeros=[];sub=[]
    for r in rr:
        y=r['truth'];q=r[decoder];e=y==q;u=sum(max(a-b,0) for a,b in zip(y,q));o=sum(max(b-a,0) for a,b in zip(y,q))
        tp+=sum(min(a,b) for a,b in zip(y,q));fp+=o;fn+=u;sub.append(min(u,o));combo[tuple(y)].append(e)
        kind='exact' if e else 'correct_total_wrong_allocation' if sum(y)==sum(q) else 'underestimated_total' if sum(q)<sum(y) else 'overestimated_total';types[kind]+=1
        ma.extend(abs(a-b) for a,b in zip(y,q));bias.extend(b-a for a,b in zip(y,q));zeros.extend(b>0 for a,b in zip(y,q) if a==0)
    actual=dict(macro_exact=st.mean(st.mean(v) for v in combo.values()),f1=2*tp/(2*tp+fp+fn),mae_all=st.mean(ma),bias=st.mean(bias),zfp=st.mean(zeros),reassigned_people_per_record=st.mean(sub),fp_people_per_record=fp/len(rr),fn_people_per_record=fn/len(rr))
    actual.update({k:types[k]/len(rr) for k in ['exact','correct_total_wrong_allocation','underestimated_total','overestimated_total']})
    for k,v in actual.items():close(stored[k],v);checks+=1
    if family=='Native':continue
    cc=read(dest/'continuous_outputs.json');brier=[];nll=[];binrows=collections.defaultdict(list)
    for r,c in zip(rr,cc):
        z=c['occupancy_logits'];mx=max(z);ex=[math.exp(x-mx) for x in z];p=[x/sum(ex) for x in ex];n=sum(r['truth']);pred=max(range(4),key=lambda i:p[i]);conf=max(p)
        brier.append(sum((x-(i==n))**2 for i,x in enumerate(p)));nll.append(-math.log(p[n]));binrows[min(9,int(conf*10))].append((conf,pred==n))
    ece=sum(len(v)/len(rr)*abs(st.mean(x[0] for x in v)-st.mean(x[1] for x in v)) for v in binrows.values())
    c=next(r for r in cal if r['family']==family and int(r['split'])==split and int(r['model_seed'])==seed)
    for k,v in dict(nll=st.mean(nll),brier=st.mean(brier),ece=ece).items():close(c[k],v);checks+=1
# Paired bootstrap point estimates must coincide with the original metric definition.
for r in csvread(OUT/'paired_intervals.csv'):
    key=r['metric'];split=r['split']
    a=[float(x[key]) for x in rows if x['family']=='Full' and x['split']==split]
    b=[float(x[key]) for x in rows if x['family']=='Native' and x['split']==split]
    close(r['difference'],st.mean(a)-st.mean(b));checks+=1
assert [math.comb(n+8,8) for n in range(4)]==[1,9,45,165]
report=dict(independent_scalar_checks=checks,input_hashes_verified=True,calibration_reproduced_without_torch=True,paired_interval_point_estimates_match=True)
target=OUT/'independent_verification.json'
if target.exists():assert read(target)==report
else:target.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(report)
