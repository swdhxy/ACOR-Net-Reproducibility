"""Reanalyse frozen integer predictions. No training, tuning, or model selection."""
from pathlib import Path
import csv, json, statistics as st, collections, hashlib, shutil

HERE = Path(__file__).resolve().parent
SOURCE = HERE / '_original_archive_not_distributed'
P = SOURCE / 'acor_reduced'
OUT = HERE / '_reproduced/original'
OUT.mkdir(parents=True, exist_ok=True)
REPRO = HERE / 'reproducibility'
REPRO.mkdir(exist_ok=True)
if not P.exists():
    P = REPRO / 'frozen_predictions'

def rows(p):
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def save(name, data):
    with (OUT/name).open('w', encoding='utf-8', newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0])); w.writeheader(); w.writerows(data)

def mean(x): return st.mean(x) if x else None

def calc(dd):
    combos=collections.defaultdict(list)
    exact=[]; occ=[]; ae=[]; pe=[]; ze=[]; oe=[]
    tp=fp=fn=0
    for x in dd:
        t=x['t']; p=x['p']; e=t==p; o=sum(t)==sum(p)
        combos[tuple(t)].append(e); exact.append(e); occ.append(o); oe.append(sum(p)-sum(t))
        for a,b in zip(t,p):
            ae.append(abs(b-a))
            if a>0: pe.append(abs(b-a))
            else: ze.append(b>0)
            tp+=min(a,b); fp+=max(b-a,0); fn+=max(a-b,0)
    return dict(records=len(dd), macro_exact=mean([mean(v) for v in combos.values()]),
                sample_exact=mean(exact), mae_positive=mean(pe), mae_all=mean(ae), zfp=mean(ze),
                f1=2*tp/(2*tp+fp+fn), occupancy_accuracy=mean(occ),
                occupancy_mae=mean([abs(x) for x in oe]), occupancy_bias=mean(oe),
                allocation_given_correct_occupancy=sum(exact)/sum(occ) if sum(occ) else None,
                correct_occupancy_wrong_allocation=mean([o and not e for o,e in zip(occ,exact)]))

selection_path=P/'selection.json' if (P/'selection.json').exists() else REPRO/'selection.json'
hash_path=P/'package_files.sha256.json' if (P/'package_files.sha256.json').exists() else REPRO/'package_files.sha256.json'
selection=json.loads(selection_path.read_text(encoding='utf-8'))['selected']
hashes=json.loads(hash_path.read_text(encoding='utf-8'))
provenance=[]; checked=0; main=[]; strata=[]; activity=[]; transitions=[]; conf=[]
mapping={'macro_exact':'macro_exact_match_by_complete_composition','sample_exact':'sample_exact_match',
         'mae_positive':'positive_count_mae','mae_all':'all_count_mae','zfp':'zero_count_false_positive_rate',
         'f1':'multiset_micro_f1','occupancy_accuracy':'occupancy_accuracy','occupancy_mae':'occupancy_mae'}

def load(p):
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    key='acor_reduced/'+p.relative_to(P).as_posix()
    if key in hashes: assert digest==hashes[key], key
    provenance.append(dict(path=key,sha256=digest,archive_hash_verified=key in hashes))
    dest=REPRO/'frozen_predictions'/p.relative_to(P)
    dest.parent.mkdir(parents=True,exist_ok=True)
    if p.resolve()!=dest.resolve(): shutil.copy2(p,dest)
    dd=rows(p)
    ids=[x['record_id'] for x in dd]; assert len(ids)==len(set(ids))
    for x in dd:
        x['t']=json.loads(x['truth']); x['p']=json.loads(x['pred'])
        assert len(x['t'])==len(x['p'])==9
        assert sum(x['t'])==int(x['n']) and sum(x['p'])==int(x['predicted_n'])
    return dd

for r in rows(P/'reports/main_all_runs.csv'):
    if r['partition']!='test_unseen': continue
    method=r['method']; internal='ours_v4' if method=='ACOR-Net' else method
    s=r['split_seed']; seed=r['model_seed']
    candidate=selection[f'{internal}:{s}']['candidate_id']
    dd=load(P/'runs/search'/f'{candidate}_m{seed}'/'evaluation_test_unseen/predictions.csv')
    met=calc(dd)
    for k,col in mapping.items():
        assert abs(met[k]-float(r[col]))<1e-10,(method,s,seed,k)
        checked+=1
    main.append(dict(method=method,split=s,seed=seed,**met))
    if method not in ['ACOR-Net','activity_counting']: continue
    mp=SOURCE/f'release/data/manifests/sample_manifest_seed{s}.csv'
    manifest=rows(mp if mp.exists() else REPRO/f'manifests/sample_manifest_seed{s}.csv')
    expected={x['record_id'] for x in manifest if x['partition']=='test_unseen'}
    assert expected=={x['record_id'] for x in dd}
    for dimension in ['n','environment','wifi_band']:
        for value in sorted({x[dimension] for x in dd}):
            sub=[x for x in dd if x[dimension]==value]
            strata.append(dict(method=method,split=s,seed=seed,dimension=dimension,value=value,**calc(sub)))
    for k,name in enumerate(['Jumping','Lying down','Stationary','Picking up','Turning around','Sitting down','Standing up','Walking','Waving']):
        errs=[x['p'][k]-x['t'][k] for x in dd]
        zero=[x['p'][k]>0 for x in dd if x['t'][k]==0]
        activity.append(dict(method=method,split=s,seed=seed,activity=name,mae=mean([abs(e) for e in errs]),bias=mean(errs),zfp=mean(zero),absent_records=len(zero)))
    for n in [2,3]:
        sub=[x for x in dd if sum(x['t'])==n]
        for pn in range(5):
            conf.append(dict(method=method,split=s,seed=seed,truth_n=n,pred_n=str(pn) if pn<4 else '4+',fraction=mean([sum(x['p'])==pn if pn<4 else sum(x['p'])>=4 for x in sub])))
    if method=='ACOR-Net':
        changed=load(P/f'sensitivity/main/ours_v4_s{s}_m{seed}/test_unseen/predictions.csv')
        old={x['record_id']:x for x in changed}; assert set(old)=={x['record_id'] for x in dd}
        rr=[(old[x['record_id']]['p']==x['t'],x['p']==x['t'],old[x['record_id']]['p']!=x['p']) for x in dd]
        transitions.append(dict(split=s,seed=seed,records=len(dd),
          corrected=mean([not a and b for a,b,c in rr]),damaged=mean([a and not b for a,b,c in rr]),
          both_correct=mean([a and b for a,b,c in rr]),both_wrong=mean([not a and not b for a,b,c in rr]),
          changed=mean([c for a,b,c in rr]),**{f'lambda0_{k}':v for k,v in calc(changed).items()}))

def aggregate(data, keys):
    groups=collections.defaultdict(list)
    for r in data: groups[tuple(r[k] for k in keys)].append(r)
    result=[]
    for key,rr in groups.items():
        value=dict(zip(keys,key)); value['runs']=len(rr)
        for k,v in rr[0].items():
            if k in keys or k in ['split','seed']: continue
            if isinstance(v,(int,float)):
                vals=[r[k] for r in rr if r[k] is not None]
                value[k]=mean(vals)
        result.append(value)
    return result

save('main_per_run.csv',main); save('strata_per_run.csv',strata); save('activity_per_run.csv',activity)
save('decoder_transitions_per_run.csv',transitions); save('occupancy_confusion_per_run.csv',conf)
summary={'main':aggregate(main,['method']),'strata':aggregate(strata,['method','dimension','value']),
         'activity':aggregate(activity,['method','activity']),'transitions':aggregate(transitions,[]),
         'confusion':aggregate(conf,['method','truth_n','pred_n'])}
for name,data in summary.items(): save(name+'_summary.csv',data)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
(OUT/'verification.json').write_text(json.dumps(dict(metric_checks_passed=checked,
    prediction_files=len(provenance),archive_hashes_verified=sum(x['archive_hash_verified'] for x in provenance),
    protocol='Fixed selected models; each metric calculated per model then averaged equally over 3 initializations and 3 splits; no pooling or new tuning.',
    inputs=provenance),indent=2),encoding='utf-8')
dest=REPRO/'manifests'; dest.mkdir(exist_ok=True)
for s in ['2026','2027','2028']:
    for kind in ['sample','combo']:
        source=SOURCE/f'release/data/manifests/{kind}_manifest_seed{s}.csv'
        if source.exists(): shutil.copy2(source,dest)
for name in ['selection.json','protocol.json','freeze.json']:
    source=P/name
    if source.exists() and source.resolve()!=(REPRO/name).resolve(): shutil.copy2(source,REPRO/name)
if hash_path.resolve()!=(REPRO/'package_files.sha256.json').resolve():
    shutil.copy2(hash_path,REPRO/'package_files.sha256.json')
dest=REPRO/'frozen_predictions/reports'; dest.mkdir(exist_ok=True)
source=P/'reports/main_all_runs.csv'
if source.resolve()!=(dest/'main_all_runs.csv').resolve(): shutil.copy2(source,dest)
print(json.dumps({k:v for k,v in summary.items() if k in ['main','transitions']},indent=2))
